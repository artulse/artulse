#!/usr/bin/env bash
# ============================================================
#  BitPanel upgrade — apply a new release onto an existing
#  install without touching data (panel.db, agent.key, ssl).
#     sudo bash upgrade.sh
# ============================================================
set -euo pipefail

BP_HOME="/opt/bitpanel"
BP_USER="bitpanel"
SRC="$(cd "$(dirname "$0")" && pwd)"

log()  { echo -e "\e[1;36m[bitpanel]\e[0m $*"; }
fail() { echo -e "\e[1;31m[bitpanel] ERROR:\e[0m $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "run as root: sudo bash upgrade.sh"
[ -d "$BP_HOME/panel" ] || fail "no existing install at $BP_HOME — run install.sh instead"

PANEL_PORT="$(grep -oE 'listen +[0-9]+' /etc/nginx/sites-available/bitpanel.conf | head -1 | grep -oE '[0-9]+')"
PANEL_PORT="${PANEL_PORT:-8899}"
log "Detected panel port ${PANEL_PORT}"

log "Updating panel + agent code..."
cp -r "$SRC/panel/." "$BP_HOME/panel/"
cp -r "$SRC/agent/." "$BP_HOME/agent/"
chown -R root:"$BP_USER" "$BP_HOME/panel" "$BP_HOME/agent"
chmod -R o-rwx "$BP_HOME/panel" "$BP_HOME/agent"

log "Refreshing PHP-FPM pool + Nginx vhost..."
sed -e "s|__BP_USER__|$BP_USER|g" -e "s|__BP_HOME__|$BP_HOME|g" \
  "$SRC/deploy/fpm-pool.conf.tpl" > /etc/php/8.3/fpm/pool.d/bitpanel.conf
[ -f /etc/nginx/snippets/bitpanel-allowlist.conf ] || \
  echo "# no restriction — all IPs allowed" > /etc/nginx/snippets/bitpanel-allowlist.conf
sed -e "s|__PORT__|$PANEL_PORT|g" -e "s|__BP_HOME__|$BP_HOME|g" \
  "$SRC/deploy/nginx-panel.conf.tpl" > /etc/nginx/sites-available/bitpanel.conf

log "Restarting services..."
cp "$SRC/agent/bitpanel-agent.service" /etc/systemd/system/bitpanel-agent.service
systemctl daemon-reload
systemctl restart bitpanel-agent
systemctl restart php8.3-fpm
nginx -t
systemctl reload nginx

sleep 1
systemctl is-active --quiet bitpanel-agent || fail "agent failed after upgrade — journalctl -u bitpanel-agent"

log "Upgrade complete. Hard-refresh the browser (Ctrl+Shift+R)."
