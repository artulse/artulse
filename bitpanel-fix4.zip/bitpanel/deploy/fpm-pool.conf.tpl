[bitpanel]
user = __BP_USER__
group = __BP_USER__

listen = /run/php/bitpanel.sock
listen.owner = www-data
listen.group = www-data
listen.mode = 0660

pm = ondemand
pm.max_children = 8
pm.process_idle_timeout = 30s
pm.max_requests = 500

php_admin_value[open_basedir] = __BP_HOME__:/run/bitpanel:/tmp
php_admin_value[error_log] = __BP_HOME__/logs/php.log
php_admin_flag[log_errors] = on
php_admin_flag[expose_php] = off
php_admin_value[session.save_path] = __BP_HOME__/data/sessions

; file manager limits
php_admin_value[upload_max_filesize] = 256M
php_admin_value[post_max_size] = 258M
php_admin_value[memory_limit] = 256M
php_admin_value[max_execution_time] = 300
php_admin_value[upload_tmp_dir] = __BP_HOME__/data/uptmp
