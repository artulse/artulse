server {
    listen __PORT__ ssl;
    listen [::]:__PORT__ ssl;
    server_name _;

    ssl_certificate     __BP_HOME__/data/ssl/panel.crt;
    ssl_certificate_key __BP_HOME__/data/ssl/panel.key;
    ssl_protocols       TLSv1.2 TLSv1.3;

    root  __BP_HOME__/panel/public;
    index index.php;

    include /etc/nginx/snippets/bitpanel-allowlist.conf;

    access_log /var/log/nginx/bitpanel.access.log;
    error_log  /var/log/nginx/bitpanel.error.log;

    client_max_body_size 260m;

    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-Content-Type-Options nosniff always;
    add_header Referrer-Policy same-origin always;

    location /assets/ {
        expires 1h;
    }

    # ---- web terminal (ttyd on 127.0.0.1:7681, session-gated) ----
    location /term/ {
        auth_request /term-auth;
        proxy_pass http://127.0.0.1:7681;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }

    location = /term-auth {
        internal;
        include fastcgi_params;
        fastcgi_pass unix:/run/php/bitpanel.sock;
        fastcgi_param SCRIPT_FILENAME $document_root/index.php;
        fastcgi_param REQUEST_URI /api/term-auth;
        fastcgi_param REQUEST_METHOD GET;
        fastcgi_param CONTENT_LENGTH "";
        fastcgi_param CONTENT_TYPE "";
    }

    location / {
        try_files $uri /index.php$is_args$args;
    }

    location = /index.php {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/bitpanel.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param HTTPS on;
        fastcgi_read_timeout 600s;
    }

    location ~ \.php$ { return 404; }
}
