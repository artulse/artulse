#!/usr/bin/env bash
# ============================================================
#  BitPanel installer — Ubuntu 24.04 (Phase 1)
#  Run as root from the extracted release directory:
#     sudo bash install.sh
#  Optional: PANEL_PORT=9001 sudo -E bash install.sh
# ============================================================
set -euo pipefail

PANEL_PORT="${PANEL_PORT:-8899}"
BP_HOME="/opt/bitpanel"
BP_USER="bitpanel"
SRC="$(cd "$(dirname "$0")" && pwd)"
export DEBIAN_FRONTEND=noninteractive

log()  { echo -e "\e[1;36m[bitpanel]\e[0m $*"; }
fail() { echo -e "\e[1;31m[bitpanel] ERROR:\e[0m $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "run as root: sudo bash install.sh"
grep -q 'VERSION_ID="24.04"' /etc/os-release || log "WARNING: built for Ubuntu 24.04, continuing anyway"

log "Updating apt index..."
apt-get update -qq
apt-get install -y -qq whiptail curl openssl unzip ca-certificates >/dev/null

# ------------------------------------------------------------
# Component selection (multi-select checklist)
# ------------------------------------------------------------
CHOICES=$(whiptail --title "BitPanel — select components" --checklist \
"Space = toggle, Enter = confirm.\nPanel core (PHP 8.3 + Nginx panel instance + SQLite) is always installed." \
24 78 15 \
"nginx"      "Nginx web server (for hosted sites)"        ON  \
"apache2"    "Apache web server"                          OFF \
"mysql"      "MySQL 8 server"                             ON  \
"mariadb"    "MariaDB server (do NOT pick with MySQL)"    OFF \
"postgresql" "PostgreSQL server"                          OFF \
"php81"      "PHP 8.1 FPM (ondrej PPA)"                   OFF \
"php82"      "PHP 8.2 FPM (ondrej PPA)"                   OFF \
"php83"      "PHP 8.3 FPM (site runtime)"                 ON  \
"nodejs"     "Node.js 22 LTS"                             OFF \
"redis"      "Redis server"                               OFF \
"memcached"  "Memcached"                                  OFF \
"docker"     "Docker Engine + compose"                    OFF \
"ttyd"       "ttyd daemon (web terminal, UI in Phase 2)"  OFF \
"fail2ban"   "Fail2ban brute-force protection"            ON  \
"ufw"        "UFW firewall (opens SSH + panel port)"      ON  \
3>&1 1>&2 2>&3) || fail "installation cancelled"

has() { case " ${CHOICES} " in *"\"$1\""*) return 0;; *) return 1;; esac; }

if has mysql && has mariadb; then
  fail "MySQL and MariaDB conflict — re-run and pick one."
fi

# ------------------------------------------------------------
# Panel core dependencies (always installed)
# ------------------------------------------------------------
log "Installing panel core (PHP 8.3 CLI/FPM, SQLite, Nginx)..."
apt-get install -y -qq nginx php8.3-fpm php8.3-cli php8.3-sqlite3 \
  php8.3-mbstring php8.3-curl php8.3-xml php8.3-zip >/dev/null

# ------------------------------------------------------------
# Selected components
# ------------------------------------------------------------
if has php81 || has php82; then
  log "Adding ondrej/php PPA for extra PHP versions..."
  apt-get install -y -qq software-properties-common >/dev/null
  add-apt-repository -y ppa:ondrej/php >/dev/null
  apt-get update -qq
fi

has apache2    && { log "Installing Apache (port 8080 to avoid Nginx clash)..."; apt-get install -y -qq apache2 >/dev/null; sed -i 's/^Listen 80$/Listen 8080/' /etc/apache2/ports.conf || true; systemctl restart apache2 || true; }
has mysql      && { log "Installing MySQL 8...";      apt-get install -y -qq mysql-server >/dev/null; }
has mariadb    && { log "Installing MariaDB...";      apt-get install -y -qq mariadb-server >/dev/null; }
has postgresql && { log "Installing PostgreSQL...";   apt-get install -y -qq postgresql >/dev/null; }
has php81      && { log "Installing PHP 8.1 FPM...";  apt-get install -y -qq php8.1-fpm php8.1-mysql php8.1-mbstring php8.1-curl php8.1-xml >/dev/null; }
has php82      && { log "Installing PHP 8.2 FPM...";  apt-get install -y -qq php8.2-fpm php8.2-mysql php8.2-mbstring php8.2-curl php8.2-xml >/dev/null; }
has php83      && { log "Installing PHP 8.3 site extensions..."; apt-get install -y -qq php8.3-mysql php8.3-gd php8.3-intl >/dev/null; }
has nodejs     && { log "Installing Node.js 22...";   curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null 2>&1; apt-get install -y -qq nodejs >/dev/null; }
has redis      && { log "Installing Redis...";        apt-get install -y -qq redis-server >/dev/null; }
has memcached  && { log "Installing Memcached...";    apt-get install -y -qq memcached >/dev/null; }
has docker     && { log "Installing Docker...";       apt-get install -y -qq docker.io docker-compose-v2 >/dev/null; systemctl enable --now docker >/dev/null 2>&1 || true; }
has ttyd       && { log "Installing ttyd...";         apt-get install -y -qq ttyd >/dev/null || log "ttyd package unavailable, skip (Phase 2 will bundle it)"; }
has fail2ban   && { log "Installing Fail2ban...";     apt-get install -y -qq fail2ban >/dev/null; systemctl enable --now fail2ban >/dev/null 2>&1 || true; }

# ------------------------------------------------------------
# Panel user + directories
# ------------------------------------------------------------
log "Creating ${BP_USER} system user and directory layout..."
id -u "$BP_USER" >/dev/null 2>&1 || useradd --system --home "$BP_HOME" --shell /usr/sbin/nologin "$BP_USER"
mkdir -p "$BP_HOME"/{panel,agent,data/ssl,data/ssl/sites,data/ssl/mail,data/sites,data/backups,data/bkjobs,data/daemons,data/uptmp,data/dltmp,data/mail,logs}
mkdir -p /var/www/_letsencrypt/.well-known/acme-challenge
chown -R www-data:www-data /var/www/_letsencrypt 2>/dev/null || true
cp -r "$SRC/panel/." "$BP_HOME/panel/"
cp -r "$SRC/agent/." "$BP_HOME/agent/"

# Shared secret between panel (bitpanel user) and agent (root)
openssl rand -hex 32 > "$BP_HOME/data/agent.key"
chown root:"$BP_USER" "$BP_HOME/data/agent.key"
chmod 640 "$BP_HOME/data/agent.key"

# Self-signed TLS cert for the panel itself
if [ ! -f "$BP_HOME/data/ssl/panel.crt" ]; then
  openssl req -x509 -nodes -newkey rsa:2048 -days 3650 \
    -subj "/CN=bitpanel" \
    -keyout "$BP_HOME/data/ssl/panel.key" \
    -out    "$BP_HOME/data/ssl/panel.crt" >/dev/null 2>&1
fi
chmod 600 "$BP_HOME/data/ssl/panel.key"

# ------------------------------------------------------------
# Panel database + admin credentials
# ------------------------------------------------------------
ADMIN_PASS="$(openssl rand -base64 15 | tr -d '/+=' | cut -c1-16)"
log "Initialising panel database..."
php "$BP_HOME/panel/bin/init_db.php" "admin" "$ADMIN_PASS"
# Save credentials NOW — if a later step fails, the password must not be lost.
CRED_FILE="/root/.bitpanel-credentials"
{
  echo "user=admin"
  echo "pass=${ADMIN_PASS}"
} > "$CRED_FILE"
chmod 600 "$CRED_FILE"
chown -R "$BP_USER":"$BP_USER" "$BP_HOME/data" "$BP_HOME/logs"
chown root:"$BP_USER" "$BP_HOME/data/agent.key"   # restore after -R
chmod 640 "$BP_HOME/data/agent.key"
chown -R root:"$BP_USER" "$BP_HOME/panel" "$BP_HOME/agent"
chmod -R o-rwx "$BP_HOME"
# nginx (www-data) must be able to traverse into and read the web root.
usermod -aG "$BP_USER" www-data
chgrp "$BP_USER" "$BP_HOME"
chmod 750 "$BP_HOME" "$BP_HOME/panel"
find "$BP_HOME/panel" -type d -exec chmod 750 {} \;
find "$BP_HOME/panel" -type f -exec chmod 640 {} \;

# ------------------------------------------------------------
# PHP-FPM pool (panel runs unprivileged as bitpanel)
# ------------------------------------------------------------
log "Configuring dedicated PHP-FPM pool..."
sed -e "s|__BP_USER__|$BP_USER|g" -e "s|__BP_HOME__|$BP_HOME|g" \
  "$SRC/deploy/fpm-pool.conf.tpl" > /etc/php/8.3/fpm/pool.d/bitpanel.conf
systemctl restart php8.3-fpm

# ------------------------------------------------------------
# Nginx vhost for the panel (own port, TLS)
# ------------------------------------------------------------
log "Configuring panel Nginx vhost on port ${PANEL_PORT}..."
[ -f /etc/nginx/snippets/bitpanel-allowlist.conf ] || \
  echo "# no restriction — all IPs allowed" > /etc/nginx/snippets/bitpanel-allowlist.conf
sed -e "s|__PORT__|$PANEL_PORT|g" -e "s|__BP_HOME__|$BP_HOME|g" \
  "$SRC/deploy/nginx-panel.conf.tpl" > /etc/nginx/sites-available/bitpanel.conf
ln -sf /etc/nginx/sites-available/bitpanel.conf /etc/nginx/sites-enabled/bitpanel.conf
nginx -t
systemctl reload nginx

# ------------------------------------------------------------
# Root agent (systemd)
# ------------------------------------------------------------
log "Installing bitpanel-agent daemon..."
cp "$SRC/agent/bitpanel-agent.service" /etc/systemd/system/bitpanel-agent.service
systemctl daemon-reload
systemctl enable --now bitpanel-agent
sleep 1
systemctl is-active --quiet bitpanel-agent || fail "agent failed to start — check: journalctl -u bitpanel-agent"

log "Scheduling metrics collection (every 5 min)..."
echo "*/5 * * * * root /usr/bin/php ${BP_HOME}/panel/bin/metrics-collector.php >> ${BP_HOME}/logs/metrics.log 2>&1" \
  > /etc/cron.d/bitpanel-metrics
chmod 644 /etc/cron.d/bitpanel-metrics

# ------------------------------------------------------------
# Firewall
# ------------------------------------------------------------
if has ufw; then
  log "Configuring UFW (SSH + panel port)..."
  apt-get install -y -qq ufw >/dev/null
  ufw allow OpenSSH >/dev/null
  ufw allow "${PANEL_PORT}/tcp" >/dev/null
  has nginx   && { ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; }
  ufw --force enable >/dev/null
fi

# ------------------------------------------------------------
# Summary
# ------------------------------------------------------------
IP="$(hostname -I | awk '{print $1}')"
# CRED_FILE was written earlier (right after password generation); add the URL now.
sed -i '1i url=https://'"${IP}:${PANEL_PORT}" "$CRED_FILE"
chmod 600 "$CRED_FILE"

echo
echo "=============================================================="
echo "  BitPanel installed"
echo "  URL      : https://${IP}:${PANEL_PORT}   (self-signed cert)"
echo "             On AWS use the PUBLIC IP and open ${PANEL_PORT}/tcp"
echo "             in the Security Group — restrict source to office IP."
echo "  Login    : admin"
echo "  Password : ${ADMIN_PASS}"
echo "  Saved to : ${CRED_FILE}"
echo "  Change the password after first login (Settings)."
echo "=============================================================="
