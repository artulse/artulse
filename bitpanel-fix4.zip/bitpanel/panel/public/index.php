<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

$path   = parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';
$method = (string)($_SERVER['REQUEST_METHOD'] ?? 'GET');

/* Units the UI may act on — mirrors agent allowlist for fast failure. */
const UI_UNITS = [
    'nginx', 'apache2', 'mysql', 'mariadb', 'postgresql',
    'redis-server', 'memcached', 'docker', 'fail2ban', 'ttyd', 'bitpanel-ttyd',
    'php8.1-fpm', 'php8.2-fpm', 'php8.3-fpm',
];

/* Role guard: non-admins may read (GET) but not change anything via /api/*.
   Self-service exceptions: own 2FA enrolment and own password (handled on /settings). */
if ($method === 'POST' && strpos($path, '/api/') === 0
    && !in_array($path, ['/api/2fa/init', '/api/2fa/enable', '/api/2fa/disable'], true)) {
    if (!logged_in() && bearer_principal() === null) {
        json_out(['ok' => false, 'error' => 'unauthenticated'], 401);
    }
    if (!is_admin()) {
        json_out(['ok' => false, 'error' => 'your role is read-only'], 403);
    }
}

/* File manager API lives in its own sub-router. */
if (strpos($path, '/api/fs/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_fs.php';
    exit;
}

/* Sites + SSL API. */
if ($path === '/api/sites' || strpos($path, '/api/sites/') === 0 || $path === '/api/php-versions') {
    require_login_api();
    require dirname(__DIR__) . '/app/api_sites.php';
    exit;
}

/* Databases + Cron API. */
if (strpos($path, '/api/db/') === 0 || strpos($path, '/api/cron/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_dbcron.php';
    exit;
}

/* Firewall + Fail2ban API. */
if (strpos($path, '/api/fw/') === 0 || strpos($path, '/api/f2b/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_firewall.php';
    exit;
}

/* Software / Logs / Docker / System (updates, processes, ports) API. */
if (strpos($path, '/api/soft/') === 0 || strpos($path, '/api/log/') === 0 || strpos($path, '/api/docker/') === 0
    || strpos($path, '/api/sys/') === 0 || strpos($path, '/api/proc/') === 0 || strpos($path, '/api/net/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_system.php';
    exit;
}

/* PHP manager API. */
if (strpos($path, '/api/php/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_php.php';
    exit;
}

/* App daemons (supervisor) API. */
if (strpos($path, '/api/daemon/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_daemons.php';
    exit;
}

/* Backups + S3 + scheduled jobs API. */
if (strpos($path, '/api/backup/') === 0 || strpos($path, '/api/s3/') === 0 || strpos($path, '/api/bkjob/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_backup.php';
    exit;
}

/* FTP + panel users + API tokens (admin). */
if (strpos($path, '/api/ftp/') === 0 || strpos($path, '/api/users/') === 0 || strpos($path, '/api/tokens/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_admin.php';
    exit;
}

/* Mail server API. */
if (strpos($path, '/api/mail/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_mail.php';
    exit;
}

/* Data cleanup API. */
if (strpos($path, '/api/cleanup/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_cleanup.php';
    exit;
}

/* App Store + WP Toolkit API. */
if (strpos($path, '/api/app/') === 0 || strpos($path, '/api/wp/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_apps.php';
    exit;
}

/* Security page API. */
if (strpos($path, '/api/security/') === 0) {
    require_login_api();
    require dirname(__DIR__) . '/app/api_security.php';
    exit;
}

switch (true) {

    /* ---------------- auth ---------------- */

    case $path === '/login' && $method === 'GET':
        if (logged_in()) {
            header('Location: /');
            exit;
        }
        $pend = $_SESSION['pending_2fa'] ?? null;
        if (is_array($pend) && (time() - (int)$pend['ts']) < 300) {
            render('login_2fa', ['error' => null]);
        }
        unset($_SESSION['pending_2fa']);
        render('login', ['error' => null]);

    case $path === '/login' && $method === 'POST':
        $ip = client_ip();
        $st = db()->prepare(
            'SELECT COUNT(*) c FROM login_attempts WHERE ip = ? AND ok = 0 AND ts > ?'
        );
        $st->execute([$ip, time() - 600]);
        if ((int)$st->fetch()['c'] >= 8) {
            render('login', ['error' => 'Too many failed attempts. Try again in 10 minutes.']);
        }

        $u  = trim((string)($_POST['username'] ?? ''));
        $p  = (string)($_POST['password'] ?? '');
        $st = db()->prepare('SELECT * FROM users WHERE username = ?');
        $st->execute([$u]);
        $row = $st->fetch();

        $okLogin = $row && password_verify($p, (string)$row['pass_hash']);
        db()->prepare('INSERT INTO login_attempts (ip, ok, ts) VALUES (?,?,?)')
            ->execute([$ip, $okLogin ? 1 : 0, time()]);

        if (!$okLogin) {
            audit('login.fail', "user={$u}");
            render('login', ['error' => 'Wrong username or password.']);
        }

        // Password correct — require second factor if enrolled.
        if (!empty($row['totp_secret'])) {
            $_SESSION['pending_2fa'] = [
                'uid' => (int)$row['id'], 'uname' => (string)$row['username'], 'ts' => time(),
            ];
            render('login_2fa', ['error' => null]);
        }

        session_regenerate_id(true);
        $_SESSION['uid']   = (int)$row['id'];
        $_SESSION['uname'] = (string)$row['username'];
        $_SESSION['role']  = (string)($row['role'] ?? 'admin');
        audit('login.ok');
        header('Location: /');
        exit;

    case $path === '/login/2fa' && $method === 'POST':
        $pend = $_SESSION['pending_2fa'] ?? null;
        if (!is_array($pend) || (time() - (int)$pend['ts']) >= 300) {
            unset($_SESSION['pending_2fa']);
            header('Location: /login');
            exit;
        }
        $ip = client_ip();
        $st = db()->prepare('SELECT COUNT(*) c FROM login_attempts WHERE ip = ? AND ok = 0 AND ts > ?');
        $st->execute([$ip, time() - 600]);
        if ((int)$st->fetch()['c'] >= 8) {
            render('login_2fa', ['error' => 'Too many attempts. Try again in 10 minutes.']);
        }

        $code = (string)($_POST['code'] ?? '');
        $st = db()->prepare('SELECT totp_secret FROM users WHERE id = ?');
        $st->execute([(int)$pend['uid']]);
        $secret = (string)($st->fetch()['totp_secret'] ?? '');
        $good = Totp::verify($secret, $code);

        db()->prepare('INSERT INTO login_attempts (ip, ok, ts) VALUES (?,?,?)')
            ->execute([$ip, $good ? 1 : 0, time()]);

        if (!$good) {
            audit('login.2fa_fail', 'user=' . $pend['uname']);
            render('login_2fa', ['error' => 'Invalid code.']);
        }

        session_regenerate_id(true);
        $rl = db()->prepare('SELECT role FROM users WHERE id = ?');
        $rl->execute([(int)$pend['uid']]);
        $_SESSION['uid']   = (int)$pend['uid'];
        $_SESSION['uname'] = (string)$pend['uname'];
        $_SESSION['role']  = (string)($rl->fetch()['role'] ?? 'admin');
        unset($_SESSION['pending_2fa']);
        audit('login.2fa_ok');
        header('Location: /');
        exit;

    case $path === '/logout' && $method === 'POST':
        csrf_check();
        audit('logout');
        session_destroy();
        header('Location: /login');
        exit;

    /* ---------------- pages ---------------- */

    case $path === '/' && $method === 'GET':
        require_login_page();
        render('dashboard', ['page' => 'dashboard']);

    case $path === '/files' && $method === 'GET':
        require_login_page();
        render('files', ['page' => 'files', 'scripts' => ['/assets/files.js']]);

    case $path === '/terminal' && $method === 'GET':
        require_login_page();
        render('terminal', ['page' => 'terminal', 'scripts' => ['/assets/terminal.js']]);

    case $path === '/sites' && $method === 'GET':
        require_login_page();
        render('sites', ['page' => 'sites', 'scripts' => ['/assets/sites.js']]);

    case $path === '/databases' && $method === 'GET':
        require_login_page();
        render('databases', ['page' => 'databases', 'scripts' => ['/assets/databases.js']]);

    case $path === '/cron' && $method === 'GET':
        require_login_page();
        render('cron', ['page' => 'cron', 'scripts' => ['/assets/cron.js']]);

    case $path === '/firewall' && $method === 'GET':
        require_login_page();
        render('firewall', ['page' => 'firewall', 'scripts' => ['/assets/firewall.js']]);

    case $path === '/software' && $method === 'GET':
        require_login_page();
        render('software', ['page' => 'software', 'scripts' => ['/assets/software.js']]);

    case $path === '/backups' && $method === 'GET':
        require_login_page();
        render('backups', ['page' => 'backups', 'scripts' => ['/assets/backups.js']]);

    case $path === '/docker' && $method === 'GET':
        require_login_page();
        render('docker', ['page' => 'docker', 'scripts' => ['/assets/docker.js']]);

    case $path === '/logs' && $method === 'GET':
        require_login_page();
        render('logs', ['page' => 'logs', 'scripts' => ['/assets/logs.js']]);

    case $path === '/php' && $method === 'GET':
        require_login_page();
        render('php', ['page' => 'php', 'scripts' => ['/assets/php.js']]);

    case $path === '/daemons' && $method === 'GET':
        require_login_page();
        render('daemons', ['page' => 'daemons', 'scripts' => ['/assets/daemons.js']]);

    case $path === '/system' && $method === 'GET':
        require_login_page();
        render('system', ['page' => 'system', 'scripts' => ['/assets/system.js']]);

    case $path === '/mail' && $method === 'GET':
        require_login_page();
        render('mail', ['page' => 'mail', 'scripts' => ['/assets/mail.js']]);

    case $path === '/cleanup' && $method === 'GET':
        require_login_page();
        render('cleanup', ['page' => 'cleanup', 'scripts' => ['/assets/cleanup.js']]);

    case $path === '/apps' && $method === 'GET':
        require_login_page();
        render('apps', ['page' => 'apps', 'scripts' => ['/assets/apps.js']]);

    case $path === '/wptoolkit' && $method === 'GET':
        require_login_page();
        render('wptoolkit', ['page' => 'wptoolkit', 'scripts' => ['/assets/wptoolkit.js']]);

    case $path === '/security' && $method === 'GET':
        require_login_page();
        if (!is_admin()) { header('Location: /'); exit; }
        render('security', ['page' => 'security', 'scripts' => ['/assets/security.js']]);

    case $path === '/ftp' && $method === 'GET':
        require_login_page();
        render('ftp', ['page' => 'ftp', 'scripts' => ['/assets/ftp.js']]);

    case $path === '/users' && $method === 'GET':
        require_login_page();
        if (!is_admin()) { header('Location: /'); exit; }
        render('users', ['page' => 'users', 'scripts' => ['/assets/users.js']]);

    /* nginx auth_request subrequest gate for the ttyd proxy */
    case $path === '/api/term-auth' && $method === 'GET':
        http_response_code(logged_in() ? 204 : 401);
        exit;

    case $path === '/api/term/status' && $method === 'GET':
        require_login_api();
        json_out(AgentClient::call('term.status'));

    case $path === '/api/term/setup' && $method === 'POST':
        require_login_api();
        csrf_check();
        $res = AgentClient::call('term.setup', [], 360);
        audit('term.setup', !empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err'));
        json_out($res);

    case $path === '/settings' && $method === 'GET':
        require_login_page();
        render('settings', ['page' => 'settings', 'msg' => null, 'err' => null,
                            'scripts' => ['/assets/twofa.js']]);

    case $path === '/settings' && $method === 'POST':
        require_login_page();
        csrf_check();
        $cur = (string)($_POST['current'] ?? '');
        $new = (string)($_POST['new'] ?? '');
        $st  = db()->prepare('SELECT pass_hash FROM users WHERE id = ?');
        $st->execute([(int)$_SESSION['uid']]);
        $row = $st->fetch();

        if (!$row || !password_verify($cur, (string)$row['pass_hash'])) {
            render('settings', ['page' => 'settings', 'msg' => null, 'err' => 'Current password is wrong.', 'scripts' => ['/assets/twofa.js']]);
        }
        if (strlen($new) < 10) {
            render('settings', ['page' => 'settings', 'msg' => null, 'err' => 'New password must be at least 10 characters.', 'scripts' => ['/assets/twofa.js']]);
        }
        db()->prepare('UPDATE users SET pass_hash = ? WHERE id = ?')
            ->execute([password_hash($new, PASSWORD_BCRYPT), (int)$_SESSION['uid']]);
        audit('password.change');
        render('settings', ['page' => 'settings', 'msg' => 'Password updated.', 'err' => null, 'scripts' => ['/assets/twofa.js']]);

    /* ---- two-factor auth (TOTP) ---- */

    case $path === '/api/2fa/status' && $method === 'GET':
        require_login_api();
        $st = db()->prepare('SELECT totp_secret FROM users WHERE id = ?');
        $st->execute([(int)$_SESSION['uid']]);
        json_out(['ok' => true, 'enabled' => !empty($st->fetch()['totp_secret'])]);

    case $path === '/api/2fa/init' && $method === 'POST':
        require_login_api();
        csrf_check();
        $secret = Totp::generateSecret();
        $_SESSION['pending_totp'] = $secret;   // not persisted until confirmed
        json_out(['ok' => true, 'secret' => $secret,
                  'uri' => Totp::uri($secret, (string)($_SESSION['uname'] ?? 'admin'))]);

    case $path === '/api/2fa/enable' && $method === 'POST':
        require_login_api();
        csrf_check();
        $secret = (string)($_SESSION['pending_totp'] ?? '');
        $body   = json_decode((string)file_get_contents('php://input'), true) ?: [];
        if ($secret === '') {
            json_out(['ok' => false, 'error' => 'no enrolment in progress — start again'], 400);
        }
        if (!Totp::verify($secret, (string)($body['code'] ?? ''))) {
            json_out(['ok' => false, 'error' => 'that code did not match — check your app clock and retry']);
        }
        db()->prepare('UPDATE users SET totp_secret = ? WHERE id = ?')
            ->execute([$secret, (int)$_SESSION['uid']]);
        unset($_SESSION['pending_totp']);
        audit('2fa.enable');
        json_out(['ok' => true]);

    case $path === '/api/2fa/disable' && $method === 'POST':
        require_login_api();
        csrf_check();
        $body = json_decode((string)file_get_contents('php://input'), true) ?: [];
        $st = db()->prepare('SELECT totp_secret FROM users WHERE id = ?');
        $st->execute([(int)$_SESSION['uid']]);
        $secret = (string)($st->fetch()['totp_secret'] ?? '');
        if ($secret === '') {
            json_out(['ok' => true]); // already off
        }
        if (!Totp::verify($secret, (string)($body['code'] ?? ''))) {
            json_out(['ok' => false, 'error' => 'enter a current code to turn 2FA off']);
        }
        db()->prepare('UPDATE users SET totp_secret = NULL WHERE id = ?')
            ->execute([(int)$_SESSION['uid']]);
        audit('2fa.disable');
        json_out(['ok' => true]);

    /* ---------------- JSON API ---------------- */

    case $path === '/api/stats' && $method === 'GET':
        require_login_api();
        json_out(AgentClient::call('sys.stats'));

    case $path === '/api/metrics/history' && $method === 'GET':
        require_login_api();
        $range = (string)($_GET['range'] ?? '24h');
        $window = ['24h' => 86400, '7d' => 7 * 86400, '30d' => 30 * 86400][$range] ?? 86400;
        $st = db()->prepare('SELECT ts, cpu, mem_pct, disk_pct FROM metrics WHERE ts >= ? ORDER BY ts');
        $st->execute([time() - $window]);
        json_out(['ok' => true, 'data' => $st->fetchAll()]);

    case $path === '/api/overview' && $method === 'GET':
        require_login_api();
        json_out(AgentClient::call('overview.summary', [], 30));

    case $path === '/api/services' && $method === 'GET':
        require_login_api();
        json_out(AgentClient::call('service.status'));

    case $path === '/api/service' && $method === 'POST':
        require_login_api();
        csrf_check();
        $body   = json_decode((string)file_get_contents('php://input'), true) ?: [];
        $unit   = (string)($body['unit'] ?? '');
        $action = (string)($body['action'] ?? '');
        if (!in_array($unit, UI_UNITS, true)
            || !in_array($action, ['start', 'stop', 'restart', 'reload'], true)) {
            json_out(['ok' => false, 'error' => 'invalid unit or action'], 400);
        }
        $res = AgentClient::call('service.action', ['unit' => $unit, 'action' => $action]);
        audit('service.' . $action, $unit . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    default:
        http_response_code(404);
        echo '404';
        exit;
}
