/* BitPanel users & API tokens */
(function () {
  'use strict';
  if (!document.getElementById('us-table')) return;
  function $(id) { return document.getElementById(id); }

  function loadUsers() {
    BP.get('/api/users/list').then(function (res) {
      var tb = $('us-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'list failed'); return; }
      res.data.forEach(function (u) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(u.username) + '</td>' +
          '<td><span class="bp-state ' + (u.role === 'admin' ? 'ok' : 'mid') + '">' + u.role + '</span></td>' +
          '<td class="bp-sub">' + (u.twofa ? 'on' : 'off') + '</td><td class="text-end"></td>';
        var act = tr.lastElementChild;
        BP.btn(act, u.role === 'admin' ? 'make viewer' : 'make admin', function () { setRole(u); });
        BP.btn(act, 'password', function () { pw(u); });
        BP.btn(act, 'delete', function () { del(u); });
        tb.appendChild(tr);
      });
    }).catch(function () { BP.err('Request failed.'); });
  }

  $('us-create').addEventListener('click', function () {
    var name = $('us-name').value.trim(), pass = $('us-pass').value;
    if (!name || !pass) { BP.err('Username and password are required.'); return; }
    BP.post('/api/users/create', { username: name, password: pass, role: $('us-role').value }).then(function (r) {
      if (r.ok) { BP.ok('User created.'); $('us-name').value = ''; $('us-pass').value = ''; loadUsers(); } else BP.err(r.error || 'create failed');
    });
  });
  function setRole(u) { var role = u.role === 'admin' ? 'viewer' : 'admin';
    BP.post('/api/users/role', { id: u.id, role: role }).then(function (r) { if (r.ok) { BP.ok('Role updated.'); loadUsers(); } else BP.err(r.error || 'failed'); }); }
  function pw(u) { var p = prompt('New password for ' + u.username + ' (min 10):'); if (!p) return;
    BP.post('/api/users/password', { id: u.id, password: p }).then(function (r) { if (r.ok) BP.ok('Password changed.'); else BP.err(r.error || 'failed'); }); }
  function del(u) { if (!confirm('Delete panel user ' + u.username + '?')) return;
    BP.post('/api/users/delete', { id: u.id }).then(function (r) { if (r.ok) { BP.ok('Deleted.'); loadUsers(); } else BP.err(r.error || 'failed'); }); }

  /* tokens */
  function loadTokens() {
    BP.get('/api/tokens/list').then(function (res) {
      var tb = $('tk-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok || !res.data.length) { tb.innerHTML = '<tr><td colspan="4" class="text-muted">No tokens.</td></tr>'; return; }
      res.data.forEach(function (t) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(t.label) + '</td><td class="bp-sub">' + BP.date(t.created_at) + '</td>' +
          '<td class="bp-sub">' + (t.last_used ? BP.date(t.last_used) : 'never') + '</td><td class="text-end"></td>';
        BP.btn(tr.lastElementChild, 'revoke', function () { revoke(t); });
        tb.appendChild(tr);
      });
    });
  }
  $('tk-create').addEventListener('click', function () {
    var label = $('tk-label').value.trim();
    if (!label) { BP.err('Enter a label.'); return; }
    BP.post('/api/tokens/create', { label: label }).then(function (r) {
      if (!r.ok) { BP.err(r.error || 'create failed'); return; }
      var box = $('tk-new');
      box.textContent = 'Copy this token now — it is shown only once: ' + r.token;
      box.classList.remove('d-none');
      $('tk-label').value = '';
      loadTokens();
    });
  });
  function revoke(t) { if (!confirm('Revoke token "' + t.label + '"? Any client using it will stop working.')) return;
    BP.post('/api/tokens/delete', { id: t.id }).then(function (r) { if (r.ok) { BP.ok('Revoked.'); loadTokens(); } else BP.err(r.error || 'failed'); }); }

  loadUsers();
  loadTokens();
})();
