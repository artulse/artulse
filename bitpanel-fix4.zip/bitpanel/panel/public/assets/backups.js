/* BitPanel backups */
(function () {
  'use strict';
  if (!document.getElementById('bk-table')) return;

  function $(id) { return document.getElementById(id); }

  function syncType() {
    var t = $('bk-type').value;
    $('bk-path').classList.toggle('d-none', t === 'site' || t === 'db');
    $('bk-target').classList.toggle('d-none', t === 'path');
    if (t === 'site') fillTargets('/api/sites', 'site');
    else if (t === 'db') fillTargets('/api/db/list', 'db');
  }
  $('bk-type').addEventListener('change', syncType);

  function fillTargets(url, kind) {
    BP.get(url).then(function (res) {
      var sel = $('bk-target'); sel.innerHTML = '';
      var list = res.ok ? res.data : [];
      list.forEach(function (x) {
        var val = kind === 'site' ? x.id : x.name;
        var o = document.createElement('option'); o.value = val; o.textContent = val; sel.appendChild(o);
      });
      if (!list.length) sel.innerHTML = '<option value="">— none —</option>';
    }).catch(function () {});
  }

  $('bk-create').addEventListener('click', function () {
    var t = $('bk-type').value;
    var target = t === 'path' ? $('bk-path').value.trim() : $('bk-target').value;
    if (!target) { BP.err('Choose or enter a target.'); return; }
    BP.ok('Creating backup…');
    BP.post('/api/backup/create', { type: t, target: target }).then(function (r) {
      if (r.ok) { BP.ok('Backup created: ' + r.data.name); load(); } else BP.err(r.error || 'backup failed');
    }).catch(function () { BP.err('Request failed.'); });
  });

  function load() {
    BP.get('/api/backup/list').then(function (res) {
      var tb = $('bk-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'list failed'); return; }
      $('bk-count').textContent = res.data.length + ' backup' + (res.data.length === 1 ? '' : 's');
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="5" class="text-muted">No backups yet.</td></tr>'; return; }
      res.data.forEach(function (b) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit st-target" title="' + BP.esc(b.name) + '">' + BP.esc(b.name) + '</td>' +
          '<td class="bp-sub">' + b.type + '</td><td class="bp-sub">' + BP.bytes(b.size) + '</td>' +
          '<td class="bp-sub">' + BP.date(b.mtime) + '</td><td class="text-end"></td>';
        var act = tr.lastElementChild;
        BP.btn(act, 'download', function () { location.href = '/api/fs/download?path=' + encodeURIComponent(b.path); });
        BP.btn(act, 'S3', function () { pushS3(b.name); });
        BP.btn(act, 'delete', function () { del(b.name); });
        tb.appendChild(tr);
      });
    });
  }

  function del(name) {
    if (!confirm('Delete backup ' + name + '?')) return;
    BP.post('/api/backup/delete', { name: name }).then(function (r) { if (r.ok) { BP.ok('Deleted.'); load(); } else BP.err(r.error || 'delete failed'); });
  }
  function pushS3(name) {
    BP.ok('Uploading ' + name + ' to S3…');
    BP.post('/api/s3/push', { name: name }).then(function (r) { if (r.ok) BP.ok(r.data || 'uploaded'); else BP.err(r.error || 'upload failed'); });
  }

  /* S3 config */
  function loadS3() {
    BP.get('/api/s3/get').then(function (res) {
      if (!res.ok) return;
      var d = res.data;
      if (d.configured) {
        $('bk-s3-state').textContent = 'Configured — bucket ' + d.bucket + ' (' + d.region + '), key ' + d.access_key;
        $('s3-bucket').value = d.bucket; $('s3-region').value = d.region; $('s3-prefix').value = d.prefix || '';
      } else {
        $('bk-s3-state').textContent = 'Not configured. Uploads to S3 are disabled until you save settings.';
      }
    }).catch(function () {});
  }
  $('s3-save').addEventListener('click', function () {
    BP.post('/api/s3/set', { bucket: $('s3-bucket').value.trim(), region: $('s3-region').value.trim(),
      prefix: $('s3-prefix').value.trim(), access_key: $('s3-ak').value.trim(), secret_key: $('s3-sk').value })
      .then(function (r) { if (r.ok) { BP.ok('S3 settings saved.'); $('s3-ak').value = ''; $('s3-sk').value = ''; loadS3(); } else BP.err(r.error || 'save failed'); });
  });

  syncType();
  load();
  loadS3();

  /* ---- scheduled jobs ---- */
  function bjSync() {
    var t = document.getElementById('bj-type').value;
    document.getElementById('bj-path').classList.toggle('d-none', t === 'site' || t === 'db');
    document.getElementById('bj-target').classList.toggle('d-none', t === 'path');
    if (t === 'site') bjFill('/api/sites', 'site');
    else if (t === 'db') bjFill('/api/db/list', 'db');
  }
  function bjFill(url, kind) {
    BP.get(url).then(function (res) {
      var sel = document.getElementById('bj-target'); sel.innerHTML = '';
      (res.ok ? res.data : []).forEach(function (x) { var v = kind === 'site' ? x.id : x.name; var o = document.createElement('option'); o.value = v; o.textContent = v; sel.appendChild(o); });
      if (!sel.options.length) sel.innerHTML = '<option value="">— none —</option>';
    }).catch(function () {});
  }
  document.getElementById('bj-type').addEventListener('change', bjSync);
  document.getElementById('bj-create').addEventListener('click', function () {
    var t = document.getElementById('bj-type').value;
    var target = t === 'path' ? document.getElementById('bj-path').value.trim() : document.getElementById('bj-target').value;
    var sched = document.getElementById('bj-sched').value.trim();
    if (!target || !sched) { BP.err('Target and schedule are required.'); return; }
    BP.post('/api/bkjob/create', { type: t, target: target, schedule: sched,
      keep: parseInt(document.getElementById('bj-keep').value, 10) || 7, s3: document.getElementById('bj-s3').checked })
      .then(function (r) { if (r.ok) { BP.ok('Scheduled job added.'); loadJobs(); } else BP.err(r.error || 'failed'); });
  });
  function loadJobs() {
    BP.get('/api/bkjob/list').then(function (res) {
      var tb = document.getElementById('bj-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok || !res.data.length) { tb.innerHTML = '<tr><td colspan="5" class="text-muted">No scheduled jobs.</td></tr>'; return; }
      res.data.forEach(function (j) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(j.type + ': ' + j.target) + '</td><td class="bp-sub">' + BP.esc(j.schedule) + '</td>' +
          '<td class="bp-sub">' + j.keep + '</td><td class="bp-sub">' + (j.s3 ? 'yes' : 'no') + '</td><td class="text-end"></td>';
        BP.btn(tr.lastElementChild, 'delete', function () {
          if (!confirm('Delete scheduled job ' + j.id + '? Existing archives are kept.')) return;
          BP.post('/api/bkjob/delete', { id: j.id }).then(function (r) { if (r.ok) { BP.ok('Deleted.'); loadJobs(); } else BP.err(r.error || 'failed'); });
        });
        tb.appendChild(tr);
      });
    });
  }
  bjSync();
  loadJobs();
})();
