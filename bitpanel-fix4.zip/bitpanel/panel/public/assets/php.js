/* BitPanel PHP manager */
(function () {
  'use strict';
  if (!document.getElementById('ph-ver')) return;
  function $(id) { return document.getElementById(id); }

  var KEYS = ['memory_limit', 'upload_max_filesize', 'post_max_size', 'max_execution_time',
              'max_input_time', 'max_input_vars', 'display_errors', 'date.timezone'];

  function loadVersions() {
    BP.get('/api/php/versions').then(function (res) {
      var sel = $('ph-ver'); sel.innerHTML = '';
      if (!res.ok || !res.data.length) { sel.innerHTML = '<option value="">none installed</option>'; BP.err('No PHP-FPM versions installed. Add one from Software.'); return; }
      res.data.forEach(function (v) { var o = document.createElement('option'); o.value = v.version; o.textContent = 'PHP ' + v.version; sel.appendChild(o); });
      loadAll();
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  function ver() { return $('ph-ver').value; }

  function loadAll() { if (!ver()) return; $('ph-wrap').classList.remove('d-none'); loadSettings(); loadExt(); }
  $('ph-ver').addEventListener('change', loadAll);

  function loadSettings() {
    BP.get('/api/php/settings?version=' + encodeURIComponent(ver())).then(function (res) {
      if (!res.ok) { BP.err(res.error || 'load failed'); return; }
      var wrap = $('ph-settings'); wrap.innerHTML = '';
      KEYS.forEach(function (k) {
        var row = document.createElement('div'); row.className = 'st-row';
        var val = res.data.values[k] || '';
        if (k === 'display_errors') {
          row.innerHTML = '<label>' + k + '</label><select class="form-select" data-k="' + k + '" style="max-width:120px"><option>Off</option><option>On</option></select>';
          wrap.appendChild(row); row.querySelector('select').value = (val === '1' || val === 'On') ? 'On' : 'Off';
        } else {
          row.innerHTML = '<label>' + k + '</label><input class="form-control" data-k="' + k + '" style="max-width:200px;font-family:var(--bp-mono)">';
          wrap.appendChild(row); row.querySelector('input').value = val;
        }
      });
    });
  }

  $('ph-save').addEventListener('click', function () {
    var values = {};
    $('ph-settings').querySelectorAll('[data-k]').forEach(function (el) { values[el.getAttribute('data-k')] = el.value.trim(); });
    BP.post('/api/php/settings', { version: ver(), values: values }).then(function (r) {
      if (r.ok) BP.ok('Saved · FPM restarted.'); else BP.err(r.error || 'save failed');
    });
  });

  function loadExt() {
    BP.get('/api/php/extensions?version=' + encodeURIComponent(ver())).then(function (res) {
      var wrap = $('ph-ext'); wrap.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'ext load failed'); return; }
      res.data.forEach(function (e) {
        var chip = document.createElement('div');
        chip.className = 'ph-chip ' + (e.enabled ? 'on' : '');
        chip.innerHTML = '<span>' + BP.esc(e.ext) + '</span>';
        var b = document.createElement('button'); b.className = 'bp-act'; b.textContent = e.enabled ? 'remove' : 'install';
        b.addEventListener('click', function () { toggle(e.ext, !e.enabled); });
        chip.appendChild(b); wrap.appendChild(chip);
      });
    });
  }
  function toggle(ext, enable) {
    BP.ok((enable ? 'Installing ' : 'Removing ') + ext + '…');
    BP.post('/api/php/ext-toggle', { version: ver(), ext: ext, enable: enable }).then(function (r) {
      if (r.ok) BP.ok(r.data || 'done'); else BP.err(r.error || 'failed'); loadExt();
    });
  }

  loadVersions();
})();
