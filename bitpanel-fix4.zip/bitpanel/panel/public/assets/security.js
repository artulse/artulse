/* BitPanel security */
(function () {
  'use strict';
  if (!document.getElementById('sc-allow-table')) return;
  function $(id) { return document.getElementById(id); }

  var allowlist = [];

  function load() {
    BP.get('/api/security/get').then(function (res) {
      if (!res.ok) { BP.err(res.error || 'load failed'); return; }
      var d = res.data;
      $('sc-port').textContent = d.ssh_port;
      $('sc-port-input').value = '';

      var rootOn = d.root_login !== 'no';
      $('sc-root-state').textContent = rootOn ? 'root login: allowed' : 'root login: disabled';
      $('sc-root-state').className = 'bp-state ' + (rootOn ? 'mid' : 'ok');

      $('sc-ping-state').textContent = d.ping_disabled ? 'ping disabled' : 'ping enabled';
      $('sc-ping-state').className = 'bp-state ' + (d.ping_disabled ? 'ok' : 'mid');

      allowlist = d.panel_allowlist || [];
      renderAllow();
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  function renderAllow() {
    var tb = $('sc-allow-table').tBodies[0]; tb.innerHTML = '';
    if (!allowlist.length) { tb.innerHTML = '<tr><td colspan="2" class="text-muted">No restriction — all IPs can reach the panel.</td></tr>'; return; }
    allowlist.forEach(function (ip, i) {
      var tr = document.createElement('tr');
      tr.innerHTML = '<td class="bp-unit">' + BP.esc(ip) + '</td><td class="text-end"></td>';
      BP.btn(tr.lastElementChild, 'remove', function () { allowlist.splice(i, 1); renderAllow(); });
      tb.appendChild(tr);
    });
  }

  $('sc-port-save').addEventListener('click', function () {
    var port = parseInt($('sc-port-input').value, 10);
    if (!port || port < 1 || port > 65535) { BP.err('Enter a valid port number.'); return; }
    if (!confirm('Change SSH to port ' + port + '?\n\nThe new port opens in UFW first, then sshd restarts. Test a NEW terminal on the new port before closing this one.')) return;
    BP.post('/api/security/ssh-port', { port: port }).then(function (r) {
      if (r.ok) BP.ok(r.data); else BP.err(r.error || 'change failed');
      load();
    });
  });

  $('sc-root-toggle').addEventListener('click', function () {
    var currentlyOn = $('sc-root-state').textContent.indexOf('allowed') !== -1;
    var next = !currentlyOn;
    if (!confirm((next ? 'Allow' : 'Disable') + ' root SSH login?' + (next ? '' : '\n\nMake sure another sudo-capable user can log in first.'))) return;
    BP.post('/api/security/root-login', { enabled: next }).then(function (r) {
      if (r.ok) BP.ok(r.data); else BP.err(r.error || 'change failed');
      load();
    });
  });

  $('sc-ping-toggle').addEventListener('click', function () {
    var currentlyDisabled = $('sc-ping-state').textContent.indexOf('disabled') !== -1;
    BP.post('/api/security/ping', { disabled: !currentlyDisabled }).then(function (r) {
      if (r.ok) BP.ok(r.data); else BP.err(r.error || 'change failed');
      load();
    });
  });

  $('sc-allow-add').addEventListener('click', function () {
    var ip = $('sc-allow-input').value.trim();
    if (!ip) return;
    if (allowlist.indexOf(ip) === -1) allowlist.push(ip);
    $('sc-allow-input').value = '';
    renderAllow();
  });

  $('sc-allow-save').addEventListener('click', function () {
    if (allowlist.length && !confirm('Save this allowlist? Only these IPs (' + allowlist.join(', ') + ') will be able to reach the panel.')) return;
    BP.post('/api/security/allowlist', { ips: allowlist }).then(function (r) {
      if (r.ok) BP.ok('Allowlist saved.'); else BP.err(r.error || 'save failed — your own IP must be in the list');
      load();
    });
  });

  load();
})();
