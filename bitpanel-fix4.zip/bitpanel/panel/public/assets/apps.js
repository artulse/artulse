/* BitPanel app store */
(function () {
  'use strict';
  if (!document.getElementById('as-cards')) return;
  function $(id) { return document.getElementById(id); }

  var phpSites = [];

  function loadSites() {
    return BP.get('/api/sites').then(function (res) {
      phpSites = res.ok ? res.data.filter(function (s) { return s.type === 'php'; }) : [];
    });
  }

  function fillSiteSelect(sel) {
    sel.innerHTML = '';
    if (!phpSites.length) { sel.innerHTML = '<option value="">no PHP sites — create one first</option>'; return; }
    phpSites.forEach(function (s) {
      var o = document.createElement('option'); o.value = s.id; o.textContent = s.domains[0]; sel.appendChild(o);
    });
  }

  function render(cat) {
    var wrap = $('as-cards'); wrap.innerHTML = '';
    if (!cat.wp_cli) {
      var note = document.createElement('div');
      note.className = 'alert alert-info py-2';
      note.textContent = 'WP-CLI will be downloaded automatically the first time you install WordPress or open WP Toolkit.';
      wrap.appendChild(note);
    }
    cat.apps.forEach(function (a) {
      var card = document.createElement('div');
      card.className = 'bp-panel as-card';
      card.innerHTML = '<div class="bp-panel-title">' + BP.esc(a.name) + '</div><p class="bp-sub">' + BP.esc(a.desc) + '</p>';
      var btn = document.createElement('button'); btn.className = 'btn bp-btn'; btn.textContent = 'Install';
      btn.addEventListener('click', function () { openForm(a.key); });
      card.appendChild(btn);
      wrap.appendChild(card);
    });
  }

  function openForm(key) {
    $('as-wp-form').classList.add('d-none');
    $('as-pma-form').classList.add('d-none');
    if (key === 'wordpress') { fillSiteSelect($('wp-site')); $('as-wp-form').classList.remove('d-none'); }
    else if (key === 'phpmyadmin') { fillSiteSelect($('pma-site')); $('as-pma-form').classList.remove('d-none'); }
  }
  $('wp-cancel').addEventListener('click', function () { $('as-wp-form').classList.add('d-none'); });
  $('pma-cancel').addEventListener('click', function () { $('as-pma-form').classList.add('d-none'); });

  $('wp-install').addEventListener('click', function () {
    var site = $('wp-site').value, title = $('wp-title').value.trim(),
        user = $('wp-user').value.trim(), email = $('wp-email').value.trim();
    if (!site || !title || !user || !email) { BP.err('All fields are required.'); return; }
    BP.ok('Installing WordPress… downloads core + sets up the database, can take a minute.');
    BP.post('/api/app/wordpress', { site_id: site, title: title, admin_user: user, admin_email: email }).then(function (r) {
      if (r.ok) {
        BP.ok('WordPress installed.\nURL: ' + r.data.url + '\nAdmin: ' + r.data.admin_user + ' / ' + r.data.admin_password
          + '\n(save this password — it will not be shown again)');
        $('as-wp-form').classList.add('d-none');
      } else BP.err(r.error || 'install failed');
    }).catch(function () { BP.err('Install request failed.'); });
  });

  $('pma-install').addEventListener('click', function () {
    var site = $('pma-site').value;
    if (!site) { BP.err('Choose a site.'); return; }
    BP.ok('Installing phpMyAdmin…');
    BP.post('/api/app/phpmyadmin', { site_id: site }).then(function (r) {
      if (r.ok) { BP.ok(r.data); $('as-pma-form').classList.add('d-none'); } else BP.err(r.error || 'install failed');
    }).catch(function () { BP.err('Install request failed.'); });
  });

  loadSites().then(function () {
    BP.get('/api/app/catalog').then(function (res) {
      if (res.ok) render(res.data); else BP.err(res.error || 'catalog failed');
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  });
})();
