/* BitPanel 2FA (settings) */
(function () {
  'use strict';
  if (!document.getElementById('tf-start')) return;

  function $(id) { return document.getElementById(id); }
  function post(u, b) {
    return fetch(u, { method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF': window.BP_CSRF },
      body: JSON.stringify(b || {}) }).then(function (r) {
      if (r.status === 401) { location.href = '/login'; throw new Error('auth'); }
      return r.json();
    });
  }
  function err(m) { var b = $('tf-error'); if (m) { b.textContent = m; b.classList.remove('d-none'); } else b.classList.add('d-none'); }
  function ok(m) { var b = $('tf-ok'); if (m) { b.textContent = m; b.classList.remove('d-none'); setTimeout(function () { b.classList.add('d-none'); }, 4000); } else b.classList.add('d-none'); }

  function showState(enabled) {
    $('tf-on').classList.toggle('d-none', !enabled);
    $('tf-off').classList.toggle('d-none', enabled);
    $('tf-enroll').classList.add('d-none');
  }

  fetch('/api/2fa/status').then(function (r) { return r.json(); })
    .then(function (res) { if (res.ok) showState(res.enabled); })
    .catch(function () {});

  $('tf-start').addEventListener('click', function () {
    err(''); ok('');
    post('/api/2fa/init', {}).then(function (res) {
      if (!res.ok) { err(res.error || 'could not start enrolment'); return; }
      $('tf-off').classList.add('d-none');
      $('tf-enroll').classList.remove('d-none');
      $('tf-secret').textContent = res.secret;
      var box = $('tf-qr'); box.innerHTML = '';
      if (typeof QRCode !== 'undefined') {
        new QRCode(box, { text: res.uri, width: 176, height: 176, correctLevel: QRCode.CorrectLevel.M });
      } else {
        box.innerHTML = '<span class="bp-sub">QR unavailable offline — enter the secret manually.</span>';
      }
      $('tf-verify-code').focus();
    }).catch(function () { err('Request failed.'); });
  });

  $('tf-confirm').addEventListener('click', function () {
    var code = $('tf-verify-code').value.trim();
    if (code.length < 6) { err('Enter the 6-digit code.'); return; }
    post('/api/2fa/enable', { code: code }).then(function (res) {
      if (res.ok) { showState(true); ok('Two-factor authentication is now on.'); }
      else err(res.error || 'verification failed');
    });
  });

  $('tf-disable').addEventListener('click', function () {
    var code = $('tf-off-code').value.trim();
    if (code.length < 6) { err('Enter a current code to disable.'); return; }
    post('/api/2fa/disable', { code: code }).then(function (res) {
      if (res.ok) { showState(false); ok('Two-factor authentication disabled.'); }
      else err(res.error || 'could not disable');
    });
  });
})();
