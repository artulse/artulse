/* BitPanel shared helpers */
(function () {
  'use strict';
  function handle(r) {
    if (r.status === 401) { location.href = '/login'; throw new Error('auth'); }
    return r.json();
  }
  function box(id, msg, isOk) {
    var el = document.getElementById(id);
    if (!el) return;
    if (msg) { el.textContent = msg; el.classList.remove('d-none'); if (isOk) setTimeout(function () { el.classList.add('d-none'); }, 4000); }
    else el.classList.add('d-none');
  }
  window.BP = {
    get: function (u) { return fetch(u).then(handle); },
    post: function (u, b) {
      return fetch(u, { method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF': window.BP_CSRF },
        body: JSON.stringify(b || {}) }).then(handle);
    },
    err: function (m) { box('bp-error', m, false); },
    ok: function (m) { box('bp-ok', m, true); },
    esc: function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); },
    bytes: function (b) { if (!isFinite(b) || b < 0) b = 0; var u = ['B', 'KB', 'MB', 'GB', 'TB'], i = 0;
      while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; } return b.toFixed(b >= 100 || i === 0 ? 0 : 1) + ' ' + u[i]; },
    date: function (ts) { if (!ts) return '—'; var d = new Date(ts * 1000); function p(n) { return (n < 10 ? '0' : '') + n; }
      return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()); },
    btn: function (cell, label, fn) { var b = document.createElement('button'); b.className = 'bp-act'; b.textContent = label; b.addEventListener('click', fn); cell.appendChild(b); return b; }
  };
})();
