/* BitPanel system tools */
(function () {
  'use strict';
  if (!document.getElementById('sy-proc')) return;
  function $(id) { return document.getElementById(id); }

  function updates() {
    $('sy-upcount').textContent = 'checking…';
    BP.get('/api/sys/updates').then(function (res) {
      var tb = $('sy-uptable').tBodies[0]; tb.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'update check failed'); $('sy-upcount').textContent = ''; return; }
      $('sy-upcount').textContent = res.data.count + ' upgradable';
      if (!res.data.packages.length) { tb.innerHTML = '<tr><td colspan="3" class="text-muted">System is up to date.</td></tr>'; return; }
      res.data.packages.forEach(function (p) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(p.pkg) + '</td><td class="bp-sub">' + BP.esc(p.old) + '</td><td class="bp-sub">' + BP.esc(p.new) + '</td>';
        tb.appendChild(tr);
      });
    }).catch(function () { BP.err('Panel could not reach the agent.'); $('sy-upcount').textContent = ''; });
  }
  $('sy-refresh').addEventListener('click', updates);
  $('sy-upgrade').addEventListener('click', function () {
    if (!confirm('Run apt-get upgrade now? This can take a while and may restart services.')) return;
    BP.ok('Upgrading… this may take several minutes.');
    BP.post('/api/sys/upgrade', {}).then(function (r) { if (r.ok) { BP.ok('Upgrade finished.'); updates(); } else BP.err(r.error || 'upgrade failed'); });
  });

  function procs() {
    BP.get('/api/proc/top?sort=' + $('sy-sort').value).then(function (res) {
      var tb = $('sy-proc').tBodies[0]; tb.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'proc failed'); return; }
      res.data.forEach(function (p) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-sub">' + p.pid + '</td><td class="bp-sub">' + BP.esc(p.user) + '</td>' +
          '<td class="bp-sub">' + p.cpu.toFixed(1) + '</td><td class="bp-sub">' + p.mem.toFixed(1) + '</td>' +
          '<td class="bp-sub">' + BP.bytes(p.rss) + '</td><td class="bp-unit st-target">' + BP.esc(p.command) + '</td><td class="text-end"></td>';
        BP.btn(tr.lastElementChild, 'kill', function () { kill(p); });
        tb.appendChild(tr);
      });
    });
  }
  $('sy-sort').addEventListener('change', procs);
  $('sy-procrefresh').addEventListener('click', procs);
  function kill(p) {
    if (!confirm('Send SIGTERM to PID ' + p.pid + ' (' + p.command + ')?')) return;
    BP.post('/api/proc/kill', { pid: p.pid, signal: 'TERM' }).then(function (r) { if (r.ok) BP.ok(r.data); else BP.err(r.error || 'kill failed'); procs(); });
  }

  function ports() {
    BP.get('/api/net/listening').then(function (res) {
      var tb = $('sy-ports').tBodies[0]; tb.innerHTML = '';
      if (!res.ok || !res.data.length) { tb.innerHTML = '<tr><td colspan="3" class="text-muted">none</td></tr>'; return; }
      res.data.forEach(function (l) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-sub">' + BP.esc(l.proto) + '</td><td class="bp-unit">' + BP.esc(l.local) + '</td><td class="bp-sub">' + BP.esc(l.process || '—') + '</td>';
        tb.appendChild(tr);
      });
    });
  }

  procs(); ports();
})();
