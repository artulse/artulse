/* BitPanel app daemons */
(function () {
  'use strict';
  if (!document.getElementById('dm-table')) return;
  function $(id) { return document.getElementById(id); }

  function load() {
    BP.get('/api/daemon/list').then(function (res) {
      var tb = $('dm-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'list failed'); return; }
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="4" class="text-muted">No daemons yet.</td></tr>'; return; }
      res.data.forEach(function (d) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(d.name) + '</td>' +
          '<td class="bp-sub st-target" title="' + BP.esc(d.command) + '">' + BP.esc(d.command) + '</td>' +
          '<td><span class="bp-state ' + (d.active ? 'ok' : 'bad') + '">' + BP.esc(d.sub) + '</span></td>' +
          '<td class="text-end"></td>';
        var act = tr.lastElementChild;
        BP.btn(act, 'logs', function () { logs(d); });
        if (d.active) { BP.btn(act, 'restart', function () { action(d, 'restart'); }); BP.btn(act, 'stop', function () { action(d, 'stop'); }); }
        else { BP.btn(act, 'start', function () { action(d, 'start'); }); }
        BP.btn(act, 'delete', function () { del(d); });
        tb.appendChild(tr);
      });
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  $('dm-create').addEventListener('click', function () {
    var name = $('dm-name').value.trim(), cmd = $('dm-cmd').value.trim();
    if (!name || !cmd) { BP.err('Name and command are required.'); return; }
    BP.ok('Creating daemon…');
    BP.post('/api/daemon/create', { name: name, command: cmd, dir: $('dm-dir').value.trim(),
      user: $('dm-user').value.trim() || 'www-data', autostart: $('dm-auto').checked }).then(function (r) {
      if (r.ok) { BP.ok('Daemon created and started.'); $('dm-name').value = ''; $('dm-cmd').value = ''; $('dm-dir').value = ''; load(); }
      else BP.err(r.error || 'create failed');
    });
  });

  function action(d, act) {
    if (act === 'stop' && !confirm('Stop ' + d.name + '?')) return;
    BP.post('/api/daemon/action', { name: d.name, action: act }).then(function (r) { if (!r.ok) BP.err(r.error || 'action failed'); load(); });
  }
  function del(d) {
    if (!confirm('Delete daemon ' + d.name + '? It will be stopped and its service removed.')) return;
    BP.post('/api/daemon/delete', { name: d.name }).then(function (r) { if (r.ok) { BP.ok('Deleted.'); load(); } else BP.err(r.error || 'delete failed'); });
  }
  function logs(d) {
    $('dm-logname').textContent = d.name; $('dm-logtext').textContent = 'Loading…'; $('dm-logwrap').classList.remove('d-none');
    BP.get('/api/daemon/logs?name=' + encodeURIComponent(d.name) + '&lines=200').then(function (r) {
      $('dm-logtext').textContent = r.ok ? (r.data.text || '(no logs)') : (r.error || 'logs failed');
      var el = $('dm-logtext'); el.scrollTop = el.scrollHeight;
    });
  }
  $('dm-logclose').addEventListener('click', function () { $('dm-logwrap').classList.add('d-none'); });

  load();
})();
