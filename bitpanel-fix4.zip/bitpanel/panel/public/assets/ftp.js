/* BitPanel FTP */
(function () {
  'use strict';
  if (!document.getElementById('ftp-table')) return;
  function $(id) { return document.getElementById(id); }

  function status() {
    BP.get('/api/ftp/status').then(function (res) {
      if (!res.ok) { BP.err(res.error || 'status failed'); return; }
      var d = res.data;
      $('ftp-state').textContent = !d.installed ? 'not installed' : (d.active ? 'running' : 'stopped');
      $('ftp-state').className = 'bp-state ' + (!d.installed ? 'mid' : (d.active ? 'ok' : 'bad'));
      $('ftp-summary').textContent = d.installed ? ('vsftpd · passive ' + d.pasv) : 'vsftpd not installed';
      $('ftp-wrap').classList.toggle('d-none', !(d.installed && d.active));
      if (d.installed && d.active) loadUsers();
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  $('ftp-setup').addEventListener('click', function () {
    if (!confirm('Install and/or (re)configure vsftpd now?')) return;
    BP.ok('Setting up vsftpd…');
    BP.post('/api/ftp/setup', {}).then(function (r) { if (r.ok) BP.ok('vsftpd ready.'); else BP.err(r.error || 'setup failed'); status(); });
  });

  function loadUsers() {
    BP.get('/api/ftp/users').then(function (res) {
      var tb = $('ftp-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok || !res.data.length) { tb.innerHTML = '<tr><td colspan="3" class="text-muted">No FTP accounts.</td></tr>'; return; }
      res.data.forEach(function (u) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(u.user) + '</td><td class="bp-sub st-target">' + BP.esc(u.home) + '</td><td class="text-end"></td>';
        var act = tr.lastElementChild;
        BP.btn(act, 'password', function () { pw(u.user); });
        BP.btn(act, 'delete', function () { del(u.user); });
        tb.appendChild(tr);
      });
    });
  }

  $('ftp-add').addEventListener('click', function () {
    var user = $('ftp-user').value.trim(), pass = $('ftp-pass').value;
    if (!user || !pass) { BP.err('Username and password are required.'); return; }
    BP.post('/api/ftp/add', { user: user, password: pass, dir: $('ftp-dir').value.trim() }).then(function (r) {
      if (r.ok) { BP.ok('FTP account created.'); $('ftp-user').value = ''; $('ftp-pass').value = ''; $('ftp-dir').value = ''; loadUsers(); }
      else BP.err(r.error || 'create failed');
    });
  });
  function del(user) { if (!confirm('Delete FTP account ' + user + '? (home directory is kept)')) return;
    BP.post('/api/ftp/delete', { user: user }).then(function (r) { if (r.ok) { BP.ok(r.data || 'deleted'); loadUsers(); } else BP.err(r.error || 'delete failed'); }); }
  function pw(user) { var p = prompt('New FTP password for ' + user + ':'); if (!p) return;
    BP.post('/api/ftp/password', { user: user, password: p }).then(function (r) { if (r.ok) BP.ok('Password changed.'); else BP.err(r.error || 'change failed'); }); }

  status();
})();
