/* BitPanel WP Toolkit */
(function () {
  'use strict';
  if (!document.getElementById('wpt-table')) return;
  function $(id) { return document.getElementById(id); }

  function load() {
    var tb = $('wpt-table').tBodies[0];
    tb.innerHTML = '<tr><td colspan="4" class="text-muted">Scanning…</td></tr>';
    BP.get('/api/wp/list').then(function (res) {
      tb.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'scan failed'); tb.innerHTML = '<tr><td colspan="4" class="text-muted">Scan failed.</td></tr>'; return; }
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="4" class="text-muted">No WordPress sites detected.</td></tr>'; return; }
      res.data.forEach(function (w) {
        var tr = document.createElement('tr');
        var total = w.core_updates + w.plugin_updates + w.theme_updates;
        var upd = total
          ? '<span class="bp-state bad">' + w.core_updates + ' core · ' + w.plugin_updates + ' plugin · ' + w.theme_updates + ' theme</span>'
          : '<span class="bp-state ok">up to date</span>';
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(w.domain) + '</td><td class="bp-sub">' + BP.esc(w.version) + '</td>' +
          '<td>' + upd + '</td><td class="text-end"></td>';
        var act = tr.lastElementChild;
        if (w.core_updates) BP.btn(act, 'update core', function () { run('/api/wp/core-update', w, 'Updating core…'); });
        if (w.plugin_updates) BP.btn(act, 'update plugins', function () { run('/api/wp/plugins-update', w, 'Updating plugins…'); });
        if (w.theme_updates) BP.btn(act, 'update themes', function () { run('/api/wp/themes-update', w, 'Updating themes…'); });
        BP.btn(act, 'harden', function () { run('/api/wp/harden', w, 'Disabling file editor…'); });
        tb.appendChild(tr);
      });
    }).catch(function () { BP.err('Panel could not reach the agent.'); tb.innerHTML = ''; });
  }

  function run(url, w, msg) {
    BP.ok(msg);
    BP.post(url, { site_id: w.id }).then(function (r) {
      if (r.ok) BP.ok(typeof r.data === 'string' ? r.data : 'done'); else BP.err(r.error || 'action failed');
      load();
    }).catch(function () { BP.err('Request failed.'); });
  }

  $('wpt-refresh').addEventListener('click', load);
  load();
})();
