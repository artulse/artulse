/* BitPanel logs */
(function () {
  'use strict';
  if (!document.getElementById('lg-file')) return;
  function $(id) { return document.getElementById(id); }

  function loadList() {
    BP.get('/api/log/list').then(function (res) {
      var sel = $('lg-file'); sel.innerHTML = '';
      if (!res.ok || !res.data.length) { sel.innerHTML = '<option value="">no logs found</option>'; return; }
      res.data.forEach(function (l) {
        var o = document.createElement('option');
        o.value = l.path; o.textContent = l.key + '  (' + BP.bytes(l.size) + ')';
        sel.appendChild(o);
      });
      tail();
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  function tail() {
    var path = $('lg-file').value;
    if (!path) return;
    $('lg-text').textContent = 'Loading…';
    BP.get('/api/log/tail?path=' + encodeURIComponent(path) + '&lines=' + $('lg-lines').value).then(function (r) {
      if (!r.ok) { $('lg-text').textContent = r.error || 'read failed'; return; }
      $('lg-text').textContent = r.data.text || '(empty)';
      var el = $('lg-text'); el.scrollTop = el.scrollHeight;
    });
  }
  $('lg-file').addEventListener('change', tail);
  $('lg-lines').addEventListener('change', tail);
  $('lg-refresh').addEventListener('click', tail);
  loadList();
})();
