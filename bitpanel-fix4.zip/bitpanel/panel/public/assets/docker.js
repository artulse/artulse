/* BitPanel docker */
(function () {
  'use strict';
  if (!document.getElementById('dk-table')) return;
  function $(id) { return document.getElementById(id); }

  function load() {
    BP.get('/api/docker/ps?all=' + ($('dk-all').checked ? '1' : '')).then(function (res) {
      if (res.installed === false) { $('dk-none').classList.remove('d-none'); $('dk-summary').textContent = 'not installed'; return; }
      if (!res.ok) { BP.err(res.error || 'ps failed'); return; }
      $('dk-wrap').classList.remove('d-none');
      var run = res.data.filter(function (c) { return c.state === 'running'; }).length;
      $('dk-summary').textContent = res.data.length + ' containers · ' + run + ' running';
      var tb = $('dk-table').tBodies[0]; tb.innerHTML = '';
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="5" class="text-muted">No containers.</td></tr>'; }
      res.data.forEach(function (c) {
        var tr = document.createElement('tr');
        var running = c.state === 'running';
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(c.name) + '</td>' +
          '<td class="bp-sub st-target" title="' + BP.esc(c.image) + '">' + BP.esc(c.image) + '</td>' +
          '<td><span class="bp-state ' + (running ? 'ok' : 'mid') + '">' + BP.esc(c.status) + '</span></td>' +
          '<td class="bp-sub st-target">' + BP.esc(c.ports || '—') + '</td><td class="text-end"></td>';
        var act = tr.lastElementChild;
        BP.btn(act, 'logs', function () { logs(c); });
        if (running) { BP.btn(act, 'restart', function () { action(c, 'restart'); }); BP.btn(act, 'stop', function () { action(c, 'stop'); }); }
        else { BP.btn(act, 'start', function () { action(c, 'start'); }); BP.btn(act, 'rm', function () { action(c, 'rm'); }); }
        tb.appendChild(tr);
      });
      loadImages();
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  function loadImages() {
    BP.get('/api/docker/images').then(function (res) {
      var tb = $('dk-images').tBodies[0]; tb.innerHTML = '';
      if (!res.ok || !res.data.length) { tb.innerHTML = '<tr><td colspan="4" class="text-muted">No images.</td></tr>'; return; }
      res.data.forEach(function (im) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(im.repo) + '</td><td class="bp-sub">' + BP.esc(im.tag) + '</td>' +
          '<td class="bp-sub">' + BP.esc(im.id) + '</td><td class="bp-sub">' + BP.esc(im.size) + '</td>';
        tb.appendChild(tr);
      });
    });
  }

  function action(c, act) {
    if ((act === 'stop' || act === 'rm') && !confirm(act + ' ' + c.name + '?')) return;
    BP.post('/api/docker/action', { id: c.id, action: act }).then(function (r) { if (!r.ok) BP.err(r.error || 'action failed'); load(); });
  }

  function logs(c) {
    $('dk-logname').textContent = c.name;
    $('dk-logtext').textContent = 'Loading…';
    $('dk-logwrap').classList.remove('d-none');
    BP.get('/api/docker/logs?id=' + encodeURIComponent(c.id) + '&lines=200').then(function (r) {
      $('dk-logtext').textContent = r.ok ? (r.data.text || '(empty)') : (r.error || 'logs failed');
    });
  }
  $('dk-logclose').addEventListener('click', function () { $('dk-logwrap').classList.add('d-none'); });
  $('dk-refresh').addEventListener('click', load);
  $('dk-all').addEventListener('change', load);

  load();
})();
