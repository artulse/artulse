/* BitPanel dashboard client */
(function () {
  'use strict';
  if (!document.getElementById('svc-table')) return; // dashboard only

  var prevNet = null;

  function $(id) { return document.getElementById(id); }

  function fmtBytes(b) {
    if (!isFinite(b) || b < 0) b = 0;
    var u = ['B', 'KB', 'MB', 'GB', 'TB'], i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
    return b.toFixed(b >= 100 || i === 0 ? 0 : 1) + ' ' + u[i];
  }

  function fmtUptime(s) {
    s = Math.floor(s);
    var d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    return (d ? d + 'd ' : '') + h + 'h ' + m + 'm';
  }

  function bar(el, pct) {
    el.style.width = Math.min(100, pct) + '%';
    el.className = pct >= 90 ? 'crit' : (pct >= 75 ? 'warn' : '');
  }

  function showError(msg) {
    var box = $('agent-error');
    if (msg) { box.textContent = msg; box.classList.remove('d-none'); }
    else box.classList.add('d-none');
  }

  function renderStats(d) {
    $('h-host').textContent = d.hostname;
    $('h-os').textContent = d.os;
    $('h-uptime').textContent = fmtUptime(d.uptime);

    $('m-cpu').textContent = d.cpu.toFixed(1);
    $('m-cores').textContent = '· ' + d.cores + ' cores';
    $('m-load').textContent = d.load.join(' ');
    bar($('b-cpu'), d.cpu);

    var used = d.mem.total - d.mem.available;
    var mp = d.mem.total ? (used / d.mem.total) * 100 : 0;
    $('m-mem').textContent = mp.toFixed(1);
    $('m-memtxt').textContent = fmtBytes(used) + ' / ' + fmtBytes(d.mem.total);
    bar($('b-mem'), mp);

    var root = null;
    (d.disks || []).forEach(function (x) { if (x.mount === '/') root = x; });
    if (!root && d.disks && d.disks.length) root = d.disks[0];
    if (root) {
      var dp = (root.used / root.total) * 100;
      $('m-disk').textContent = dp.toFixed(1);
      $('m-disktxt').textContent = fmtBytes(root.used) + ' / ' + fmtBytes(root.total);
      bar($('b-disk'), dp);
    }

    if (prevNet && d.net.ts > prevNet.ts) {
      var dt = d.net.ts - prevNet.ts;
      $('m-rx').textContent = fmtBytes((d.net.rx - prevNet.rx) / dt) + '/s';
      $('m-tx').textContent = fmtBytes((d.net.tx - prevNet.tx) / dt) + '/s';
    }
    prevNet = d.net;

    var tb = $('disk-table').tBodies[0];
    tb.innerHTML = '';
    (d.disks || []).forEach(function (x) {
      var pct = (x.used / x.total) * 100;
      var tr = document.createElement('tr');
      tr.innerHTML =
        '<td class="bp-unit"></td><td class="bp-sub"></td><td class="bp-sub"></td>' +
        '<td><div class="bp-bar"><i style="width:' + Math.min(100, pct).toFixed(1) + '%"></i></div></td>';
      tr.cells[0].textContent = x.mount;
      tr.cells[1].textContent = fmtBytes(x.used);
      tr.cells[2].textContent = fmtBytes(x.total);
      tb.appendChild(tr);
    });
  }

  function stateBadge(s) {
    var cls = s.active === 'active' ? 'ok' : (s.active === 'failed' ? 'bad' : 'mid');
    return '<span class="bp-state ' + cls + '">' + s.active + ' (' + s.sub + ')</span>';
  }

  function renderServices(list) {
    var tb = $('svc-table').tBodies[0];
    tb.innerHTML = '';
    if (!list.length) {
      tb.innerHTML = '<tr><td colspan="3" class="text-muted">No managed services detected.</td></tr>';
      return;
    }
    list.forEach(function (s) {
      var tr = document.createElement('tr');
      var running = s.active === 'active';
      tr.innerHTML =
        '<td class="bp-unit">' + s.unit + '</td>' +
        '<td>' + stateBadge(s) + '</td>' +
        '<td class="text-end">' +
          (running
            ? '<button class="bp-act" data-a="reload">reload</button>' +
              '<button class="bp-act" data-a="restart">restart</button>' +
              '<button class="bp-act" data-a="stop">stop</button>'
            : '<button class="bp-act" data-a="start">start</button>') +
        '</td>';
      tr.querySelectorAll('.bp-act').forEach(function (btn) {
        btn.addEventListener('click', function () { svcAction(s.unit, btn.dataset.a, btn); });
      });
      tb.appendChild(tr);
    });
  }

  function svcAction(unit, action, btn) {
    if ((action === 'stop' || action === 'restart') &&
        !confirm(action + ' ' + unit + '?')) return;
    btn.disabled = true;
    fetch('/api/service', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF': window.BP_CSRF },
      body: JSON.stringify({ unit: unit, action: action })
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        showError(res.ok ? '' : ('Service action failed: ' + (res.error || 'unknown')));
        loadServices();
      })
      .catch(function () { showError('Panel could not reach the agent.'); })
      .finally(function () { btn.disabled = false; });
  }

  function loadStats() {
    fetch('/api/stats').then(function (r) {
      if (r.status === 401) { location.href = '/login'; return null; }
      return r.json();
    }).then(function (res) {
      if (!res) return;
      if (res.ok) { showError(''); renderStats(res.data); }
      else showError('Agent error: ' + (res.error || 'unknown'));
    }).catch(function () { showError('Panel could not reach the agent.'); });
  }

  function loadServices() {
    fetch('/api/services').then(function (r) { return r.json(); })
      .then(function (res) { if (res.ok) renderServices(res.data); })
      .catch(function () { /* stats poll surfaces the error */ });
  }

  /* ---- rollup ---- */
  function loadRollup() {
    var row = document.getElementById('rollup-row');
    if (!row) return;
    fetch('/api/overview').then(function (r) { return r.json(); }).then(function (res) {
      if (!res.ok) return;
      var d = res.data;
      row.innerHTML = '';
      [
        ['Sites', d.sites_running + ' / ' + d.sites_total, 'running'],
        ['FTP accounts', d.ftp_accounts, ''],
        ['Mail', d.mail_domains + ' domains · ' + d.mailboxes + ' boxes', ''],
        ['Databases', d.databases, ''],
        ['Docker', d.docker_running, 'running']
      ].forEach(function (item) {
        var c = document.createElement('div');
        c.className = 'bp-roll';
        c.innerHTML = '<div class="bp-roll-n">' + item[1] + '</div><div class="bp-roll-l">' + item[0]
          + (item[2] ? ' <span class="bp-sub">' + item[2] + '</span>' : '') + '</div>';
        row.appendChild(c);
      });
    }).catch(function () {});
  }

  /* ---- history chart ---- */
  var histChart = null;
  function loadHistory() {
    var canvas = document.getElementById('hist-chart');
    if (!canvas || typeof Chart === 'undefined') return;
    var range = document.getElementById('hist-range').value;
    fetch('/api/metrics/history?range=' + range).then(function (r) { return r.json(); }).then(function (res) {
      if (!res.ok) return;
      var rows = res.data;
      if (!rows.length) {
        document.getElementById('hist-note').textContent = 'No history yet — the collector runs every 5 minutes, check back shortly.';
      } else {
        document.getElementById('hist-note').textContent = 'Collected every 5 minutes · ' + rows.length + ' points.';
      }
      var labels = rows.map(function (r) {
        var d = new Date(r.ts * 1000);
        return range === '24h' ? (d.getHours() + ':' + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes())
          : (d.getMonth() + 1) + '/' + d.getDate();
      });
      var data = {
        labels: labels,
        datasets: [
          { label: 'CPU %', data: rows.map(function (r) { return r.cpu; }), borderColor: '#0891b2', tension: 0.25, pointRadius: 0 },
          { label: 'Mem %', data: rows.map(function (r) { return r.mem_pct; }), borderColor: '#d97706', tension: 0.25, pointRadius: 0 },
          { label: 'Disk %', data: rows.map(function (r) { return r.disk_pct; }), borderColor: '#16a34a', tension: 0.25, pointRadius: 0 }
        ]
      };
      if (histChart) { histChart.data = data; histChart.update(); }
      else {
        histChart = new Chart(canvas.getContext('2d'), {
          type: 'line', data: data,
          options: { responsive: true, scales: { y: { min: 0, max: 100 } }, plugins: { legend: { position: 'bottom' } } }
        });
      }
    }).catch(function () {});
  }
  var rangeSel = document.getElementById('hist-range');
  if (rangeSel) rangeSel.addEventListener('change', loadHistory);

  loadStats();
  loadServices();
  loadRollup();
  loadHistory();
  setInterval(loadStats, 3000);
  setInterval(loadServices, 10000);
  setInterval(loadRollup, 30000);
  setInterval(loadHistory, 60000);
})();
