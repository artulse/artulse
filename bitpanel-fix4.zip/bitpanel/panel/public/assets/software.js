/* BitPanel software store */
(function () {
  'use strict';
  if (!document.getElementById('sw-groups')) return;

  function load() {
    BP.get('/api/soft/catalog').then(function (res) {
      if (!res.ok) { BP.err(res.error || 'catalog failed'); return; }
      render(res.data);
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  function render(items) {
    var groups = {};
    items.forEach(function (it) { (groups[it.group] = groups[it.group] || []).push(it); });
    var wrap = document.getElementById('sw-groups');
    wrap.innerHTML = '';
    Object.keys(groups).forEach(function (g) {
      var panel = document.createElement('div');
      panel.className = 'bp-panel';
      panel.innerHTML = '<div class="bp-panel-title">' + BP.esc(g) + '</div>';
      var tbl = document.createElement('table');
      tbl.className = 'table bp-table mb-0';
      tbl.innerHTML = '<tbody></tbody>';
      var tb = tbl.tBodies[0];
      groups[g].forEach(function (it) {
        var tr = document.createElement('tr');
        var state = it.installed
          ? (it.unit ? '<span class="bp-state ' + (it.active ? 'ok' : 'bad') + '">' + (it.active ? 'running' : 'stopped') + '</span>'
                     : '<span class="bp-state ok">installed</span>')
          : '<span class="bp-state mid">not installed</span>';
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(it.label) + '</td><td>' + state + '</td><td class="text-end"></td>';
        var act = tr.lastElementChild;
        if (!it.installed) {
          BP.btn(act, 'install', function () { install(it); });
        } else if (!it.locked) {
          BP.btn(act, 'uninstall', function () { uninstall(it); });
        } else {
          act.innerHTML = '<span class="bp-sub">required</span>';
        }
        tb.appendChild(tr);
      });
      panel.appendChild(tbl);
      wrap.appendChild(panel);
    });
  }

  function install(it) {
    if (!confirm('Install ' + it.label + '? This may take a minute.')) return;
    BP.ok('Installing ' + it.label + '…');
    BP.post('/api/soft/install', { key: it.key }).then(function (r) {
      if (r.ok) BP.ok(typeof r.data === 'string' ? r.data : 'installed'); else BP.err(r.error || 'install failed');
      load();
    }).catch(function () { BP.err('Install request failed.'); });
  }

  function uninstall(it) {
    if (!confirm('Uninstall ' + it.label + '? Configuration packages will be purged.')) return;
    BP.ok('Removing ' + it.label + '…');
    BP.post('/api/soft/uninstall', { key: it.key }).then(function (r) {
      if (r.ok) BP.ok(typeof r.data === 'string' ? r.data : 'removed'); else BP.err(r.error || 'uninstall failed');
      load();
    }).catch(function () { BP.err('Request failed.'); });
  }

  load();
})();
