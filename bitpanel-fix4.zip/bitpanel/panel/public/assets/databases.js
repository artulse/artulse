/* BitPanel databases */
(function () {
  'use strict';
  if (!document.getElementById('db-table')) return;

  function $(id) { return document.getElementById(id); }
  function api(u) { return fetch(u).then(function (r) {
    if (r.status === 401) { location.href = '/login'; throw new Error('auth'); } return r.json(); }); }
  function post(u, b) { return fetch(u, { method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF': window.BP_CSRF }, body: JSON.stringify(b || {}) })
    .then(function (r) { if (r.status === 401) { location.href = '/login'; throw new Error('auth'); } return r.json(); }); }
  function err(m) { var b = $('db-error'); if (m) { b.textContent = m; b.classList.remove('d-none'); } else b.classList.add('d-none'); }
  function ok(m) { var b = $('db-ok'); if (m) { b.textContent = m; b.classList.remove('d-none'); setTimeout(function () { b.classList.add('d-none'); }, 4000); } else b.classList.add('d-none'); }
  function fmtBytes(b) { if (!isFinite(b) || b < 0) b = 0; var u = ['B', 'KB', 'MB', 'GB', 'TB'], i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; } return b.toFixed(b >= 100 || i === 0 ? 0 : 1) + ' ' + u[i]; }
  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function addBtn(cell, label, fn) { var b = document.createElement('button'); b.className = 'bp-act'; b.textContent = label; b.addEventListener('click', fn); cell.appendChild(b); }

  function boot() {
    api('/api/db/status').then(function (res) {
      if (!res.ok) { err(res.error || 'status failed'); return; }
      if (!res.data.installed) { $('db-none').classList.remove('d-none'); return; }
      $('db-engine').textContent = res.data.engine + (res.data.active ? ' · running' : ' · stopped');
      $('db-wrap').classList.remove('d-none');
      loadDbs(); loadUsers();
    }).catch(function () { err('Panel could not reach the agent.'); });
  }

  function loadDbs() {
    api('/api/db/list').then(function (res) {
      if (!res.ok) { err(res.error || 'list failed'); return; }
      var tb = $('db-table').tBodies[0]; tb.innerHTML = '';
      var sel = $('du-db'); sel.innerHTML = '<option value="">— no grant —</option>';
      var qsel = $('q-db'); if (qsel) qsel.innerHTML = '';
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="4" class="text-muted">No databases.</td></tr>'; return; }
      res.data.forEach(function (d) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + escapeHtml(d.name) + '</td>' +
          '<td class="bp-sub">' + d.tables + '</td>' +
          '<td class="bp-sub">' + fmtBytes(d.size) + '</td><td class="text-end"></td>';
        addBtn(tr.lastElementChild, 'drop', function () { dropDb(d.name); });
        tb.appendChild(tr);
        var o = document.createElement('option'); o.value = d.name; o.textContent = d.name; sel.appendChild(o);
        if (qsel) { var q = document.createElement('option'); q.value = d.name; q.textContent = d.name; qsel.appendChild(q); }
      });
    });
  }

  function loadUsers() {
    api('/api/db/users').then(function (res) {
      if (!res.ok) { err(res.error || 'users failed'); return; }
      var tb = $('du-table').tBodies[0]; tb.innerHTML = '';
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="4" class="text-muted">No application users.</td></tr>'; return; }
      res.data.forEach(function (u) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + escapeHtml(u.user) + '</td>' +
          '<td class="bp-sub">' + escapeHtml(u.host) + '</td>' +
          '<td class="bp-sub st-target">' + (u.databases.length ? escapeHtml(u.databases.join(', ')) : '—') + '</td>' +
          '<td class="text-end"></td>';
        addBtn(tr.lastElementChild, 'password', function () { pwUser(u); });
        addBtn(tr.lastElementChild, 'drop', function () { dropUser(u); });
        tb.appendChild(tr);
      });
    });
  }

  $('db-create').addEventListener('click', function () {
    var name = $('db-name').value.trim();
    if (!name) { err('Enter a database name.'); return; }
    post('/api/db/create', { name: name, charset: $('db-charset').value }).then(function (r) {
      if (r.ok) { ok('Database created: ' + name); $('db-name').value = ''; loadDbs(); } else err(r.error || 'create failed');
    });
  });

  function dropDb(name) {
    if (!confirm('Drop database ' + name + '? This permanently deletes all its data.')) return;
    post('/api/db/drop', { name: name }).then(function (r) { if (r.ok) { ok('Dropped ' + name); loadDbs(); } else err(r.error || 'drop failed'); });
  }

  $('du-create').addEventListener('click', function () {
    var user = $('du-user').value.trim(), pass = $('du-pass').value;
    if (!user || !pass) { err('Username and password are required.'); return; }
    post('/api/db/user-create', { user: user, password: pass, host: $('du-host').value, database: $('du-db').value })
      .then(function (r) { if (r.ok) { ok('User created: ' + user); $('du-user').value = ''; $('du-pass').value = ''; loadUsers(); } else err(r.error || 'create failed'); });
  });

  function dropUser(u) {
    if (!confirm('Drop user ' + u.user + '@' + u.host + '?')) return;
    post('/api/db/user-drop', { user: u.user, host: u.host }).then(function (r) { if (r.ok) { ok('Dropped ' + u.user); loadUsers(); } else err(r.error || 'drop failed'); });
  }

  function pwUser(u) {
    var p = prompt('New password for ' + u.user + '@' + u.host + ':');
    if (!p) return;
    post('/api/db/user-password', { user: u.user, host: u.host, password: p })
      .then(function (r) { if (r.ok) ok('Password changed for ' + u.user); else err(r.error || 'change failed'); });
  }

  boot();

  /* ---- SQL console + table browser ---- */
  function qdb() { var s = $('q-db'); return s ? s.value : ''; }
  if ($('q-tables')) $('q-tables').addEventListener('click', function () {
    if (!qdb()) return;
    api('/api/db/tables?database=' + encodeURIComponent(qdb())).then(function (res) {
      var t = $('q-tabletable'); var tb = t.tBodies[0]; tb.innerHTML = '';
      t.classList.remove('d-none');
      if (!res.ok) { err(res.error || 'tables failed'); return; }
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="4" class="text-muted">No tables.</td></tr>'; return; }
      res.data.forEach(function (tbl) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + escapeHtml(tbl.name) + '</td><td class="bp-sub">' + tbl.rows + '</td>' +
          '<td class="bp-sub">' + fmtBytes(tbl.size) + '</td><td class="text-end"></td>';
        var b = document.createElement('button'); b.className = 'bp-act'; b.textContent = 'browse';
        b.addEventListener('click', function () { $('q-sql').value = 'SELECT * FROM `' + tbl.name + '` LIMIT 50;'; runQuery(); });
        tr.lastElementChild.appendChild(b);
        tb.appendChild(tr);
      });
    });
  });
  function runQuery() {
    var sql = $('q-sql').value.trim();
    if (!qdb() || !sql) { err('Choose a database and enter a query.'); return; }
    if (!/^\s*(select|show|describe|desc|explain)\b/i.test(sql) &&
        !confirm('This is not a SELECT. It will modify the database. Continue?')) return;
    var out = $('q-out'); out.classList.remove('d-none'); out.textContent = 'Running…';
    post('/api/db/query', { database: qdb(), sql: sql }).then(function (r) {
      out.textContent = r.ok ? r.data.text : ('Error: ' + (r.error || 'query failed'));
    });
  }
  if ($('q-run')) $('q-run').addEventListener('click', runQuery);
  if ($('q-sql')) $('q-sql').addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); runQuery(); } });
})();
