/* BitPanel cleanup */
(function () {
  'use strict';
  if (!document.getElementById('cu-breakdown')) return;
  function $(id) { return document.getElementById(id); }

  function loadBreakdown() {
    BP.get('/api/cleanup/disk-usage').then(function (res) {
      var tb = $('cu-breakdown').tBodies[0]; tb.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'scan failed'); return; }
      var root = (res.data.disks || []).find(function (d) { return d.mount === '/'; }) || res.data.disks[0];
      var max = root ? root.total : Math.max.apply(null, res.data.breakdown.map(function (b) { return b.size; }).concat([1]));
      res.data.breakdown.forEach(function (b) {
        var pct = Math.min(100, (b.size / max) * 100);
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(b.label) + '</td><td class="bp-sub">' + BP.bytes(b.size) + '</td>' +
          '<td><div class="bp-bar"><i style="width:' + pct.toFixed(1) + '%"></i></div></td>';
        tb.appendChild(tr);
      });
      if (root) {
        var used = root.used, total = root.total;
        var tr2 = document.createElement('tr');
        tr2.innerHTML = '<td class="bp-unit">Root filesystem (total)</td><td class="bp-sub">' + BP.bytes(used) + ' / ' + BP.bytes(total) + '</td>' +
          '<td><div class="bp-bar"><i class="' + ((used / total) > 0.9 ? 'crit' : (used / total) > 0.75 ? 'warn' : '') + '" style="width:' + Math.min(100, (used / total) * 100).toFixed(1) + '%"></i></div></td>';
        tb.insertBefore(tr2, tb.firstChild);
      }
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  function row(label, bytesVal, detail, action, params) {
    var div = document.createElement('div');
    div.className = 'cu-row';
    div.innerHTML = '<div><strong>' + BP.esc(label) + '</strong><div class="bp-sub">' + BP.esc(detail) + '</div></div>' +
      '<div class="cu-row-right"><span class="bp-unit">' + BP.bytes(bytesVal) + '</span></div>';
    var btn = document.createElement('button');
    btn.className = 'btn bp-btn'; btn.textContent = 'Clean';
    btn.addEventListener('click', function () { run(action, params, btn); });
    div.querySelector('.cu-row-right').appendChild(btn);
    return div;
  }

  function scan() {
    BP.get('/api/cleanup/scan').then(function (res) {
      var wrap = $('cu-suggest'); wrap.innerHTML = '';
      if (!res.ok) { BP.err(res.error || 'scan failed'); return; }
      var d = res.data;
      wrap.appendChild(row('APT package cache', d.apt_cache.bytes, 'Downloaded .deb files no longer needed', 'apt_clean', {}));
      wrap.appendChild(row('systemd journal', d.journal.reclaimable, 'Trim journal logs down to 200 MB', 'journal_vacuum', {}));
      wrap.appendChild(row('Old backups (30+ days)', d.old_backups.bytes, d.old_backups.count + ' backup(s) older than 30 days', 'old_backups', { days: 30 }));
      wrap.appendChild(row('Large logs (20+ MB)', d.large_logs.bytes, d.large_logs.count + ' log file(s) — truncated in place, not deleted', 'truncate_logs_prompt', {}));
      wrap.appendChild(row('Stale temp files', d.tmp_files.bytes, d.tmp_files.count + ' upload/download temp file(s) older than 24h', 'tmp_files', {}));
      if (d.docker.installed) {
        var div = document.createElement('div');
        div.className = 'cu-row';
        div.innerHTML = '<div><strong>Docker</strong><div class="bp-sub">' + (d.docker.summary ? BP.esc(d.docker.summary).replace(/\n/g, '<br>') : 'stopped containers, unused images/networks') + '</div></div><div class="cu-row-right"></div>';
        var btn = document.createElement('button'); btn.className = 'bp-act'; btn.textContent = 'Prune';
        btn.addEventListener('click', function () {
          if (!confirm('Run docker system prune -af? This removes ALL stopped containers and unused images (not volumes).')) return;
          run('docker_prune', {}, btn);
        });
        div.querySelector('.cu-row-right').appendChild(btn);
        wrap.appendChild(div);
      }
      if (!wrap.children.length) wrap.innerHTML = '<p class="bp-sub mb-0">Nothing significant to clean up right now.</p>';
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  function run(action, params, btn) {
    if (action === 'truncate_logs_prompt') {
      BP.get('/api/log/list').then(function (res) {
        if (!res.ok) { BP.err('could not list logs'); return; }
        var big = res.data.filter(function (l) { return l.size > 20 * 1024 * 1024; });
        if (!big.length) { BP.ok('No large logs to truncate.'); return; }
        var names = big.map(function (l) { return l.key + ' (' + BP.bytes(l.size) + ')'; }).join('\n');
        if (!confirm('Truncate these logs to zero?\n\n' + names)) return;
        BP.post('/api/cleanup/run', { action: 'truncate_logs', params: { paths: big.map(function (l) { return l.path; }) } })
          .then(function (r) { if (r.ok) { BP.ok(r.data); scan(); loadBreakdown(); } else BP.err(r.error || 'failed'); });
      });
      return;
    }
    if (btn) btn.disabled = true;
    BP.post('/api/cleanup/run', { action: action, params: params }).then(function (r) {
      if (r.ok) { BP.ok(r.data || 'done'); } else BP.err(r.error || 'cleanup failed');
      scan(); loadBreakdown();
    }).catch(function () { BP.err('Request failed.'); }).finally(function () { if (btn) btn.disabled = false; });
  }

  $('cu-refresh').addEventListener('click', function () { loadBreakdown(); scan(); });
  loadBreakdown();
  scan();
})();
