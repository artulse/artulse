/* BitPanel mail server */
(function () {
  'use strict';
  if (!document.getElementById('dm-table')) return;
  function $(id) { return document.getElementById(id); }

  function status() {
    BP.get('/api/mail/status').then(function (res) {
      if (!res.ok) { BP.err(res.error || 'status failed'); return; }
      var d = res.data;
      $('ml-state').textContent = !d.installed ? 'not installed'
        : ((d.postfix && d.dovecot) ? 'running' : 'installed, not fully running');
      $('ml-state').className = 'bp-state ' + (!d.installed ? 'mid' : ((d.postfix && d.dovecot) ? 'ok' : 'bad'));
      $('ml-summary').textContent = d.installed ? (d.domains + ' domain(s) · ' + d.mailboxes + ' mailbox(es)') : 'Postfix/Dovecot not installed';
      $('ml-body').classList.toggle('d-none', !d.installed);
      $('ml-host').value = d.hostname || '';
      $('ml-ssl-state').textContent = d.ssl ? 'certificate installed' : 'no certificate';
      $('ml-ssl-state').className = 'bp-state ' + (d.ssl ? 'ok' : 'mid');
      if (d.installed) { loadDomains(); loadAliases(); }
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  $('ml-setup').addEventListener('click', function () {
    if (!confirm('Install and configure the mail server now? This may take a minute.')) return;
    BP.ok('Setting up Postfix + Dovecot + OpenDKIM…');
    BP.post('/api/mail/setup', {}, ).then(function (r) { if (r.ok) BP.ok('Mail server ready.'); else BP.err(r.error || 'setup failed'); status(); })
      .catch(function () { BP.err('Setup request failed.'); });
  });

  $('ml-host-save').addEventListener('click', function () {
    var h = $('ml-host').value.trim();
    if (!h) { BP.err('Enter a hostname.'); return; }
    BP.post('/api/mail/hostname', { hostname: h }).then(function (r) { if (r.ok) BP.ok('Hostname saved.'); else BP.err(r.error || 'save failed'); status(); });
  });
  $('ml-ssl').addEventListener('click', function () {
    if (!$('ml-host').value.trim()) { BP.err('Save a hostname first.'); return; }
    BP.ok('Requesting certificate… 15-30s.');
    BP.post('/api/mail/ssl', {}).then(function (r) { if (r.ok) BP.ok('Certificate installed.'); else BP.err(r.error || 'issuance failed'); status(); });
  });

  /* domains */
  function loadDomains() {
    BP.get('/api/mail/domains').then(function (res) {
      var tb = $('dm-table').tBodies[0]; tb.innerHTML = '';
      var sel = null;
      if (!res.ok) { BP.err(res.error || 'domains failed'); return; }
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="3" class="text-muted">No domains yet.</td></tr>'; }
      res.data.forEach(function (d) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(d.domain) + '</td><td class="bp-sub">' + d.mailboxes + '</td><td class="text-end"></td>';
        var act = tr.lastElementChild;
        BP.btn(act, 'DNS records', function () { showRecords(d.domain); });
        BP.btn(act, 'delete', function () { delDomain(d); });
        tb.appendChild(tr);
      });
      loadMailboxes();
    }).catch(function () { BP.err('Panel could not reach the agent.'); });
  }

  $('dm-add').addEventListener('click', function () {
    var d = $('dm-domain').value.trim();
    if (!d) { BP.err('Enter a domain.'); return; }
    BP.ok('Adding domain and generating DKIM key…');
    BP.post('/api/mail/domains', { domain: d }).then(function (r) {
      if (r.ok) { BP.ok('Domain added.'); $('dm-domain').value = ''; loadDomains(); showRecords(d); }
      else BP.err(r.error || 'add failed');
    });
  });
  function delDomain(d) {
    if (!confirm('Delete domain ' + d.domain + '? This deletes all ' + d.mailboxes + ' mailbox(es) and their mail permanently.')) return;
    BP.post('/api/mail/domain-delete', { domain: d.domain }).then(function (r) { if (r.ok) { BP.ok('Domain deleted.'); loadDomains(); } else BP.err(r.error || 'delete failed'); });
  }
  function showRecords(domain) {
    BP.get('/api/mail/domain-records?domain=' + encodeURIComponent(domain)).then(function (res) {
      if (!res.ok) { BP.err(res.error || 'records failed'); return; }
      $('dr-domain').textContent = domain;
      var tb = $('dr-table').tBodies[0]; tb.innerHTML = '';
      ['mx', 'spf', 'dkim', 'dmarc'].forEach(function (k) {
        var r = res.data[k];
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-sub">' + r.type + '</td><td class="bp-unit">' + BP.esc(r.host) + '</td>' +
          '<td class="bp-sub st-target" style="max-width:420px;white-space:normal" title="' + BP.esc(r.value) + '">' + BP.esc(r.value) + '</td>';
        tb.appendChild(tr);
      });
      $('dm-records').classList.remove('d-none');
    });
  }
  $('dr-close').addEventListener('click', function () { $('dm-records').classList.add('d-none'); });

  /* mailboxes */
  function loadMailboxes() {
    BP.get('/api/mail/mailboxes?domain=').then(function (res) {
      var tb = $('mb-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok || !res.data.length) { tb.innerHTML = '<tr><td colspan="2" class="text-muted">No mailboxes yet.</td></tr>'; return; }
      res.data.forEach(function (m) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(m.email) + '</td><td class="text-end"></td>';
        var act = tr.lastElementChild;
        BP.btn(act, 'password', function () { pwBox(m); });
        BP.btn(act, 'delete', function () { delBox(m); });
        tb.appendChild(tr);
      });
    });
  }
  $('mb-add').addEventListener('click', function () {
    var email = $('mb-email').value.trim(), pass = $('mb-pass').value;
    if (!email || !pass) { BP.err('Email and password are required.'); return; }
    BP.post('/api/mail/mailboxes', { email: email, password: pass }).then(function (r) {
      if (r.ok) { BP.ok('Mailbox created.'); $('mb-email').value = ''; $('mb-pass').value = ''; loadDomains(); }
      else BP.err(r.error || 'create failed');
    });
  });
  function pwBox(m) { var p = prompt('New password for ' + m.email + ' (min 8):'); if (!p) return;
    BP.post('/api/mail/mailbox-password', { email: m.email, password: p }).then(function (r) { if (r.ok) BP.ok('Password changed.'); else BP.err(r.error || 'failed'); }); }
  function delBox(m) { if (!confirm('Delete mailbox ' + m.email + ' and all its mail?')) return;
    BP.post('/api/mail/mailbox-delete', { email: m.email }).then(function (r) { if (r.ok) { BP.ok('Mailbox deleted.'); loadDomains(); } else BP.err(r.error || 'failed'); }); }

  /* aliases */
  function loadAliases() {
    BP.get('/api/mail/aliases').then(function (res) {
      var tb = $('al-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok || !res.data.length) { tb.innerHTML = '<tr><td colspan="3" class="text-muted">No aliases.</td></tr>'; return; }
      res.data.forEach(function (a) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td class="bp-unit">' + BP.esc(a.from) + '</td><td class="bp-sub">' + BP.esc(a.to) + '</td><td class="text-end"></td>';
        BP.btn(tr.lastElementChild, 'delete', function () {
          BP.post('/api/mail/alias-delete', { from: a.from }).then(function (r) { if (r.ok) { BP.ok('Alias deleted.'); loadAliases(); } else BP.err(r.error || 'failed'); });
        });
        tb.appendChild(tr);
      });
    });
  }
  $('al-add').addEventListener('click', function () {
    var from = $('al-from').value.trim(), to = $('al-to').value.trim();
    if (!from || !to) { BP.err('Both fields are required.'); return; }
    BP.post('/api/mail/aliases', { from: from, to: to }).then(function (r) {
      if (r.ok) { BP.ok('Alias added.'); $('al-from').value = ''; $('al-to').value = ''; loadAliases(); }
      else BP.err(r.error || 'add failed');
    });
  });

  status();
})();
