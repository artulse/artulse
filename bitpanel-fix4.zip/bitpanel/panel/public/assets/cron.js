/* BitPanel cron */
(function () {
  'use strict';
  if (!document.getElementById('cr-table')) return;

  var user = 'root';

  function $(id) { return document.getElementById(id); }
  function api(u) { return fetch(u).then(function (r) {
    if (r.status === 401) { location.href = '/login'; throw new Error('auth'); } return r.json(); }); }
  function post(u, b) { return fetch(u, { method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF': window.BP_CSRF }, body: JSON.stringify(b || {}) })
    .then(function (r) { if (r.status === 401) { location.href = '/login'; throw new Error('auth'); } return r.json(); }); }
  function err(m) { var b = $('cr-error'); if (m) { b.textContent = m; b.classList.remove('d-none'); } else b.classList.add('d-none'); }
  function ok(m) { var b = $('cr-ok'); if (m) { b.textContent = m; b.classList.remove('d-none'); setTimeout(function () { b.classList.add('d-none'); }, 4000); } else b.classList.add('d-none'); }
  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function addBtn(cell, label, fn) { var b = document.createElement('button'); b.className = 'bp-act'; b.textContent = label; b.addEventListener('click', fn); cell.appendChild(b); }

  function loadUsers() {
    api('/api/cron/users').then(function (res) {
      var sel = $('cr-user'); sel.innerHTML = '';
      (res.ok ? res.data : ['root']).forEach(function (u) {
        var o = document.createElement('option'); o.value = u; o.textContent = u;
        if (u === 'root') o.selected = true; sel.appendChild(o);
      });
      load();
    }).catch(function () { err('Panel could not reach the agent.'); });
  }

  function load() {
    user = $('cr-user').value || 'root';
    $('cr-who').textContent = user;
    err('');
    api('/api/cron/list?user=' + encodeURIComponent(user)).then(function (res) {
      if (!res.ok) { err(res.error || 'list failed'); return; }
      render(res.data.jobs);
    }).catch(function (e) { if (e.message !== 'auth') err('Panel could not reach the agent.'); });
  }

  function render(jobs) {
    var tb = $('cr-table').tBodies[0]; tb.innerHTML = '';
    if (!jobs.length) { tb.innerHTML = '<tr><td colspan="3" class="text-muted">No scheduled tasks.</td></tr>'; return; }
    jobs.forEach(function (j) {
      var tr = document.createElement('tr');
      if (!j.enabled) tr.style.opacity = '0.5';
      tr.innerHTML = '<td class="bp-unit">' + escapeHtml(j.schedule) +
        (j.enabled ? '' : ' <span class="bp-state mid">off</span>') + '</td>' +
        '<td class="bp-sub st-target" title="' + escapeHtml(j.command) + '">' + escapeHtml(j.command) + '</td>' +
        '<td class="text-end"></td>';
      addBtn(tr.lastElementChild, j.enabled ? 'disable' : 'enable', function () { toggle(j.index); });
      addBtn(tr.lastElementChild, 'delete', function () { del(j.index, j.schedule); });
      tb.appendChild(tr);
    });
  }

  $('cr-user').addEventListener('change', load);
  $('cr-refresh').addEventListener('click', load);

  $('cr-add').addEventListener('click', function () {
    var sched = $('cr-sched').value.trim(), cmd = $('cr-cmd').value.trim();
    if (!sched || !cmd) { err('Schedule and command are required.'); return; }
    post('/api/cron/add', { user: user, schedule: sched, command: cmd }).then(function (r) {
      if (r.ok) { ok('Task added.'); $('cr-sched').value = ''; $('cr-cmd').value = ''; load(); } else err(r.error || 'add failed');
    });
  });

  function toggle(i) { post('/api/cron/toggle', { user: user, index: i }).then(function (r) { if (!r.ok) err(r.error || 'toggle failed'); load(); }); }
  function del(i, s) {
    if (!confirm('Delete task: ' + s + ' …?')) return;
    post('/api/cron/delete', { user: user, index: i }).then(function (r) { if (r.ok) ok('Task deleted.'); else err(r.error || 'delete failed'); load(); });
  }

  loadUsers();
})();
