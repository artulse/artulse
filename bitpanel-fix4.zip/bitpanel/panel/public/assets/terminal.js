/* BitPanel terminal */
(function () {
  'use strict';
  var wrap = document.getElementById('term-wrap');
  if (!wrap) return;

  function $(id) { return document.getElementById(id); }
  function err(msg) {
    var box = $('term-error');
    if (msg) { box.textContent = msg; box.classList.remove('d-none'); }
    else box.classList.add('d-none');
  }

  function mount() {
    $('term-setup').classList.add('d-none');
    wrap.classList.remove('d-none');
    $('term-frame').src = '/term/';
  }

  function check() {
    fetch('/api/term/status').then(function (r) {
      if (r.status === 401) { location.href = '/login'; return null; }
      return r.json();
    }).then(function (res) {
      if (!res) return;
      if (!res.ok) { err('Agent error: ' + (res.error || 'unknown')); return; }
      if (res.data.active) mount();
      else $('term-setup').classList.remove('d-none');
    }).catch(function () { err('Panel could not reach the agent.'); });
  }

  $('term-enable').addEventListener('click', function () {
    var btn = this;
    btn.disabled = true;
    $('term-busy').classList.remove('d-none');
    fetch('/api/term/setup', {
      method: 'POST',
      headers: { 'X-CSRF': window.BP_CSRF }
    }).then(function (r) { return r.json(); })
      .then(function (res) {
        if (res.ok && res.data.active) { mount(); return; }
        err('Setup failed: ' + (res.error || 'unknown'));
        btn.disabled = false;
      })
      .catch(function () { err('Setup request failed.'); btn.disabled = false; })
      .finally(function () { $('term-busy').classList.add('d-none'); });
  });

  check();
})();
