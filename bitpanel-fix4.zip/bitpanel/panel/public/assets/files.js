/* BitPanel file manager */
(function () {
  'use strict';
  var table = document.getElementById('fm-table');
  if (!table) return;

  var cwd = '/';
  var editing = null;

  function $(id) { return document.getElementById(id); }
  function api(url) { return fetch(url).then(function (r) {
    if (r.status === 401) { location.href = '/login'; throw new Error('auth'); }
    return r.json();
  }); }
  function post(url, body) {
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF': window.BP_CSRF },
      body: JSON.stringify(body || {})
    }).then(function (r) {
      if (r.status === 401) { location.href = '/login'; throw new Error('auth'); }
      return r.json();
    });
  }
  function err(msg) {
    var box = $('fm-error');
    if (msg) { box.textContent = msg; box.classList.remove('d-none'); }
    else box.classList.add('d-none');
  }
  function fmtBytes(b) {
    if (!isFinite(b) || b < 0) b = 0;
    var u = ['B', 'KB', 'MB', 'GB', 'TB'], i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
    return b.toFixed(b >= 100 || i === 0 ? 0 : 1) + ' ' + u[i];
  }
  function fmtDate(ts) {
    var d = new Date(ts * 1000);
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate())
      + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  function join(dir, name) { return (dir === '/' ? '' : dir) + '/' + name; }
  function isArchive(n) { return /\.(zip|tar|tgz|tar\.gz)$/i.test(n); }

  /* ---------------- listing ---------------- */

  function load(path) {
    err('');
    api('/api/fs/list?path=' + encodeURIComponent(path)).then(function (res) {
      if (!res.ok) { err(res.error || 'list failed'); return; }
      cwd = res.data.path;
      $('fm-path').value = cwd;
      location.hash = encodeURIComponent(cwd);
      renderRows(res.data.entries);
    }).catch(function (e) { if (e.message !== 'auth') err('Panel could not reach the agent.'); });
  }

  function renderRows(list) {
    var tb = table.tBodies[0];
    tb.innerHTML = '';
    $('fm-count').textContent = cwd + ' · ' + list.length + ' items';
    if (!list.length) {
      tb.innerHTML = '<tr><td colspan="6" class="text-muted">Empty directory.</td></tr>';
      return;
    }
    list.forEach(function (x) {
      var tr = document.createElement('tr');
      var icon = x.type === 'dir' ? '📁' : (x.type === 'link' ? '🔗' : '📄');
      var nameCell = document.createElement('td');
      var a = document.createElement('a');
      a.href = 'javascript:void(0)';
      a.className = 'fm-name';
      a.textContent = icon + ' ' + x.name + (x.type === 'link' && x.target ? ' → ' + x.target : '');
      a.addEventListener('click', function () {
        if (x.type === 'dir') load(join(cwd, x.name));
        else openEditor(join(cwd, x.name));
      });
      nameCell.appendChild(a);

      var act = document.createElement('td');
      act.className = 'text-end fm-actions';
      addBtn(act, 'dl', function () {
        location.href = '/api/fs/download?path=' + encodeURIComponent(join(cwd, x.name));
      }, x.type !== 'dir');
      addBtn(act, 'ren', function () { doRename(x.name); }, true);
      addBtn(act, 'perm', function () { doChmod(x); }, true);
      addBtn(act, 'own', function () { doChown(x); }, true);
      addBtn(act, 'zip', function () { doCompress(x.name); }, !isArchive(x.name));
      addBtn(act, 'unzip', function () { doExtract(x.name); }, x.type === 'file' && isArchive(x.name));
      addBtn(act, 'del', function () { doDelete(x); }, true);

      tr.appendChild(nameCell);
      tr.insertAdjacentHTML('beforeend',
        '<td class="bp-sub">' + (x.type === 'dir' ? '—' : fmtBytes(x.size)) + '</td>' +
        '<td class="bp-sub fm-mode">' + x.mode + '</td>' +
        '<td class="bp-sub">' + x.owner + ':' + x.group + '</td>' +
        '<td class="bp-sub">' + fmtDate(x.mtime) + '</td>');
      tr.appendChild(act);
      tb.appendChild(tr);
    });
  }

  function addBtn(cell, label, fn, show) {
    if (!show) return;
    var b = document.createElement('button');
    b.className = 'bp-act';
    b.textContent = label;
    b.addEventListener('click', fn);
    cell.appendChild(b);
  }

  /* ---------------- operations ---------------- */

  function after(res, failMsg) {
    if (!res.ok) err(res.error || failMsg);
    load(cwd);
  }

  function doRename(name) {
    var to = prompt('Rename / move\nNew name or absolute path:', name);
    if (!to) return;
    if (to[0] !== '/') to = join(cwd, to);
    post('/api/fs/rename', { from: join(cwd, name), to: to })
      .then(function (r) { after(r, 'rename failed'); });
  }

  function doChmod(x) {
    var mode = prompt('chmod ' + x.name + '\nOctal mode (e.g. 644, 755):', x.mode.replace(/^0+/, '') || '644');
    if (!mode) return;
    var rec = x.type === 'dir' ? confirm('Apply recursively to everything inside?') : false;
    post('/api/fs/chmod', { path: join(cwd, x.name), mode: mode, recursive: rec })
      .then(function (r) { after(r, 'chmod failed'); });
  }

  function doChown(x) {
    var spec = prompt('chown ' + x.name + '\nowner or owner:group (e.g. www-data:www-data):', x.owner + ':' + x.group);
    if (!spec) return;
    var parts = spec.split(':');
    var rec = x.type === 'dir' ? confirm('Apply recursively to everything inside?') : false;
    post('/api/fs/chown', {
      path: join(cwd, x.name), owner: parts[0] || '', group: parts[1] || '', recursive: rec
    }).then(function (r) { after(r, 'chown failed'); });
  }

  function doCompress(name) {
    post('/api/fs/compress', { path: join(cwd, name) })
      .then(function (r) { after(r, 'compress failed'); });
  }

  function doExtract(name) {
    if (!confirm('Extract ' + name + ' into this directory? Existing files are overwritten.')) return;
    post('/api/fs/extract', { path: join(cwd, name) })
      .then(function (r) { after(r, 'extract failed'); });
  }

  function doDelete(x) {
    var warn = x.type === 'dir'
      ? 'Delete DIRECTORY ' + x.name + ' and everything inside it?'
      : 'Delete ' + x.name + '?';
    if (!confirm(warn)) return;
    post('/api/fs/delete', { path: join(cwd, x.name) })
      .then(function (r) { after(r, 'delete failed'); });
  }

  /* ---------------- editor ---------------- */

  function openEditor(path) {
    api('/api/fs/read?path=' + encodeURIComponent(path)).then(function (res) {
      if (!res.ok) {
        if (/2 MB/.test(res.error || '')) {
          location.href = '/api/fs/download?path=' + encodeURIComponent(path);
        } else err(res.error || 'read failed');
        return;
      }
      if (res.data.binary) {
        if (confirm('Binary file — download instead?')) {
          location.href = '/api/fs/download?path=' + encodeURIComponent(path);
        }
        return;
      }
      editing = res.data.path;
      $('fm-editor-path').textContent = editing + ' (' + fmtBytes(res.data.size) + ')';
      $('fm-editor-text').value = atob2utf8(res.data.content_b64);
      $('fm-editor').classList.remove('d-none');
      $('fm-editor-text').focus();
    });
  }

  function atob2utf8(b64) {
    var bin = atob(b64), bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder('utf-8').decode(bytes);
  }
  function utf82b64(str) {
    var bytes = new TextEncoder().encode(str), bin = '';
    for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }

  function saveEditor() {
    if (!editing) return;
    post('/api/fs/write', { path: editing, content_b64: utf82b64($('fm-editor-text').value) })
      .then(function (r) {
        $('fm-editor-note').textContent = r.ok ? 'Saved ✓' : ('Save failed: ' + (r.error || ''));
        if (r.ok) setTimeout(function () { $('fm-editor-note').textContent = 'Ctrl+S to save'; }, 1500);
      });
  }

  $('fm-editor-save').addEventListener('click', saveEditor);
  $('fm-editor-close').addEventListener('click', function () {
    $('fm-editor').classList.add('d-none');
    editing = null;
    load(cwd);
  });
  $('fm-editor-text').addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveEditor(); }
    if (e.key === 'Tab') {
      e.preventDefault();
      var t = e.target, s = t.selectionStart;
      t.value = t.value.slice(0, s) + '    ' + t.value.slice(t.selectionEnd);
      t.selectionStart = t.selectionEnd = s + 4;
    }
  });

  /* ---------------- toolbar ---------------- */

  $('fm-up').addEventListener('click', function () {
    if (cwd === '/') return;
    load(cwd.replace(/\/[^/]+\/?$/, '') || '/');
  });
  $('fm-go').addEventListener('click', function () { load($('fm-path').value.trim() || '/'); });
  $('fm-path').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') load($('fm-path').value.trim() || '/');
  });
  $('fm-refresh').addEventListener('click', function () { load(cwd); });

  $('fm-newdir').addEventListener('click', function () {
    var n = prompt('New folder name:');
    if (!n) return;
    post('/api/fs/mkdir', { path: join(cwd, n) }).then(function (r) { after(r, 'mkdir failed'); });
  });
  $('fm-newfile').addEventListener('click', function () {
    var n = prompt('New file name:');
    if (!n) return;
    post('/api/fs/write', { path: join(cwd, n), content_b64: '', create: true })
      .then(function (r) { after(r, 'create failed'); });
  });

  /* ---------------- upload ---------------- */

  $('fm-upload').addEventListener('click', function () { $('fm-file-input').click(); });
  $('fm-file-input').addEventListener('change', function () {
    var files = Array.prototype.slice.call(this.files);
    this.value = '';
    uploadNext(files, 0);
  });

  function uploadNext(files, i) {
    if (i >= files.length) {
      $('fm-progress').classList.add('d-none');
      load(cwd);
      return;
    }
    var f = files[i];
    $('fm-progress').classList.remove('d-none');
    sendFile(f, false, function done(res) {
      if (!res.ok && res.exists) {
        if (confirm(f.name + ' exists — overwrite?')) {
          sendFile(f, true, function (r2) {
            if (!r2.ok) err('Upload failed: ' + (r2.error || ''));
            uploadNext(files, i + 1);
          });
          return;
        }
      } else if (!res.ok) {
        err('Upload failed: ' + (res.error || ''));
      }
      uploadNext(files, i + 1);
    });
  }

  function sendFile(f, overwrite, done) {
    var fd = new FormData();
    fd.append('_csrf', window.BP_CSRF);
    fd.append('dest', cwd);
    if (overwrite) fd.append('overwrite', '1');
    fd.append('file', f);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/fs/upload');
    xhr.upload.onprogress = function (ev) {
      if (!ev.lengthComputable) return;
      var pct = (ev.loaded / ev.total) * 100;
      document.getElementById('fm-progress-bar').style.width = pct.toFixed(0) + '%';
      document.getElementById('fm-progress-text').textContent =
        f.name + ' — ' + fmtBytes(ev.loaded) + ' / ' + fmtBytes(ev.total);
    };
    xhr.onload = function () {
      var res = {};
      try { res = JSON.parse(xhr.responseText); } catch (e) { res = { ok: false, error: 'bad response' }; }
      done(res);
    };
    xhr.onerror = function () { done({ ok: false, error: 'network error' }); };
    xhr.send(fd);
  }

  /* ---------------- boot ---------------- */

  var start = decodeURIComponent((location.hash || '').replace(/^#/, '')) || '/var/www';
  load(start[0] === '/' ? start : '/');
})();
