/* BitPanel firewall */
(function () {
  'use strict';
  if (!document.getElementById('fw-table')) return;

  var fwActive = false;

  function $(id) { return document.getElementById(id); }
  function api(u) { return fetch(u).then(function (r) {
    if (r.status === 401) { location.href = '/login'; throw new Error('auth'); } return r.json(); }); }
  function post(u, b) { return fetch(u, { method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF': window.BP_CSRF }, body: JSON.stringify(b || {}) })
    .then(function (r) { if (r.status === 401) { location.href = '/login'; throw new Error('auth'); } return r.json(); }); }
  function err(m) { var b = $('fw-error'); if (m) { b.textContent = m; b.classList.remove('d-none'); } else b.classList.add('d-none'); }
  function ok(m) { var b = $('fw-ok'); if (m) { b.textContent = m; b.classList.remove('d-none'); setTimeout(function () { b.classList.add('d-none'); }, 4000); } else b.classList.add('d-none'); }
  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function addBtn(cell, label, fn) { var b = document.createElement('button'); b.className = 'bp-act'; b.textContent = label; b.addEventListener('click', fn); cell.appendChild(b); }

  /* ---- ufw ---- */
  function loadStatus() {
    api('/api/fw/status').then(function (res) {
      if (!res.ok) { err(res.error || 'status failed'); return; }
      var d = res.data;
      if (!d.installed) {
        $('fw-state').textContent = 'not installed';
        $('fw-state').className = 'bp-state mid';
        $('fw-toggle').textContent = 'Install & enable';
        $('fw-summary').textContent = 'UFW is not installed';
        fwActive = false;
        $('fw-body').classList.add('d-none');
        return;
      }
      fwActive = d.active;
      $('fw-state').textContent = d.active ? 'active' : 'inactive';
      $('fw-state').className = 'bp-state ' + (d.active ? 'ok' : 'bad');
      $('fw-default').textContent = d.active ? ('  · default in: ' + d.default_in + ', out: ' + d.default_out) : '';
      $('fw-toggle').textContent = d.active ? 'Disable firewall' : 'Enable firewall';
      $('fw-summary').textContent = d.active ? 'UFW active' : 'UFW inactive';
      $('fw-body').classList.toggle('d-none', !d.active);
      if (d.active) loadRules();
    }).catch(function () { err('Panel could not reach the agent.'); });
  }

  function loadRules() {
    api('/api/fw/rules').then(function (res) {
      var tb = $('fw-table').tBodies[0]; tb.innerHTML = '';
      if (!res.ok) { err(res.error || 'rules failed'); return; }
      if (!res.data.length) { tb.innerHTML = '<tr><td colspan="5" class="text-muted">No rules.</td></tr>'; return; }
      res.data.forEach(function (r) {
        var tr = document.createElement('tr');
        var act = r.action.indexOf('ALLOW') === 0 ? 'ok' : 'bad';
        tr.innerHTML = '<td class="bp-sub">' + r.num + '</td>' +
          '<td class="bp-unit">' + escapeHtml(r.to) + '</td>' +
          '<td><span class="bp-state ' + act + '">' + escapeHtml(r.action) + '</span></td>' +
          '<td class="bp-sub">' + escapeHtml(r.from) + '</td><td class="text-end"></td>';
        addBtn(tr.lastElementChild, 'delete', function () { delRule(r.num, r.to); });
        tb.appendChild(tr);
      });
    });
  }

  $('fw-toggle').addEventListener('click', function () {
    err(''); ok('');
    if (fwActive && !confirm('Disable the firewall? All ports will be open to the network.')) return;
    if (!fwActive && !confirm('Enable the firewall?\nSSH and this panel port stay open automatically. All other inbound ports will be blocked unless you add rules.')) return;
    var btn = this; btn.disabled = true;
    ok(fwActive ? 'Disabling…' : 'Enabling (may install ufw)…');
    post('/api/fw/toggle', { enable: !fwActive }).then(function (res) {
      if (res.ok) ok(typeof res.data === 'string' ? res.data : 'done');
      else err(res.error || 'toggle failed');
      loadStatus();
    }).catch(function () { err('Request failed.'); }).finally(function () { btn.disabled = false; });
  });

  $('fw-add').addEventListener('click', function () {
    var port = $('fw-port').value.trim();
    if (!port) { err('Enter a port.'); return; }
    post('/api/fw/add', { action: $('fw-action').value, port: port,
      proto: $('fw-proto').value, source: $('fw-source').value.trim() })
      .then(function (res) {
        if (res.ok) { ok('Rule added.'); $('fw-port').value = ''; $('fw-source').value = ''; loadRules(); }
        else err(res.error || 'add failed');
      });
  });

  function delRule(num, to) {
    if (!confirm('Delete rule #' + num + ' (' + to + ')?')) return;
    post('/api/fw/delete', { num: num }).then(function (res) {
      if (res.ok) { ok('Rule deleted.'); loadRules(); } else err(res.error || 'delete failed');
    });
  }

  /* ---- fail2ban ---- */
  function loadF2b() {
    api('/api/f2b/status').then(function (res) {
      var wrap = $('f2b-jails'); wrap.innerHTML = '';
      if (!res.ok) { $('f2b-summary').textContent = 'status unavailable'; return; }
      var d = res.data;
      if (!d.installed) { $('f2b-summary').textContent = 'Fail2ban is not installed (add it from the component installer).'; return; }
      if (!d.active) { $('f2b-summary').textContent = 'Fail2ban is installed but not running.'; return; }
      if (!d.jails.length) { $('f2b-summary').textContent = 'Fail2ban running · no jails configured.'; return; }
      $('f2b-summary').textContent = 'Fail2ban running · jails: ' + d.jails.join(', ');
      d.jails.forEach(function (j) { loadJail(j, wrap); });
    }).catch(function () { $('f2b-summary').textContent = 'status unavailable'; });
  }

  function loadJail(jail, wrap) {
    api('/api/f2b/jail?jail=' + encodeURIComponent(jail)).then(function (res) {
      if (!res.ok) return;
      var d = res.data;
      var box = document.createElement('div');
      box.className = 'f2b-jail';
      var head = document.createElement('div');
      head.className = 'bp-sub';
      head.innerHTML = '<strong>' + escapeHtml(jail) + '</strong> — currently banned: ' + d.banned + ', failures: ' + d.failed;
      box.appendChild(head);
      if (d.ips.length) {
        var tbl = document.createElement('div');
        tbl.className = 'f2b-ips';
        d.ips.forEach(function (ip) {
          var row = document.createElement('span');
          row.className = 'f2b-ip';
          row.innerHTML = '<code>' + escapeHtml(ip) + '</code>';
          var b = document.createElement('button');
          b.className = 'bp-act'; b.textContent = 'unban';
          b.addEventListener('click', function () { unban(jail, ip); });
          row.appendChild(b);
          tbl.appendChild(row);
        });
        box.appendChild(tbl);
      }
      wrap.appendChild(box);
    });
  }

  function unban(jail, ip) {
    post('/api/f2b/unban', { jail: jail, ip: ip }).then(function (res) {
      if (res.ok) { ok('Unbanned ' + ip); loadF2b(); } else err(res.error || 'unban failed');
    });
  }

  loadStatus();
  loadF2b();
})();
