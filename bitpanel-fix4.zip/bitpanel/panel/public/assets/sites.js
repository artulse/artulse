/* BitPanel sites & SSL */
(function () {
  'use strict';
  var table = document.getElementById('st-table');
  if (!table) return;

  function $(id) { return document.getElementById(id); }
  function api(u) { return fetch(u).then(function (r) {
    if (r.status === 401) { location.href = '/login'; throw new Error('auth'); }
    return r.json();
  }); }
  function post(u, b) {
    return fetch(u, { method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF': window.BP_CSRF },
      body: JSON.stringify(b || {}) }).then(function (r) {
      if (r.status === 401) { location.href = '/login'; throw new Error('auth'); }
      return r.json();
    });
  }
  function err(m) { var b = $('st-error'); if (m) { b.textContent = m; b.classList.remove('d-none'); } else b.classList.add('d-none'); }
  function ok(m) { var b = $('st-ok'); if (m) { b.textContent = m; b.classList.remove('d-none'); setTimeout(function () { b.classList.add('d-none'); }, 4000); } else b.classList.add('d-none'); }

  function expiryText(ts) {
    if (!ts) return '';
    var days = Math.round((ts * 1000 - Date.now()) / 86400000);
    return ' · ' + days + 'd left';
  }

  /* ---- type-dependent form fields ---- */
  function syncForm() {
    var t = $('st-type').value;
    $('st-php-row').classList.toggle('d-none', t !== 'php');
    $('st-root-row').classList.toggle('d-none', t === 'proxy');
    $('st-up-row').classList.toggle('d-none', t !== 'proxy');
  }
  $('st-type').addEventListener('change', syncForm);

  function loadPhp() {
    api('/api/php-versions').then(function (res) {
      var sel = $('st-php');
      sel.innerHTML = '';
      if (res.ok && res.data.length) {
        res.data.forEach(function (v) {
          var o = document.createElement('option');
          o.value = v.version; o.textContent = 'PHP ' + v.version;
          sel.appendChild(o);
        });
      } else {
        sel.innerHTML = '<option value="">none installed</option>';
      }
    }).catch(function () {});
  }

  /* ---- listing ---- */
  function load() {
    err('');
    api('/api/sites').then(function (res) {
      if (!res.ok) { err(res.error || 'list failed'); return; }
      render(res.data);
    }).catch(function (e) { if (e.message !== 'auth') err('Panel could not reach the agent.'); });
  }

  function render(list) {
    var tb = table.tBodies[0];
    tb.innerHTML = '';
    $('st-count').textContent = list.length + ' site' + (list.length === 1 ? '' : 's');
    if (!list.length) {
      tb.innerHTML = '<tr><td colspan="6" class="text-muted">No sites yet.</td></tr>';
      return;
    }
    list.forEach(function (s) {
      var tr = document.createElement('tr');
      var target = s.type === 'proxy' ? s.upstream : (s.root + (s.php ? ' · PHP ' + s.php : ''));
      var primary = s.domains[0] + (s.domains.length > 1 ? ' +' + (s.domains.length - 1) : '');
      var sslCell = s.ssl
        ? '<span class="bp-state ok">HTTPS' + (s.force_https ? ' (forced)' : '') + '</span>'
          + '<span class="bp-sub">' + expiryText(s.cert_expiry) + '</span>'
        : '<span class="bp-state mid">http only</span>';
      var wafCell = s.waf ? '<span class="bp-state ok">on</span>' : '<span class="bp-state mid">off</span>';

      var nameHtml = '<span class="bp-unit">' + primary + '</span>'
        + (s.enabled ? '' : ' <span class="bp-state bad">disabled</span>');

      tr.innerHTML =
        '<td>' + nameHtml + '</td>' +
        '<td class="bp-sub">' + s.type + '</td>' +
        '<td class="bp-sub st-target">' + escapeHtml(target) + '</td>' +
        '<td>' + sslCell + '</td>' +
        '<td>' + wafCell + '</td>' +
        '<td class="text-end st-actions"></td>';

      var act = tr.querySelector('.st-actions');
      if (!s.ssl) addBtn(act, 'Secure', function () { doSsl(s); });
      addBtn(act, s.waf ? 'WAF off' : 'WAF on', function () { doWaf(s); });
      addBtn(act, s.enabled ? 'disable' : 'enable', function () { doToggle(s); });
      addBtn(act, 'delete', function () { doDelete(s); });
      tb.appendChild(tr);
    });
  }

  function addBtn(cell, label, fn) {
    var b = document.createElement('button');
    b.className = 'bp-act'; b.textContent = label;
    b.addEventListener('click', fn); cell.appendChild(b);
  }
  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---- actions ---- */
  $('st-create').addEventListener('click', function () {
    var domains = $('st-domains').value.split(',').map(function (d) { return d.trim(); }).filter(Boolean);
    if (!domains.length) { err('Enter at least one domain.'); return; }
    var body = { domains: domains, type: $('st-type').value,
      root: $('st-root').value.trim(), php: $('st-php').value,
      upstream: $('st-upstream').value.trim() };
    var btn = this; btn.disabled = true;
    post('/api/sites/create', body).then(function (r) {
      if (r.ok) { ok('Site created: ' + domains[0]); $('st-domains').value = ''; $('st-root').value = ''; $('st-upstream').value = ''; load(); }
      else err(r.error || 'create failed');
    }).catch(function () { err('Create request failed.'); })
      .finally(function () { btn.disabled = false; });
  });

  function doToggle(s) {
    post('/api/sites/toggle', { id: s.id, enable: !s.enabled })
      .then(function (r) { if (!r.ok) err(r.error || 'toggle failed'); load(); });
  }

  function doWaf(s) {
    var enable = !s.waf;
    if (enable && !confirm('Enable WAF for ' + s.domains[0] + '?\nBlocks common SQLi/XSS/path-traversal/scanner patterns and rate-limits requests. Native nginx rules, not full ModSecurity/OWASP CRS.')) return;
    post('/api/sites/waf', { id: s.id, enable: enable })
      .then(function (r) { if (!r.ok) err(r.error || 'WAF toggle failed'); load(); });
  }

  function doDelete(s) {
    if (!confirm('Delete site ' + s.domains[0] + '?\nThe nginx config and certificate are removed. The document root and its files are left in place.')) return;
    post('/api/sites/delete', { id: s.id })
      .then(function (r) { if (r.ok) ok(r.data || 'deleted'); else err(r.error || 'delete failed'); load(); });
  }

  function doSsl(s) {
    if (!confirm('Issue a Let\'s Encrypt certificate for:\n' + s.domains.join(', ')
        + '\n\nThe domain(s) must already point to this server with port 80 open.')) return;
    var redirect = confirm('Force HTTP -> HTTPS redirect once the certificate is installed?\n\nOK = redirect all traffic to HTTPS\nCancel = keep HTTP reachable too');
    ok('Requesting certificate… this can take 15-30s.');
    post('/api/sites/ssl', { id: s.id, force_https: redirect })
      .then(function (r) {
        if (r.ok) ok('Certificate installed for ' + s.domains[0] + '.');
        else err(r.error || 'SSL issuance failed');
        load();
      }).catch(function () { err('SSL request failed.'); });
  }

  syncForm();
  loadPhp();
  load();
})();
