<?php
declare(strict_types=1);

/** /api/cleanup/* — included by public/index.php. */

function cl_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$clRoute = substr($path, strlen('/api/'));

switch ($clRoute . ':' . $method) {

    case 'cleanup/disk-usage:GET':
        json_out(AgentClient::call('cleanup.disk_usage', [], 30));

    case 'cleanup/scan:GET':
        json_out(AgentClient::call('cleanup.scan', [], 40));

    case 'cleanup/run:POST':
        csrf_check();
        $b = cl_body();
        $res = AgentClient::call('cleanup.run', [
            'action' => (string)($b['action'] ?? ''),
            'params' => is_array($b['params'] ?? null) ? $b['params'] : [],
        ], 150);
        audit('cleanup.' . (string)($b['action'] ?? ''), !empty($res['ok']) ? (string)($res['data'] ?? 'ok') : (string)($res['error'] ?? 'err'));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
