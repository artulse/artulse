<?php
declare(strict_types=1);

/** Dependency-free TOTP (RFC 6238), SHA1 / 6 digits / 30s. */
final class Totp
{
    private const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    private const PERIOD    = 30;
    private const DIGITS    = 6;

    public static function generateSecret(int $bytes = 20): string
    {
        return self::base32encode(random_bytes($bytes));
    }

    public static function code(string $secret, ?int $t = null): string
    {
        $key = self::base32decode($secret);
        $counter = (int)floor(($t ?? time()) / self::PERIOD);
        $hash = hash_hmac('sha1', pack('J', $counter), $key, true);
        $off  = ord($hash[19]) & 0x0f;
        $val  = ((ord($hash[$off]) & 0x7f) << 24)
              | ((ord($hash[$off + 1]) & 0xff) << 16)
              | ((ord($hash[$off + 2]) & 0xff) << 8)
              |  (ord($hash[$off + 3]) & 0xff);
        return str_pad((string)($val % (10 ** self::DIGITS)), self::DIGITS, '0', STR_PAD_LEFT);
    }

    public static function verify(string $secret, string $code, int $window = 1): bool
    {
        $code = preg_replace('/\D/', '', $code);
        if ($code === null || strlen($code) !== self::DIGITS || $secret === '') {
            return false;
        }
        $t = time();
        for ($w = -$window; $w <= $window; $w++) {
            if (hash_equals(self::code($secret, $t + $w * self::PERIOD), $code)) {
                return true;
            }
        }
        return false;
    }

    public static function uri(string $secret, string $account, string $issuer = 'BitPanel'): string
    {
        $label = rawurlencode($issuer) . ':' . rawurlencode($account);
        $q = http_build_query([
            'secret' => $secret, 'issuer' => $issuer,
            'algorithm' => 'SHA1', 'digits' => self::DIGITS, 'period' => self::PERIOD,
        ]);
        return "otpauth://totp/{$label}?{$q}";
    }

    public static function base32encode(string $bin): string
    {
        if ($bin === '') { return ''; }
        $bits = '';
        foreach (str_split($bin) as $c) {
            $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 5) as $chunk) {
            $out .= self::ALPHABET[bindec(str_pad($chunk, 5, '0', STR_PAD_RIGHT))];
        }
        return $out;
    }

    public static function base32decode(string $b32): string
    {
        $b32 = strtoupper((string)preg_replace('/[^A-Za-z2-7]/', '', $b32));
        if ($b32 === '') { return ''; }
        $bits = '';
        foreach (str_split($b32) as $ch) {
            $bits .= str_pad(decbin(strpos(self::ALPHABET, $ch)), 5, '0', STR_PAD_LEFT);
        }
        $bin = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) { $bin .= chr(bindec($byte)); }
        }
        return $bin;
    }
}
