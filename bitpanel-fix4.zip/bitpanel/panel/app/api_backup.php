<?php
declare(strict_types=1);

/** /api/backup/* and /api/s3/* — included by public/index.php. */

function bk_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$bkRoute = substr($path, strlen('/api/'));

switch ($bkRoute . ':' . $method) {

    case 'backup/list:GET':
        json_out(AgentClient::call('backup.list'));

    case 'backup/create:POST':
        csrf_check();
        $b = bk_body();
        $res = AgentClient::call('backup.create', [
            'type' => (string)($b['type'] ?? ''), 'target' => (string)($b['target'] ?? ''),
        ], 900);
        audit('backup.create', (string)($b['type'] ?? '') . ':' . (string)($b['target'] ?? ''));
        json_out($res);

    case 'backup/delete:POST':
        csrf_check();
        $b = bk_body();
        $res = AgentClient::call('backup.delete', ['name' => (string)($b['name'] ?? '')], 30);
        audit('backup.delete', (string)($b['name'] ?? ''));
        json_out($res);

    case 's3/get:GET':
        json_out(AgentClient::call('s3.get'));

    case 's3/set:POST':
        csrf_check();
        $b = bk_body();
        $res = AgentClient::call('s3.set', [
            'bucket' => (string)($b['bucket'] ?? ''), 'region' => (string)($b['region'] ?? ''),
            'prefix' => (string)($b['prefix'] ?? ''),
            'access_key' => (string)($b['access_key'] ?? ''), 'secret_key' => (string)($b['secret_key'] ?? ''),
        ], 30);
        audit('s3.config', (string)($b['bucket'] ?? ''));
        json_out($res);

    case 's3/push:POST':
        csrf_check();
        $b = bk_body();
        $res = AgentClient::call('s3.push', ['name' => (string)($b['name'] ?? '')], 600);
        audit('s3.push', (string)($b['name'] ?? '') . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    /* ---- scheduled backup jobs ---- */
    case 'bkjob/list:GET':
        json_out(AgentClient::call('bkjob.list'));

    case 'bkjob/create:POST':
        csrf_check();
        $b = bk_body();
        $res = AgentClient::call('bkjob.create', [
            'type' => (string)($b['type'] ?? ''), 'target' => (string)($b['target'] ?? ''),
            'schedule' => (string)($b['schedule'] ?? ''), 'keep' => (int)($b['keep'] ?? 7),
            's3' => !empty($b['s3']),
        ], 30);
        audit('bkjob.create', (string)($b['type'] ?? '') . ':' . (string)($b['target'] ?? ''));
        json_out($res);

    case 'bkjob/delete:POST':
        csrf_check();
        $b = bk_body();
        $res = AgentClient::call('bkjob.delete', ['id' => (string)($b['id'] ?? '')], 30);
        audit('bkjob.delete', (string)($b['id'] ?? ''));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
