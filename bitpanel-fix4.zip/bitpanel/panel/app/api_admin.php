<?php
declare(strict_types=1);

/** /api/ftp/* /api/users/* /api/tokens/* — included by public/index.php. */

function ad_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$adRoute = substr($path, strlen('/api/'));

switch ($adRoute . ':' . $method) {

    /* ---- FTP (vsftpd, system users via agent) ---- */
    case 'ftp/status:GET':
        json_out(AgentClient::call('ftp.status'));

    case 'ftp/users:GET':
        json_out(AgentClient::call('ftp.users'));

    case 'ftp/setup:POST':
        csrf_check();
        $res = AgentClient::call('ftp.setup', [], 340);
        audit('ftp.setup', !empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err'));
        json_out($res);

    case 'ftp/add:POST':
        csrf_check();
        $b = ad_body();
        $res = AgentClient::call('ftp.add', [
            'user' => (string)($b['user'] ?? ''), 'password' => (string)($b['password'] ?? ''),
            'dir' => (string)($b['dir'] ?? ''),
        ], 40);
        audit('ftp.add', (string)($b['user'] ?? ''));
        json_out($res);

    case 'ftp/delete:POST':
        csrf_check();
        $b = ad_body();
        $res = AgentClient::call('ftp.delete', ['user' => (string)($b['user'] ?? '')], 40);
        audit('ftp.delete', (string)($b['user'] ?? ''));
        json_out($res);

    case 'ftp/password:POST':
        csrf_check();
        $b = ad_body();
        $res = AgentClient::call('ftp.password', [
            'user' => (string)($b['user'] ?? ''), 'password' => (string)($b['password'] ?? ''),
        ], 30);
        audit('ftp.password', (string)($b['user'] ?? ''));
        json_out($res);

    /* ---- panel users & roles (SQLite) ---- */
    case 'users/list:GET':
        $rows = db()->query('SELECT id, username, role, totp_secret, created_at FROM users ORDER BY username')->fetchAll();
        $out = [];
        foreach ($rows as $r) {
            $out[] = ['id' => (int)$r['id'], 'username' => $r['username'], 'role' => $r['role'],
                      'twofa' => !empty($r['totp_secret']), 'created_at' => (int)$r['created_at']];
        }
        json_out(['ok' => true, 'data' => $out]);

    case 'users/create:POST':
        csrf_check();
        $b = ad_body();
        $u = trim((string)($b['username'] ?? ''));
        $p = (string)($b['password'] ?? '');
        $role = (string)($b['role'] ?? 'viewer');
        if (!preg_match('/^[A-Za-z0-9_.\-]{2,32}$/', $u)) { json_out(['ok' => false, 'error' => 'username: 2–32 chars, letters/digits/._-']); }
        if (strlen($p) < 10) { json_out(['ok' => false, 'error' => 'password must be at least 10 characters']); }
        if (!in_array($role, ['admin', 'viewer'], true)) { json_out(['ok' => false, 'error' => 'role must be admin or viewer']); }
        try {
            db()->prepare('INSERT INTO users (username, pass_hash, role, created_at) VALUES (?,?,?,?)')
                ->execute([$u, password_hash($p, PASSWORD_BCRYPT), $role, time()]);
        } catch (Throwable $e) {
            json_out(['ok' => false, 'error' => 'username already exists']);
        }
        audit('user.create', $u . ' (' . $role . ')');
        json_out(['ok' => true]);

    case 'users/role:POST':
        csrf_check();
        $b = ad_body();
        $id = (int)($b['id'] ?? 0);
        $role = (string)($b['role'] ?? '');
        if (!in_array($role, ['admin', 'viewer'], true)) { json_out(['ok' => false, 'error' => 'bad role']); }
        // never leave zero admins
        if ($role === 'viewer') {
            $admins = (int)db()->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch()['c'];
            $q = db()->prepare('SELECT role FROM users WHERE id = ?'); $q->execute([$id]);
            $isAdmin = ($q->fetch()['role'] ?? '') === 'admin';
            if ($admins <= 1 && $isAdmin) { json_out(['ok' => false, 'error' => 'cannot demote the last admin']); }
        }
        db()->prepare('UPDATE users SET role = ? WHERE id = ?')->execute([$role, $id]);
        audit('user.role', '#' . $id . ' → ' . $role);
        json_out(['ok' => true]);

    case 'users/password:POST':
        csrf_check();
        $b = ad_body();
        $id = (int)($b['id'] ?? 0);
        $p = (string)($b['password'] ?? '');
        if (strlen($p) < 10) { json_out(['ok' => false, 'error' => 'password must be at least 10 characters']); }
        db()->prepare('UPDATE users SET pass_hash = ? WHERE id = ?')->execute([password_hash($p, PASSWORD_BCRYPT), $id]);
        audit('user.password', '#' . $id);
        json_out(['ok' => true]);

    case 'users/delete:POST':
        csrf_check();
        $b = ad_body();
        $id = (int)($b['id'] ?? 0);
        if ($id === (int)($_SESSION['uid'] ?? -1)) { json_out(['ok' => false, 'error' => 'you cannot delete your own account']); }
        $admins = (int)db()->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch()['c'];
        $tq = db()->prepare('SELECT username, role FROM users WHERE id = ?'); $tq->execute([$id]); $target = $tq->fetch();
        if (!$target) { json_out(['ok' => false, 'error' => 'user not found']); }
        if ($target['role'] === 'admin' && $admins <= 1) { json_out(['ok' => false, 'error' => 'cannot delete the last admin']); }
        db()->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
        audit('user.delete', (string)$target['username']);
        json_out(['ok' => true]);

    /* ---- API tokens ---- */
    case 'tokens/list:GET':
        $rows = db()->query('SELECT id, label, created_at, last_used FROM api_tokens ORDER BY created_at DESC')->fetchAll();
        json_out(['ok' => true, 'data' => $rows]);

    case 'tokens/create:POST':
        csrf_check();
        $b = ad_body();
        $label = trim((string)($b['label'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9 _.\-]{1,40}$/', $label)) { json_out(['ok' => false, 'error' => 'label: 1–40 chars']); }
        $token = 'bp_' . bin2hex(random_bytes(24));
        db()->prepare('INSERT INTO api_tokens (label, token_hash, created_at) VALUES (?,?,?)')
            ->execute([$label, hash('sha256', $token), time()]);
        audit('token.create', $label);
        // token shown once, never stored in plain text
        json_out(['ok' => true, 'token' => $token]);

    case 'tokens/delete:POST':
        csrf_check();
        $b = ad_body();
        $id = (int)($b['id'] ?? 0);
        db()->prepare('DELETE FROM api_tokens WHERE id = ?')->execute([$id]);
        audit('token.delete', '#' . $id);
        json_out(['ok' => true]);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
