<?php
declare(strict_types=1);

/** /api/sites/* and /api/php-versions — included by public/index.php. */

function s_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$sRoute = substr($path, strlen('/api/'));

switch ($sRoute . ':' . $method) {

    case 'php-versions:GET':
        json_out(AgentClient::call('php.versions'));

    case 'sites:GET':
        json_out(AgentClient::call('site.list'));

    case 'sites/create:POST':
        csrf_check();
        $b = s_body();
        $res = AgentClient::call('site.create', [
            'domains'  => (array)($b['domains'] ?? []),
            'type'     => (string)($b['type'] ?? ''),
            'root'     => (string)($b['root'] ?? ''),
            'php'      => (string)($b['php'] ?? ''),
            'upstream' => (string)($b['upstream'] ?? ''),
            'id'       => (string)($b['id'] ?? ''),
        ], 60);
        audit('site.create', (string)($b['type'] ?? '') . ' ' . implode(',', (array)($b['domains'] ?? []))
            . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'sites/toggle:POST':
        csrf_check();
        $b = s_body();
        $res = AgentClient::call('site.toggle', [
            'id' => (string)($b['id'] ?? ''), 'enable' => !empty($b['enable']),
        ], 30);
        audit('site.toggle', (string)($b['id'] ?? '') . ' enable=' . (!empty($b['enable']) ? '1' : '0'));
        json_out($res);

    case 'sites/delete:POST':
        csrf_check();
        $b = s_body();
        $res = AgentClient::call('site.delete', ['id' => (string)($b['id'] ?? '')], 60);
        audit('site.delete', (string)($b['id'] ?? ''));
        json_out($res);

    case 'sites/ssl:POST':
        csrf_check();
        $b = s_body();
        $res = AgentClient::call('ssl.issue', [
            'id' => (string)($b['id'] ?? ''), 'force_https' => !empty($b['force_https']),
        ], 340);
        audit('ssl.issue', (string)($b['id'] ?? '')
            . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'sites/waf:POST':
        csrf_check();
        $b = s_body();
        $res = AgentClient::call('site.waf_toggle', [
            'id' => (string)($b['id'] ?? ''), 'enable' => !empty($b['enable']),
        ], 30);
        audit('site.waf', (string)($b['id'] ?? '') . ' enable=' . (!empty($b['enable']) ? '1' : '0'));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown sites endpoint'], 404);
}
