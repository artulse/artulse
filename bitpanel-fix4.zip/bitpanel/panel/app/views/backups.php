<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>Backups</h1><div class="bp-hostline" id="bk-count"></div></div>
<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>
<div class="bp-panel">
  <div class="bp-panel-title">Create backup</div>
  <div class="st-row">
    <select class="form-select" id="bk-type" style="max-width:160px">
      <option value="site">Site</option>
      <option value="db">Database</option>
      <option value="path">Path</option>
    </select>
    <select class="form-select" id="bk-target" style="max-width:260px"></select>
    <input class="form-control d-none" id="bk-path" placeholder="/var/www/something" spellcheck="false" style="max-width:260px;font-family:var(--bp-mono)">
    <button class="btn bp-btn" id="bk-create">Create</button>
  </div>
</div>
<div class="bp-panel">
  <div class="bp-panel-title">Backups</div>
  <table class="table bp-table mb-0" id="bk-table">
    <thead><tr><th>Name</th><th>Type</th><th>Size</th><th>Created</th><th class="text-end">Actions</th></tr></thead>
    <tbody><tr><td colspan="5" class="text-muted">Loading…</td></tr></tbody>
  </table>
</div>
<div class="bp-panel" style="max-width:560px">
  <div class="bp-panel-title">Amazon S3 (optional)</div>
  <div id="bk-s3-state" class="bp-sub mb-2"></div>
  <div class="st-form">
    <div class="st-row"><label>Bucket</label><input class="form-control" id="s3-bucket" spellcheck="false"></div>
    <div class="st-row"><label>Region</label><input class="form-control" id="s3-region" placeholder="ap-south-1" spellcheck="false"></div>
    <div class="st-row"><label>Prefix</label><input class="form-control" id="s3-prefix" placeholder="backups/ (optional)" spellcheck="false"></div>
    <div class="st-row"><label>Access key</label><input class="form-control" id="s3-ak" spellcheck="false" placeholder="leave blank to keep"></div>
    <div class="st-row"><label>Secret key</label><input class="form-control" id="s3-sk" type="password" placeholder="leave blank to keep"></div>
    <div class="st-row"><label></label><button class="btn bp-btn" id="s3-save">Save S3 settings</button></div>
  </div>
</div>
<div class="bp-panel">
  <div class="bp-panel-title">Scheduled backup jobs</div>
  <div class="st-row">
    <select class="form-select" id="bj-type" style="max-width:140px">
      <option value="site">Site</option><option value="db">Database</option><option value="path">Path</option>
    </select>
    <select class="form-select" id="bj-target" style="max-width:220px"></select>
    <input class="form-control d-none" id="bj-path" placeholder="/var/www/x" spellcheck="false" style="max-width:220px;font-family:var(--bp-mono)">
    <input class="form-control" id="bj-sched" placeholder="0 3 * * *" spellcheck="false" style="max-width:150px;font-family:var(--bp-mono)">
    <input class="form-control" id="bj-keep" type="number" value="7" min="1" max="100" style="max-width:90px" title="keep last N">
    <label class="bp-sub"><input type="checkbox" id="bj-s3"> S3</label>
    <button class="btn bp-btn" id="bj-create">Add job</button>
  </div>
  <table class="table bp-table mb-0 mt-2" id="bj-table">
    <thead><tr><th>Job</th><th>Schedule</th><th>Keep</th><th>S3</th><th class="text-end"></th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
