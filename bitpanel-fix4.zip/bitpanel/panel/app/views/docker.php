<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>Docker</h1><div class="bp-hostline" id="dk-summary"></div></div>
<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>
<div id="dk-none" class="bp-panel d-none"><div class="bp-panel-title">Docker not installed</div><p class="bp-sub mb-0">Install it from the Software page, then reload.</p></div>
<div id="dk-wrap" class="d-none">
  <div class="bp-panel">
    <div class="st-row" style="margin-bottom:0">
      <span class="bp-panel-title" style="margin:0">Containers</span>
      <label class="bp-sub" style="margin-left:12px"><input type="checkbox" id="dk-all"> show stopped</label>
      <span class="fm-spacer"></span><button class="bp-act" id="dk-refresh">Refresh</button>
    </div>
    <table class="table bp-table mb-0 mt-2" id="dk-table">
      <thead><tr><th>Name</th><th>Image</th><th>State</th><th>Ports</th><th class="text-end">Actions</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>
  <div class="bp-panel">
    <div class="bp-panel-title">Images</div>
    <table class="table bp-table mb-0" id="dk-images">
      <thead><tr><th>Repository</th><th>Tag</th><th>ID</th><th>Size</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>
</div>
<div id="dk-logwrap" class="bp-panel d-none">
  <div class="st-row" style="margin-bottom:0"><span class="bp-panel-title" style="margin:0">Logs — <span id="dk-logname" class="bp-unit"></span></span><span class="fm-spacer"></span><button class="bp-act" id="dk-logclose">Close</button></div>
  <pre class="log-view" id="dk-logtext"></pre>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
