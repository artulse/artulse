<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>App Store</h1>
  <div class="bp-hostline">one-click applications</div>
</div>

<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none" style="white-space:pre-wrap"></div>

<div id="as-cards"></div>

<!-- WordPress install form -->
<div id="as-wp-form" class="bp-panel d-none" style="max-width:520px">
  <div class="bp-panel-title">Install WordPress</div>
  <div class="st-form">
    <div class="st-row"><label>Target site</label><select class="form-select" id="wp-site"></select></div>
    <div class="st-row"><label>Site title</label><input class="form-control" id="wp-title" placeholder="My Site"></div>
    <div class="st-row"><label>Admin user</label><input class="form-control" id="wp-user" placeholder="admin" spellcheck="false"></div>
    <div class="st-row"><label>Admin email</label><input class="form-control" id="wp-email" placeholder="you@example.com" spellcheck="false"></div>
    <div class="st-row"><label></label><button class="btn bp-btn" id="wp-install">Install</button><button class="bp-act" id="wp-cancel" style="margin-left:8px">Cancel</button></div>
  </div>
  <p class="bp-sub mb-0">Needs an existing, empty PHP site. Create one on the Sites page first.</p>
</div>

<!-- phpMyAdmin install form -->
<div id="as-pma-form" class="bp-panel d-none" style="max-width:480px">
  <div class="bp-panel-title">Install phpMyAdmin</div>
  <div class="st-row">
    <label>Target site</label><select class="form-select" id="pma-site"></select>
    <button class="btn bp-btn" id="pma-install">Install</button>
    <button class="bp-act" id="pma-cancel">Cancel</button>
  </div>
  <p class="bp-sub mt-2 mb-0">Installs into <code>/phpmyadmin</code> under the chosen site. Consider restricting access (VPN, IP allowlist) since it's a common attack target.</p>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
