<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Mail</h1>
  <div class="bp-hostline" id="ml-summary"></div>
</div>

<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>

<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <span class="bp-panel-title" style="margin:0">Status</span>
    <span id="ml-state" class="bp-state mid" style="margin-left:8px">…</span>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="ml-setup">Set up / repair mail server</button>
  </div>
  <p class="bp-sub mt-2 mb-0">Installs Postfix + Dovecot + OpenDKIM, configured as virtual-mailbox
    only — no open relay: sending out requires an authenticated login (port 587).</p>
</div>

<div id="ml-body" class="d-none">
  <div class="bp-panel" style="max-width:560px">
    <div class="bp-panel-title">Mail hostname &amp; TLS</div>
    <div class="st-row">
      <input class="form-control" id="ml-host" placeholder="mail.example.com" spellcheck="false" style="font-family:var(--bp-mono)">
      <button class="bp-act" id="ml-host-save">Save</button>
    </div>
    <p class="bp-sub mt-2 mb-1">This hostname must already point at this server's IP (an A record) before requesting a certificate.</p>
    <div class="st-row" style="margin-bottom:0">
      <span id="ml-ssl-state" class="bp-state mid">no certificate</span>
      <span class="fm-spacer"></span>
      <button class="bp-act" id="ml-ssl">Request certificate</button>
    </div>
  </div>

  <div class="bp-panel">
    <div class="bp-panel-title">Add domain</div>
    <div class="st-row">
      <input class="form-control" id="dm-domain" placeholder="example.com" spellcheck="false" style="max-width:280px">
      <button class="btn bp-btn" id="dm-add">Add domain</button>
    </div>
    <p class="bp-sub mt-2 mb-0">Generates a DKIM key. You'll get MX / SPF / DKIM / DMARC records to add wherever this domain's DNS is managed (e.g. Route 53) — BitPanel does not manage DNS itself.</p>
  </div>

  <div class="bp-panel">
    <div class="bp-panel-title">Domains</div>
    <table class="table bp-table mb-0" id="dm-table">
      <thead><tr><th>Domain</th><th>Mailboxes</th><th class="text-end">Actions</th></tr></thead>
      <tbody><tr><td colspan="3" class="text-muted">Loading…</td></tr></tbody>
    </table>
  </div>

  <div id="dm-records" class="bp-panel d-none">
    <div class="st-row" style="margin-bottom:0"><span class="bp-panel-title" style="margin:0">DNS records — <span id="dr-domain" class="bp-unit"></span></span><span class="fm-spacer"></span><button class="bp-act" id="dr-close">Close</button></div>
    <table class="table bp-table mb-0 mt-2" id="dr-table">
      <thead><tr><th>Type</th><th>Host</th><th>Value</th></tr></thead><tbody></tbody>
    </table>
  </div>

  <div class="bp-panel">
    <div class="bp-panel-title">Mailboxes</div>
    <div class="st-row">
      <input class="form-control" id="mb-email" placeholder="name@example.com" spellcheck="false" style="max-width:260px">
      <input class="form-control" id="mb-pass" type="text" placeholder="password (min 8)" spellcheck="false" style="max-width:220px">
      <button class="btn bp-btn" id="mb-add">Create mailbox</button>
    </div>
    <table class="table bp-table mb-0 mt-2" id="mb-table">
      <thead><tr><th>Email</th><th class="text-end">Actions</th></tr></thead>
      <tbody></tbody>
    </table>
    <p class="bp-sub mb-0">Any IMAP client (Thunderbird, Outlook, Apple Mail) works: server = mail hostname above, IMAP port 993, SMTP port 587, username = full email.</p>
  </div>

  <div class="bp-panel">
    <div class="bp-panel-title">Aliases &amp; forwards</div>
    <div class="st-row">
      <input class="form-control" id="al-from" placeholder="info@example.com" spellcheck="false" style="max-width:220px">
      <input class="form-control" id="al-to" placeholder="target@example.com (comma for several)" spellcheck="false" style="max-width:280px">
      <button class="btn bp-btn" id="al-add">Add alias</button>
    </div>
    <table class="table bp-table mb-0 mt-2" id="al-table">
      <thead><tr><th>From</th><th>To</th><th class="text-end"></th></tr></thead>
      <tbody></tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
