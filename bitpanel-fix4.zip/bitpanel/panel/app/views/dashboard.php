<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Dashboard</h1>
  <div class="bp-hostline">
    <span id="h-host">—</span> · <span id="h-os">—</span> · up <span id="h-uptime">—</span>
  </div>
</div>

<div id="agent-error" class="alert alert-danger d-none"></div>

<div class="bp-rollup" id="rollup-row"></div>

<div class="bp-grid">
  <div class="bp-card">
    <div class="bp-card-label">CPU <small id="m-cores"></small></div>
    <div class="bp-metric"><span id="m-cpu">—</span><small>%</small></div>
    <div class="bp-bar"><i id="b-cpu"></i></div>
    <div class="bp-sub">load <span id="m-load">—</span></div>
  </div>
  <div class="bp-card">
    <div class="bp-card-label">Memory</div>
    <div class="bp-metric"><span id="m-mem">—</span><small>%</small></div>
    <div class="bp-bar"><i id="b-mem"></i></div>
    <div class="bp-sub" id="m-memtxt">—</div>
  </div>
  <div class="bp-card">
    <div class="bp-card-label">Disk /</div>
    <div class="bp-metric"><span id="m-disk">—</span><small>%</small></div>
    <div class="bp-bar"><i id="b-disk"></i></div>
    <div class="bp-sub" id="m-disktxt">—</div>
  </div>
  <div class="bp-card">
    <div class="bp-card-label">Network</div>
    <div class="bp-net">↓ <span id="m-rx">—</span></div>
    <div class="bp-net">↑ <span id="m-tx">—</span></div>
    <div class="bp-sub">since last poll</div>
  </div>
</div>

<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <span class="bp-panel-title" style="margin:0">History</span>
    <select class="form-select" id="hist-range" style="max-width:130px;margin-left:8px">
      <option value="24h">Last 24h</option>
      <option value="7d">Last 7 days</option>
      <option value="30d">Last 30 days</option>
    </select>
  </div>
  <canvas id="hist-chart" height="80"></canvas>
  <p class="bp-sub mb-0" id="hist-note">Collected every 5 minutes.</p>
</div>

<div class="bp-panel">
  <div class="bp-panel-title">Services</div>
  <table class="table bp-table mb-0" id="svc-table">
    <thead>
      <tr><th>Unit</th><th>State</th><th class="text-end">Actions</th></tr>
    </thead>
    <tbody><tr><td colspan="3" class="text-muted">Loading…</td></tr></tbody>
  </table>
</div>

<div class="bp-panel">
  <div class="bp-panel-title">Mounted disks</div>
  <table class="table bp-table mb-0" id="disk-table">
    <thead><tr><th>Mount</th><th>Used</th><th>Total</th><th style="width:40%"></th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<?php require __DIR__ . '/_bottom.php'; ?>
