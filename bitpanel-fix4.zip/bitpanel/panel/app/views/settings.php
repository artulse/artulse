<?php /** @var ?string $msg @var ?string $err */ require __DIR__ . '/_top.php'; ?>

<div class="bp-head"><h1>Settings</h1></div>

<div class="bp-panel" style="max-width:480px">
  <div class="bp-panel-title">Change password</div>
  <?php if (!empty($msg)): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
  <?php if (!empty($err)): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
  <form method="post" action="/settings" class="p-1">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <label class="form-label">Current password</label>
    <input class="form-control mb-3" type="password" name="current" required>
    <label class="form-label">New password (min 10 chars)</label>
    <input class="form-control mb-4" type="password" name="new" minlength="10" required>
    <button class="btn bp-btn" type="submit">Update password</button>
  </form>
</div>

<div class="bp-panel" style="max-width:480px">
  <div class="bp-panel-title">Two-factor authentication</div>
  <div id="tf-error" class="alert alert-danger py-2 d-none"></div>
  <div id="tf-ok" class="alert alert-success py-2 d-none"></div>

  <div id="tf-on" class="d-none">
    <p class="bp-sub">2FA is <strong>on</strong>. A code from your authenticator app is required at every login.</p>
    <label class="form-label">Enter a current code to disable</label>
    <div class="d-flex gap-2" style="max-width:280px">
      <input class="form-control bp-otp" id="tf-off-code" inputmode="numeric" maxlength="6" placeholder="000000">
      <button class="bp-act" id="tf-disable">Disable</button>
    </div>
  </div>

  <div id="tf-off">
    <p class="bp-sub">Protect the panel with a time-based one-time code (Google Authenticator, Authy, 1Password, …).</p>
    <button class="btn bp-btn" id="tf-start">Enable 2FA</button>
  </div>

  <div id="tf-enroll" class="d-none">
    <p class="bp-sub mb-2">1. Scan this with your authenticator app:</p>
    <div id="tf-qr" class="tf-qr"></div>
    <p class="bp-sub mb-1">Or enter this secret manually:</p>
    <code id="tf-secret" class="tf-secret"></code>
    <p class="bp-sub mt-3 mb-1">2. Enter the 6-digit code it shows:</p>
    <div class="d-flex gap-2" style="max-width:280px">
      <input class="form-control bp-otp" id="tf-verify-code" inputmode="numeric" maxlength="6" placeholder="000000">
      <button class="btn bp-btn" id="tf-confirm">Confirm</button>
    </div>
  </div>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
