<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>WP Toolkit</h1>
  <div class="bp-hostline">auto-detected WordPress installs</div>
</div>

<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none" style="white-space:pre-wrap"></div>

<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <span class="bp-panel-title" style="margin:0">Sites</span>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="wpt-refresh">Refresh</button>
  </div>
  <table class="table bp-table mb-0 mt-2" id="wpt-table">
    <thead><tr><th>Site</th><th>Version</th><th>Updates</th><th class="text-end">Actions</th></tr></thead>
    <tbody><tr><td colspan="4" class="text-muted">Scanning sites for wp-config.php…</td></tr></tbody>
  </table>
  <p class="bp-sub mt-2 mb-0">Detects any site whose document root has a <code>wp-config.php</code> — including WordPress installed outside the App Store.</p>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
