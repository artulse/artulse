<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>App Daemons</h1><div class="bp-hostline">run apps as auto-restarting services</div></div>
<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>
<div class="bp-panel">
  <div class="bp-panel-title">New daemon</div>
  <div class="st-form">
    <div class="st-row"><label>Name</label><input class="form-control" id="dm-name" placeholder="my-node-app" spellcheck="false" style="max-width:240px"></div>
    <div class="st-row"><label>Command</label><input class="form-control" id="dm-cmd" placeholder="node server.js  (or: gunicorn app:app)" spellcheck="false" style="font-family:var(--bp-mono)"></div>
    <div class="st-row"><label>Directory</label><input class="form-control" id="dm-dir" placeholder="/var/www/app" spellcheck="false" style="font-family:var(--bp-mono)"></div>
    <div class="st-row"><label>Run as</label><input class="form-control" id="dm-user" value="www-data" spellcheck="false" style="max-width:200px"></div>
    <div class="st-row"><label></label><label class="bp-sub"><input type="checkbox" id="dm-auto" checked> start on boot</label></div>
    <div class="st-row"><label></label><button class="btn bp-btn" id="dm-create">Create &amp; start</button></div>
  </div>
</div>
<div class="bp-panel">
  <div class="bp-panel-title">Daemons</div>
  <table class="table bp-table mb-0" id="dm-table">
    <thead><tr><th>Name</th><th>Command</th><th>State</th><th class="text-end">Actions</th></tr></thead>
    <tbody><tr><td colspan="4" class="text-muted">Loading…</td></tr></tbody>
  </table>
</div>
<div id="dm-logwrap" class="bp-panel d-none">
  <div class="st-row" style="margin-bottom:0"><span class="bp-panel-title" style="margin:0">Logs — <span id="dm-logname" class="bp-unit"></span></span><span class="fm-spacer"></span><button class="bp-act" id="dm-logclose">Close</button></div>
  <pre class="log-view" id="dm-logtext"></pre>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
