<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Files</h1>
  <div class="bp-hostline" id="fm-count"></div>
</div>

<div id="fm-error" class="alert alert-danger d-none"></div>

<div class="bp-panel">
  <div class="fm-bar">
    <button class="bp-act" id="fm-up" title="Parent directory">↑ Up</button>
    <input class="form-control fm-path" id="fm-path" value="/" spellcheck="false">
    <button class="bp-act" id="fm-go">Go</button>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="fm-newfile">+ File</button>
    <button class="bp-act" id="fm-newdir">+ Folder</button>
    <button class="bp-act" id="fm-upload">Upload</button>
    <button class="bp-act" id="fm-refresh">Refresh</button>
    <input type="file" id="fm-file-input" multiple hidden>
  </div>
  <div id="fm-progress" class="fm-progress d-none">
    <div class="bp-bar"><i id="fm-progress-bar"></i></div>
    <div class="bp-sub" id="fm-progress-text"></div>
  </div>
  <div class="fm-scroll">
    <table class="table bp-table mb-0" id="fm-table">
      <thead>
        <tr>
          <th>Name</th><th>Size</th><th>Perms</th><th>Owner</th><th>Modified</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody><tr><td colspan="6" class="text-muted">Loading…</td></tr></tbody>
    </table>
  </div>
</div>

<!-- editor overlay -->
<div id="fm-editor" class="fm-editor d-none">
  <div class="fm-editor-box">
    <div class="fm-editor-head">
      <span class="bp-unit" id="fm-editor-path"></span>
      <span class="fm-spacer"></span>
      <span class="bp-sub" id="fm-editor-note">Ctrl+S to save</span>
      <button class="bp-act" id="fm-editor-save">Save</button>
      <button class="bp-act" id="fm-editor-close">Close</button>
    </div>
    <textarea id="fm-editor-text" spellcheck="false"></textarea>
  </div>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
