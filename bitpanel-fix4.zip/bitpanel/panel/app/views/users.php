<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>Users &amp; API</h1><div class="bp-hostline">panel accounts and programmatic tokens</div></div>
<div id="bp-error" class="alert alert-danger d-none"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>
<div class="bp-panel">
  <div class="bp-panel-title">Add panel user</div>
  <div class="st-row">
    <input class="form-control" id="us-name" placeholder="username" spellcheck="false" style="max-width:200px">
    <input class="form-control" id="us-pass" type="text" placeholder="password (min 10)" spellcheck="false" style="max-width:220px">
    <select class="form-select" id="us-role" style="max-width:150px"><option value="viewer">viewer</option><option value="admin">admin</option></select>
    <button class="btn bp-btn" id="us-create">Add user</button>
  </div>
  <p class="bp-sub mt-2 mb-0">Viewers can see everything but cannot make changes. Admins have full control.</p>
</div>
<div class="bp-panel">
  <div class="bp-panel-title">Panel users</div>
  <table class="table bp-table mb-0" id="us-table">
    <thead><tr><th>Username</th><th>Role</th><th>2FA</th><th class="text-end">Actions</th></tr></thead>
    <tbody></tbody>
  </table>
</div>
<div class="bp-panel">
  <div class="bp-panel-title">API tokens</div>
  <div class="st-row">
    <input class="form-control" id="tk-label" placeholder="token label (e.g. deploy-ci)" spellcheck="false" style="max-width:280px">
    <button class="btn bp-btn" id="tk-create">Create token</button>
  </div>
  <div id="tk-new" class="alert alert-success d-none mt-2" style="word-break:break-all"></div>
  <table class="table bp-table mb-0 mt-2" id="tk-table">
    <thead><tr><th>Label</th><th>Created</th><th>Last used</th><th class="text-end">Actions</th></tr></thead>
    <tbody></tbody>
  </table>
  <p class="bp-sub mt-2 mb-0">Use a token with <code>Authorization: Bearer &lt;token&gt;</code> against any <code>/api/…</code> endpoint. Tokens have admin rights.</p>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
