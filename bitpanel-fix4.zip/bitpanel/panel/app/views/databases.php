<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Databases</h1>
  <div class="bp-hostline" id="db-engine"></div>
</div>

<div id="db-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="db-ok" class="alert alert-success d-none"></div>
<div id="db-none" class="bp-panel d-none">
  <div class="bp-panel-title">No database server</div>
  <p class="bp-sub mb-0">Install MySQL or MariaDB from the component installer, then reload this page.</p>
</div>

<div id="db-wrap" class="d-none">
  <div class="bp-panel">
    <div class="bp-panel-title">Create database</div>
    <div class="st-row">
      <label>Name</label>
      <input class="form-control" id="db-name" placeholder="app_production" spellcheck="false" style="max-width:280px">
      <select class="form-select" id="db-charset" style="max-width:160px">
        <option value="utf8mb4">utf8mb4</option>
        <option value="utf8">utf8</option>
        <option value="latin1">latin1</option>
      </select>
      <button class="btn bp-btn" id="db-create">Create</button>
    </div>
  </div>

  <div class="bp-panel">
    <div class="bp-panel-title">Databases</div>
    <table class="table bp-table mb-0" id="db-table">
      <thead><tr><th>Name</th><th>Tables</th><th>Size</th><th class="text-end">Actions</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>

  <div class="bp-panel">
    <div class="bp-panel-title">Create user</div>
    <div class="st-form">
      <div class="st-row">
        <label>Username</label>
        <input class="form-control" id="du-user" placeholder="app_user" spellcheck="false">
      </div>
      <div class="st-row">
        <label>Password</label>
        <input class="form-control" id="du-pass" type="text" placeholder="strong password" spellcheck="false">
      </div>
      <div class="st-row">
        <label>Host</label>
        <select class="form-select" id="du-host">
          <option value="localhost">localhost (local only)</option>
          <option value="%">% (any host)</option>
        </select>
      </div>
      <div class="st-row">
        <label>Grant on</label>
        <select class="form-select" id="du-db"><option value="">— no grant —</option></select>
      </div>
      <div class="st-row">
        <label></label>
        <button class="btn bp-btn" id="du-create">Create user</button>
      </div>
    </div>
  </div>

  <div class="bp-panel">
    <div class="bp-panel-title">Users</div>
    <table class="table bp-table mb-0" id="du-table">
      <thead><tr><th>User</th><th>Host</th><th>Databases</th><th class="text-end">Actions</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>

  <div class="bp-panel">
    <div class="st-row" style="margin-bottom:0">
      <span class="bp-panel-title" style="margin:0">SQL console</span>
      <select class="form-select" id="q-db" style="max-width:220px;margin-left:8px"></select>
      <span class="fm-spacer"></span>
      <button class="bp-act" id="q-tables">List tables</button>
    </div>
    <table class="table bp-table mb-0 mt-2 d-none" id="q-tabletable">
      <thead><tr><th>Table</th><th>Rows</th><th>Size</th><th class="text-end"></th></tr></thead>
      <tbody></tbody>
    </table>
    <textarea id="q-sql" class="q-sql mt-2" spellcheck="false" placeholder="SELECT * FROM users LIMIT 20;"></textarea>
    <div class="st-row" style="margin:8px 0 0"><button class="btn bp-btn" id="q-run">Run query</button><span class="bp-sub" style="margin-left:10px">Ctrl+Enter to run · runs with full admin rights</span></div>
    <pre class="log-view mt-2 d-none" id="q-out"></pre>
  </div>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
