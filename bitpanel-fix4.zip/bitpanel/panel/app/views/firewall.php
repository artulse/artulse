<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Firewall</h1>
  <div class="bp-hostline" id="fw-summary"></div>
</div>

<div id="fw-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="fw-ok" class="alert alert-success d-none"></div>

<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <div>
      <span class="bp-panel-title" style="margin:0">UFW</span>
      <span id="fw-state" class="bp-state mid" style="margin-left:8px">…</span>
      <span class="bp-sub" id="fw-default"></span>
    </div>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="fw-toggle">…</button>
  </div>
  <p class="bp-sub mt-2 mb-0" id="fw-guard-note">Enabling the firewall automatically keeps your SSH port and this panel's port open, so you won't be locked out.</p>
</div>

<div id="fw-body" class="d-none">
  <div class="bp-panel">
    <div class="bp-panel-title">Add rule</div>
    <div class="st-row">
      <select class="form-select" id="fw-action" style="max-width:130px">
        <option value="allow">allow</option>
        <option value="deny">deny</option>
        <option value="reject">reject</option>
        <option value="limit">limit</option>
      </select>
      <input class="form-control" id="fw-port" placeholder="port (e.g. 443)" inputmode="numeric" style="max-width:150px">
      <select class="form-select" id="fw-proto" style="max-width:110px">
        <option value="tcp">tcp</option>
        <option value="udp">udp</option>
        <option value="any">any</option>
      </select>
      <input class="form-control" id="fw-source" placeholder="from IP/CIDR (optional)" spellcheck="false" style="max-width:200px">
      <button class="btn bp-btn" id="fw-add">Add</button>
    </div>
  </div>

  <div class="bp-panel">
    <div class="bp-panel-title">Rules</div>
    <table class="table bp-table mb-0" id="fw-table">
      <thead><tr><th style="width:60px">#</th><th>To</th><th>Action</th><th>From</th><th class="text-end"></th></tr></thead>
      <tbody><tr><td colspan="5" class="text-muted">Loading…</td></tr></tbody>
    </table>
  </div>
</div>

<div class="bp-panel">
  <div class="bp-panel-title">Fail2ban</div>
  <div id="f2b-summary" class="bp-sub">Loading…</div>
  <div id="f2b-jails" class="mt-2"></div>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
