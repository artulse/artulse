<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Terminal</h1>
  <div class="bp-hostline">tty via ttyd · sign in with system credentials</div>
</div>

<div id="term-error" class="alert alert-danger d-none"></div>

<div class="bp-panel d-none" id="term-setup">
  <div class="bp-panel-title">Terminal not enabled yet</div>
  <p class="bp-sub">
    This installs ttyd, binds it to 127.0.0.1 only, and proxies it through the panel
    behind your session. The shell starts with a standard <code>login</code> prompt —
    enter a system user (e.g. <code>ubuntu</code>) and its password, exactly like the console.
  </p>
  <button class="btn bp-btn" id="term-enable">Enable terminal</button>
  <span class="bp-sub d-none" id="term-busy">Installing… this can take a minute.</span>
</div>

<div class="bp-panel fm-termwrap d-none" id="term-wrap">
  <iframe id="term-frame" class="fm-term" src="about:blank"></iframe>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
