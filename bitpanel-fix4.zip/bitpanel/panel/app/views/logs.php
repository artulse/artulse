<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>Logs</h1><div class="bp-hostline">read-only tail of server logs</div></div>
<div id="bp-error" class="alert alert-danger d-none"></div>
<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <select class="form-select" id="lg-file" style="max-width:320px"><option>loading…</option></select>
    <select class="form-select" id="lg-lines" style="max-width:130px">
      <option value="100">100 lines</option><option value="200" selected>200 lines</option>
      <option value="500">500 lines</option><option value="1000">1000 lines</option>
    </select>
    <button class="bp-act" id="lg-refresh">Refresh</button>
  </div>
</div>
<div class="bp-panel"><pre class="log-view" id="lg-text">Select a log…</pre></div>
<?php require __DIR__ . '/_bottom.php'; ?>
