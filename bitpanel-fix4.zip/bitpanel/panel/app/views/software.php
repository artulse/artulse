<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>Software</h1><div class="bp-hostline">install and manage server components</div></div>
<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>
<div id="sw-groups"></div>
<?php require __DIR__ . '/_bottom.php'; ?>
