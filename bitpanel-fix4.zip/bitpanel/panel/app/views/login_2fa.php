<?php /** @var ?string $error */ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BitPanel · Verification</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/app.css">
</head>
<body class="bp-login-body">
<div class="bp-login-card">
  <div class="bp-brand mb-4">Bit<span>Panel</span></div>
  <p class="bp-sub mb-3">Enter the 6-digit code from your authenticator app.</p>
  <?php if ($error): ?>
    <div class="alert alert-danger py-2"><?= e($error) ?></div>
  <?php endif; ?>
  <form method="post" action="/login/2fa" autocomplete="off">
    <input class="form-control mb-4 bp-otp" name="code" inputmode="numeric" pattern="[0-9]*"
           maxlength="6" placeholder="000000" required autofocus>
    <button class="btn bp-btn w-100" type="submit">Verify</button>
  </form>
  <form method="post" action="/logout" class="mt-3 text-center">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <button type="submit" class="btn btn-link bp-sub p-0">Cancel</button>
  </form>
</div>
</body>
</html>
