<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Security</h1>
  <div class="bp-hostline">SSH, root login, ping, panel access</div>
</div>

<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none" style="white-space:pre-wrap"></div>

<div class="bp-panel" style="max-width:560px">
  <div class="bp-panel-title">SSH port</div>
  <p class="bp-sub">Current port: <span id="sc-port" class="bp-unit">…</span></p>
  <div class="st-row">
    <input class="form-control" id="sc-port-input" placeholder="e.g. 2222" inputmode="numeric" style="max-width:140px">
    <button class="btn bp-btn" id="sc-port-save">Change port</button>
  </div>
  <p class="bp-sub mt-2 mb-0">The new port is opened in UFW automatically before SSH restarts, so you won't be locked out — but always test a <strong>new</strong> connection on the new port before closing your current session.</p>
</div>

<div class="bp-panel" style="max-width:560px">
  <div class="bp-panel-title">Root SSH login</div>
  <div class="st-row" style="margin-bottom:0">
    <span id="sc-root-state" class="bp-state mid">…</span>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="sc-root-toggle">Toggle</button>
  </div>
  <p class="bp-sub mt-2 mb-0">Disabling this means root can no longer SSH in at all — make sure you (or another user) can sudo before turning it off.</p>
</div>

<div class="bp-panel" style="max-width:560px">
  <div class="bp-panel-title">Ping (ICMP echo)</div>
  <div class="st-row" style="margin-bottom:0">
    <span id="sc-ping-state" class="bp-state mid">…</span>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="sc-ping-toggle">Toggle</button>
  </div>
</div>

<div class="bp-panel" style="max-width:560px">
  <div class="bp-panel-title">Panel IP allowlist</div>
  <p class="bp-sub">Restrict who can even reach the panel's login page, at the Nginx level (in addition to your AWS Security Group).</p>
  <table class="table bp-table mb-0" id="sc-allow-table">
    <thead><tr><th>IP / CIDR</th><th class="text-end"></th></tr></thead>
    <tbody></tbody>
  </table>
  <div class="st-row">
    <input class="form-control" id="sc-allow-input" placeholder="e.g. 203.0.113.10 or 203.0.113.0/24" spellcheck="false">
    <button class="bp-act" id="sc-allow-add">Add</button>
  </div>
  <p class="bp-sub mt-2 mb-0">The list can never be saved without your own current IP in it — that guard prevents locking yourself out. Clear the list entirely to remove the restriction.</p>
  <button class="btn bp-btn mt-2" id="sc-allow-save">Save allowlist</button>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
