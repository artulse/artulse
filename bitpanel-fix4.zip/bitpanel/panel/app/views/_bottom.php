  </main>
</div>
<script>window.BP_CSRF = <?= json_encode(csrf_token()) ?>;</script>
<script src="/assets/bp.js"></script>
<script src="/assets/app.js"></script>
<?php foreach (($scripts ?? []) as $s): ?>
<script src="<?= e($s) ?>"></script>
<?php endforeach; ?>
</body>
</html>
