<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Sites &amp; SSL</h1>
  <div class="bp-hostline" id="st-count"></div>
</div>

<div id="st-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="st-ok" class="alert alert-success d-none"></div>

<div class="bp-panel">
  <div class="bp-panel-title">Add site</div>
  <div class="st-form">
    <div class="st-row">
      <label>Domains</label>
      <input class="form-control" id="st-domains" placeholder="example.com, www.example.com" spellcheck="false">
    </div>
    <div class="st-row">
      <label>Type</label>
      <select class="form-select" id="st-type">
        <option value="php">PHP site</option>
        <option value="static">Static site</option>
        <option value="proxy">Reverse proxy</option>
      </select>
    </div>
    <div class="st-row" id="st-php-row">
      <label>PHP</label>
      <select class="form-select" id="st-php"><option>loading…</option></select>
    </div>
    <div class="st-row" id="st-root-row">
      <label>Document root</label>
      <input class="form-control" id="st-root" placeholder="/var/www/example.com (blank = auto)" spellcheck="false">
    </div>
    <div class="st-row d-none" id="st-up-row">
      <label>Upstream</label>
      <input class="form-control" id="st-upstream" placeholder="http://127.0.0.1:3000" spellcheck="false">
    </div>
    <div class="st-row">
      <label></label>
      <button class="btn bp-btn" id="st-create">Create site</button>
    </div>
  </div>
  <p class="bp-sub mb-0">SSL needs the domain's DNS pointed at this server and ports 80/443 open in the AWS Security Group.</p>
</div>

<div class="bp-panel">
  <div class="bp-panel-title">Sites</div>
  <table class="table bp-table mb-0" id="st-table">
    <thead>
      <tr><th>Site</th><th>Type</th><th>Target</th><th>SSL</th><th>WAF</th><th class="text-end">Actions</th></tr>
    </thead>
    <tbody><tr><td colspan="5" class="text-muted">Loading…</td></tr></tbody>
  </table>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
