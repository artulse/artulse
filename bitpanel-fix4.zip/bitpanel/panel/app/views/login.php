<?php /** @var ?string $error */ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BitPanel · Sign in</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/app.css">
</head>
<body class="bp-login-body">
<div class="bp-login-card">
  <div class="bp-brand mb-4">Bit<span>Panel</span></div>
  <?php if ($error): ?>
    <div class="alert alert-danger py-2"><?= e($error) ?></div>
  <?php endif; ?>
  <form method="post" action="/login" autocomplete="off">
    <label class="form-label">Username</label>
    <input class="form-control mb-3" name="username" required autofocus>
    <label class="form-label">Password</label>
    <input class="form-control mb-4" type="password" name="password" required>
    <button class="btn bp-btn w-100" type="submit">Sign in</button>
  </form>
  <p class="bp-login-note">Root server console · <?= e((string)gethostname()) ?></p>
</div>
</body>
</html>
