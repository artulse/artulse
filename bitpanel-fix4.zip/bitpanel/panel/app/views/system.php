<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>System</h1><div class="bp-hostline">updates, processes, listening ports</div></div>
<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>
<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <span class="bp-panel-title" style="margin:0">Package updates</span>
    <span class="bp-sub" id="sy-upcount" style="margin-left:8px"></span>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="sy-refresh">Check</button>
    <button class="btn bp-btn" id="sy-upgrade" style="margin-left:6px">Upgrade all</button>
  </div>
  <div class="fm-scroll mt-2"><table class="table bp-table mb-0" id="sy-uptable">
    <thead><tr><th>Package</th><th>Installed</th><th>Available</th></tr></thead><tbody><tr><td colspan="3" class="text-muted">Click Check…</td></tr></tbody>
  </table></div>
</div>
<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <span class="bp-panel-title" style="margin:0">Top processes</span>
    <select class="form-select" id="sy-sort" style="max-width:150px;margin-left:8px"><option value="cpu">by CPU</option><option value="mem">by memory</option></select>
    <span class="fm-spacer"></span><button class="bp-act" id="sy-procrefresh">Refresh</button>
  </div>
  <table class="table bp-table mb-0 mt-2" id="sy-proc">
    <thead><tr><th>PID</th><th>User</th><th>CPU%</th><th>Mem%</th><th>RSS</th><th>Command</th><th class="text-end"></th></tr></thead>
    <tbody></tbody>
  </table>
</div>
<div class="bp-panel">
  <div class="bp-panel-title">Listening ports</div>
  <table class="table bp-table mb-0" id="sy-ports">
    <thead><tr><th>Proto</th><th>Local address</th><th>Process</th></tr></thead>
    <tbody></tbody>
  </table>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
