<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Cleanup</h1>
  <div class="bp-hostline">reclaim disk space</div>
</div>

<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>

<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <span class="bp-panel-title" style="margin:0">Disk usage breakdown</span>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="cu-refresh">Refresh</button>
  </div>
  <table class="table bp-table mb-0 mt-2" id="cu-breakdown">
    <thead><tr><th>Area</th><th>Size</th><th style="width:40%"></th></tr></thead>
    <tbody><tr><td colspan="3" class="text-muted">Loading…</td></tr></tbody>
  </table>
</div>

<div class="bp-panel">
  <div class="bp-panel-title">Suggested cleanup</div>
  <div id="cu-suggest"><p class="bp-sub">Scanning…</p></div>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
