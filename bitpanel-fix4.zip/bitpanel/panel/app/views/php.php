<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>PHP Manager</h1><div class="bp-hostline">per-version settings and extensions</div></div>
<div id="bp-error" class="alert alert-danger d-none"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>
<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <label style="width:90px;flex:0 0 90px">Version</label>
    <select class="form-select" id="ph-ver" style="max-width:200px"><option>loading…</option></select>
  </div>
</div>
<div id="ph-wrap" class="d-none">
  <div class="bp-panel" style="max-width:520px">
    <div class="bp-panel-title">php.ini settings</div>
    <div class="st-form" id="ph-settings"></div>
    <button class="btn bp-btn" id="ph-save">Save &amp; restart FPM</button>
  </div>
  <div class="bp-panel">
    <div class="bp-panel-title">Extensions</div>
    <div id="ph-ext" class="ph-ext"></div>
  </div>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
