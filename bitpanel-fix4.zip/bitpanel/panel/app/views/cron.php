<?php require __DIR__ . '/_top.php'; ?>

<div class="bp-head">
  <h1>Cron</h1>
  <div class="bp-hostline">scheduled tasks per system user</div>
</div>

<div id="cr-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="cr-ok" class="alert alert-success d-none"></div>

<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <label style="width:60px;flex:0 0 60px">User</label>
    <select class="form-select" id="cr-user" style="max-width:220px"><option>loading…</option></select>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="cr-refresh">Refresh</button>
  </div>
</div>

<div class="bp-panel">
  <div class="bp-panel-title">Add task</div>
  <div class="st-form">
    <div class="st-row">
      <label>Schedule</label>
      <input class="form-control" id="cr-sched" placeholder="0 3 * * *   (or @daily)" spellcheck="false" style="font-family:var(--bp-mono)">
    </div>
    <div class="st-row">
      <label>Command</label>
      <input class="form-control" id="cr-cmd" placeholder="/usr/bin/php /var/www/app/cron.php" spellcheck="false" style="font-family:var(--bp-mono)">
    </div>
    <div class="st-row"><label></label><button class="btn bp-btn" id="cr-add">Add task</button></div>
  </div>
  <p class="bp-sub mb-0">Fields: minute hour day-of-month month day-of-week. Shortcuts: @reboot @hourly @daily @weekly @monthly.</p>
</div>

<div class="bp-panel">
  <div class="bp-panel-title">Tasks for <span id="cr-who" class="bp-unit">root</span></div>
  <table class="table bp-table mb-0" id="cr-table">
    <thead><tr><th style="width:180px">Schedule</th><th>Command</th><th class="text-end">Actions</th></tr></thead>
    <tbody><tr><td colspan="3" class="text-muted">Loading…</td></tr></tbody>
  </table>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
