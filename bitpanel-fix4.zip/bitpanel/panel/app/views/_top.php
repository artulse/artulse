<?php /** @var string $page */ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BitPanel · <?= e(ucfirst($page)) ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/app.css">
</head>
<body>
<div class="bp-shell">
  <aside class="bp-side">
    <div class="bp-brand">Bit<span>Panel</span></div>
    <nav class="bp-nav">
      <a href="/" class="<?= $page === 'dashboard' ? 'on' : '' ?>">Dashboard</a>
      <a href="/files" class="<?= $page === 'files' ? 'on' : '' ?>">Files</a>
      <a href="/terminal" class="<?= $page === 'terminal' ? 'on' : '' ?>">Terminal</a>
      <a href="/sites" class="<?= $page === 'sites' ? 'on' : '' ?>">Sites</a>
      <a href="/sites" class="<?= $page === 'sites' ? 'on' : '' ?>">SSL</a>
      <a href="/mail" class="<?= $page === 'mail' ? 'on' : '' ?>">Mail</a>
      <a href="/apps" class="<?= $page === 'apps' ? 'on' : '' ?>">App Store</a>
      <a href="/wptoolkit" class="<?= $page === 'wptoolkit' ? 'on' : '' ?>">WP Toolkit</a>
      <a href="/databases" class="<?= $page === 'databases' ? 'on' : '' ?>">Databases</a>
      <a href="/php" class="<?= $page === 'php' ? 'on' : '' ?>">PHP</a>
      <a href="/cron" class="<?= $page === 'cron' ? 'on' : '' ?>">Cron</a>
      <a href="/daemons" class="<?= $page === 'daemons' ? 'on' : '' ?>">App Daemons</a>
      <a href="/firewall" class="<?= $page === 'firewall' ? 'on' : '' ?>">Firewall</a>
      <a href="/security" class="<?= $page === 'security' ? 'on' : '' ?>">Security</a>
      <a href="/software" class="<?= $page === 'software' ? 'on' : '' ?>">Software</a>
      <a href="/system" class="<?= $page === 'system' ? 'on' : '' ?>">System</a>
      <a href="/cleanup" class="<?= $page === 'cleanup' ? 'on' : '' ?>">Cleanup</a>
      <a href="/backups" class="<?= $page === 'backups' ? 'on' : '' ?>">Backups</a>
      <a href="/docker" class="<?= $page === 'docker' ? 'on' : '' ?>">Docker</a>
      <a href="/ftp" class="<?= $page === 'ftp' ? 'on' : '' ?>">FTP</a>
      <a href="/logs" class="<?= $page === 'logs' ? 'on' : '' ?>">Logs</a>
      <?php if (is_admin()): ?><a href="/users" class="<?= $page === 'users' ? 'on' : '' ?>">Users &amp; API</a><?php endif; ?>
      <a href="/settings" class="<?= $page === 'settings' ? 'on' : '' ?>">Settings</a>
    </nav>
    <form method="post" action="/logout" class="bp-logout">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <button type="submit">Sign out · <?= e((string)($_SESSION['uname'] ?? '')) ?></button>
    </form>
  </aside>
  <main class="bp-main">
