<?php require __DIR__ . '/_top.php'; ?>
<div class="bp-head"><h1>FTP</h1><div class="bp-hostline" id="ftp-summary"></div></div>
<div id="bp-error" class="alert alert-danger d-none" style="white-space:pre-wrap"></div>
<div id="bp-ok" class="alert alert-success d-none"></div>
<div class="bp-panel">
  <div class="st-row" style="margin-bottom:0">
    <span class="bp-panel-title" style="margin:0">vsftpd</span>
    <span id="ftp-state" class="bp-state mid" style="margin-left:8px">…</span>
    <span class="fm-spacer"></span>
    <button class="bp-act" id="ftp-setup">Set up / repair</button>
  </div>
  <p class="bp-sub mt-2 mb-0">Accounts are chrooted system users. Passive ports 40000–40100 must be open in UFW and the AWS Security Group.</p>
</div>
<div id="ftp-wrap" class="d-none">
  <div class="bp-panel">
    <div class="bp-panel-title">Add FTP account</div>
    <div class="st-form">
      <div class="st-row"><label>Username</label><input class="form-control" id="ftp-user" spellcheck="false"></div>
      <div class="st-row"><label>Password</label><input class="form-control" id="ftp-pass" type="text" spellcheck="false"></div>
      <div class="st-row"><label>Home dir</label><input class="form-control" id="ftp-dir" placeholder="/var/www/username (blank = auto)" spellcheck="false" style="font-family:var(--bp-mono)"></div>
      <div class="st-row"><label></label><button class="btn bp-btn" id="ftp-add">Create account</button></div>
    </div>
  </div>
  <div class="bp-panel">
    <div class="bp-panel-title">Accounts</div>
    <table class="table bp-table mb-0" id="ftp-table">
      <thead><tr><th>User</th><th>Home</th><th class="text-end">Actions</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
