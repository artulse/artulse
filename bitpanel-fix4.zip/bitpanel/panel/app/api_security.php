<?php
declare(strict_types=1);

/** /api/security/* — included by public/index.php. */

function se_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$seRoute = substr($path, strlen('/api/'));

switch ($seRoute . ':' . $method) {

    case 'security/get:GET':
        json_out(AgentClient::call('sec.get'));

    case 'security/ssh-port:POST':
        csrf_check();
        $b = se_body();
        $port = (int)($b['port'] ?? 0);
        $res = AgentClient::call('sec.ssh_port_set', ['port' => $port], 40);
        audit('sec.ssh_port', (string)$port . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'security/root-login:POST':
        csrf_check();
        $b = se_body();
        $res = AgentClient::call('sec.root_login_set', ['enabled' => !empty($b['enabled'])], 30);
        audit('sec.root_login', !empty($b['enabled']) ? 'enabled' : 'disabled');
        json_out($res);

    case 'security/ping:POST':
        csrf_check();
        $b = se_body();
        $res = AgentClient::call('sec.ping_set', ['disabled' => !empty($b['disabled'])], 15);
        audit('sec.ping', !empty($b['disabled']) ? 'disabled' : 'enabled');
        json_out($res);

    case 'security/allowlist:POST':
        csrf_check();
        $b = se_body();
        $ips = array_values(array_filter(array_map('trim', (array)($b['ips'] ?? []))));
        // Lockout guard: the submitting browser's own IP must be able to reach the panel afterward.
        $me = client_ip();
        if ($ips && !in_array($me, $ips, true)) {
            json_out(['ok' => false, 'error' => "refusing: your current IP ({$me}) is not in the list — you would be locked out. Add it first."]);
        }
        $res = AgentClient::call('sec.allowlist_set', ['ips' => $ips], 30);
        audit('sec.allowlist', implode(',', $ips) ?: '(cleared)');
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
