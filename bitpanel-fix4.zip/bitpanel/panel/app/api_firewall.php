<?php
declare(strict_types=1);

/** /api/fw/* and /api/f2b/* — included by public/index.php. */

function fw_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$fwRoute = substr($path, strlen('/api/'));

switch ($fwRoute . ':' . $method) {

    /* ---- ufw ---- */
    case 'fw/status:GET':
        json_out(AgentClient::call('fw.status'));

    case 'fw/rules:GET':
        json_out(AgentClient::call('fw.rules'));

    case 'fw/add:POST':
        csrf_check();
        $b = fw_body();
        $res = AgentClient::call('fw.add', [
            'action' => (string)($b['action'] ?? 'allow'),
            'port'   => (string)($b['port'] ?? ''),
            'proto'  => (string)($b['proto'] ?? 'tcp'),
            'source' => (string)($b['source'] ?? ''),
        ], 30);
        audit('fw.add', (string)($b['action'] ?? '') . ' ' . (string)($b['port'] ?? '') . '/' . (string)($b['proto'] ?? ''));
        json_out($res);

    case 'fw/delete:POST':
        csrf_check();
        $b = fw_body();
        $res = AgentClient::call('fw.delete', ['num' => (int)($b['num'] ?? -1)], 30);
        audit('fw.delete', '#' . (string)($b['num'] ?? ''));
        json_out($res);

    case 'fw/toggle:POST':
        csrf_check();
        $b = fw_body();
        $res = AgentClient::call('fw.toggle', ['enable' => !empty($b['enable'])], 200);
        audit('fw.toggle', 'enable=' . (!empty($b['enable']) ? '1' : '0')
            . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    /* ---- fail2ban ---- */
    case 'f2b/status:GET':
        json_out(AgentClient::call('f2b.status'));

    case 'f2b/jail:GET':
        json_out(AgentClient::call('f2b.jail', ['jail' => (string)($_GET['jail'] ?? '')]));

    case 'f2b/unban:POST':
        csrf_check();
        $b = fw_body();
        $res = AgentClient::call('f2b.unban', [
            'jail' => (string)($b['jail'] ?? ''), 'ip' => (string)($b['ip'] ?? ''),
        ], 30);
        audit('f2b.unban', (string)($b['jail'] ?? '') . ' ' . (string)($b['ip'] ?? ''));
        json_out($res);

    case 'f2b/ban:POST':
        csrf_check();
        $b = fw_body();
        $res = AgentClient::call('f2b.ban', [
            'jail' => (string)($b['jail'] ?? ''), 'ip' => (string)($b['ip'] ?? ''),
        ], 30);
        audit('f2b.ban', (string)($b['jail'] ?? '') . ' ' . (string)($b['ip'] ?? ''));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
