<?php
declare(strict_types=1);

/** /api/soft/* /api/log/* /api/docker/* — included by public/index.php. */

function sys_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$sysRoute = substr($path, strlen('/api/'));

switch ($sysRoute . ':' . $method) {

    /* ---- software store ---- */
    case 'soft/catalog:GET':
        json_out(AgentClient::call('soft.catalog'));

    case 'soft/install:POST':
        csrf_check();
        $b = sys_body();
        $res = AgentClient::call('soft.install', ['key' => (string)($b['key'] ?? '')], 700);
        audit('soft.install', (string)($b['key'] ?? '') . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'soft/uninstall:POST':
        csrf_check();
        $b = sys_body();
        $res = AgentClient::call('soft.uninstall', ['key' => (string)($b['key'] ?? '')], 340);
        audit('soft.uninstall', (string)($b['key'] ?? ''));
        json_out($res);

    /* ---- logs ---- */
    case 'log/list:GET':
        json_out(AgentClient::call('log.list'));

    case 'log/tail:GET':
        json_out(AgentClient::call('log.tail', [
            'path' => (string)($_GET['path'] ?? ''), 'lines' => (int)($_GET['lines'] ?? 200),
        ], 30));

    /* ---- docker ---- */
    case 'docker/ps:GET':
        json_out(AgentClient::call('docker.ps', ['all' => !empty($_GET['all'])]));

    case 'docker/images:GET':
        json_out(AgentClient::call('docker.images'));

    case 'docker/logs:GET':
        json_out(AgentClient::call('docker.logs', [
            'id' => (string)($_GET['id'] ?? ''), 'lines' => (int)($_GET['lines'] ?? 200),
        ], 30));

    case 'docker/action:POST':
        csrf_check();
        $b = sys_body();
        $res = AgentClient::call('docker.action', [
            'id' => (string)($b['id'] ?? ''), 'action' => (string)($b['action'] ?? ''),
        ], 60);
        audit('docker.' . (string)($b['action'] ?? ''), (string)($b['id'] ?? ''));
        json_out($res);

    /* ---- system: updates / processes / ports ---- */
    case 'sys/updates:GET':
        json_out(AgentClient::call('sys.updates', [], 140));

    case 'sys/upgrade:POST':
        csrf_check();
        $res = AgentClient::call('sys.upgrade', [], 1300);
        audit('sys.upgrade', !empty($res['ok']) ? 'ok' : 'err');
        json_out($res);

    case 'proc/top:GET':
        json_out(AgentClient::call('proc.top', ['sort' => (string)($_GET['sort'] ?? 'cpu')]));

    case 'proc/kill:POST':
        csrf_check();
        $b = sys_body();
        $res = AgentClient::call('proc.kill', [
            'pid' => (int)($b['pid'] ?? -1), 'signal' => (string)($b['signal'] ?? 'TERM'),
        ], 15);
        audit('proc.kill', 'pid=' . (string)($b['pid'] ?? '') . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'net/listening:GET':
        json_out(AgentClient::call('net.listening'));

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
