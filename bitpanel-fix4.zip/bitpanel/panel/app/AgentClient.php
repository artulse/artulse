<?php
declare(strict_types=1);

final class AgentClient
{
    private const SOCK    = 'unix:///run/bitpanel/agent.sock';
    private const KEY     = '/opt/bitpanel/data/agent.key';
    private const MAX_RES = 24 * 1024 * 1024;

    public static function call(string $op, array $args = [], int $timeout = 20): array
    {
        $key = trim((string)@file_get_contents(self::KEY));
        if ($key === '') {
            return ['ok' => false, 'error' => 'agent key unreadable'];
        }
        $fp = @stream_socket_client(self::SOCK, $errno, $errstr, 5);
        if ($fp === false) {
            return ['ok' => false, 'error' => "agent unavailable ({$errstr})"];
        }
        stream_set_timeout($fp, $timeout);

        $payload = json_encode(['token' => $key, 'op' => $op, 'args' => $args]) . "\n";
        $len = strlen($payload);
        $off = 0;
        while ($off < $len) {
            $n = @fwrite($fp, substr($payload, $off, 262144));
            if ($n === false || $n === 0) {
                fclose($fp);
                return ['ok' => false, 'error' => 'agent write failed'];
            }
            $off += $n;
        }

        $buf = '';
        while (strlen($buf) < self::MAX_RES) {
            $chunk = fgets($fp, 65536);
            if ($chunk === false) {
                break;
            }
            $buf .= $chunk;
            if (substr($buf, -1) === "\n") {
                break;
            }
        }
        fclose($fp);

        $res = json_decode($buf, true);
        return is_array($res) ? $res : ['ok' => false, 'error' => 'bad agent response'];
    }
}
