<?php
declare(strict_types=1);

/** /api/daemon/* — included by public/index.php. */

function dm_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$dmRoute = substr($path, strlen('/api/'));

switch ($dmRoute . ':' . $method) {

    case 'daemon/list:GET':
        json_out(AgentClient::call('daemon.list'));

    case 'daemon/logs:GET':
        json_out(AgentClient::call('daemon.logs', [
            'name' => (string)($_GET['name'] ?? ''), 'lines' => (int)($_GET['lines'] ?? 200),
        ], 30));

    case 'daemon/create:POST':
        csrf_check();
        $b = dm_body();
        $res = AgentClient::call('daemon.create', [
            'name' => (string)($b['name'] ?? ''), 'command' => (string)($b['command'] ?? ''),
            'dir' => (string)($b['dir'] ?? ''), 'user' => (string)($b['user'] ?? 'www-data'),
            'autostart' => !empty($b['autostart']),
        ], 40);
        audit('daemon.create', (string)($b['name'] ?? ''));
        json_out($res);

    case 'daemon/action:POST':
        csrf_check();
        $b = dm_body();
        $res = AgentClient::call('daemon.action', [
            'name' => (string)($b['name'] ?? ''), 'action' => (string)($b['action'] ?? ''),
        ], 40);
        audit('daemon.' . (string)($b['action'] ?? ''), (string)($b['name'] ?? ''));
        json_out($res);

    case 'daemon/delete:POST':
        csrf_check();
        $b = dm_body();
        $res = AgentClient::call('daemon.delete', ['name' => (string)($b['name'] ?? '')], 40);
        audit('daemon.delete', (string)($b['name'] ?? ''));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
