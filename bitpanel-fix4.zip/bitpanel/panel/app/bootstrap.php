<?php
declare(strict_types=1);

const BP_DATA = '/opt/bitpanel/data';

require __DIR__ . '/AgentClient.php';
require __DIR__ . '/Totp.php';

session_name('BITPANELSESS');
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => true,
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('sqlite:' . BP_DATA . '/panel.db', null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec('PRAGMA journal_mode=WAL');
        $pdo->exec('PRAGMA busy_timeout=5000');
        bp_migrate($pdo);
    }
    return $pdo;
}

/** Idempotent schema top-ups for panels created before these columns existed. */
function bp_migrate(PDO $pdo): void
{
    try {
        $cols = $pdo->query("PRAGMA table_info(users)")->fetchAll();
        $names = array_column($cols, 'name');
        if ($names && !in_array('role', $names, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'admin'");
        }
    } catch (Throwable $e) { /* fresh db handled by init */ }
    try {
        $pdo->exec('CREATE TABLE IF NOT EXISTS api_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            label TEXT NOT NULL,
            token_hash TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            last_used INTEGER
        )');
    } catch (Throwable $e) { /* ignore */ }
    try {
        $pdo->exec('CREATE TABLE IF NOT EXISTS metrics (
            ts INTEGER PRIMARY KEY,
            cpu REAL NOT NULL,
            mem_pct REAL NOT NULL,
            disk_pct REAL NOT NULL,
            net_rx INTEGER NOT NULL,
            net_tx INTEGER NOT NULL
        )');
    } catch (Throwable $e) { /* ignore */ }
}

function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_check(): void
{
    if (bearer_principal() !== null) { return; } // token auth carries no cookie → CSRF N/A
    $sent = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF'] ?? '');
    if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], (string)$sent)) {
        http_response_code(419);
        exit('CSRF token mismatch');
    }
}

/** Returns the API-token principal for this request, or null. Memoised. */
function bearer_principal(): ?array
{
    static $checked = false;
    static $principal = null;
    if ($checked) { return $principal; }
    $checked = true;

    $hdr = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if ($hdr === '' && function_exists('apache_request_headers')) {
        $h = apache_request_headers();
        $hdr = (string)($h['Authorization'] ?? '');
    }
    if (!preg_match('/^Bearer\s+([A-Za-z0-9_\-]{20,128})$/', $hdr, $m)) {
        return null;
    }
    $hash = hash('sha256', $m[1]);
    $st = db()->prepare('SELECT id, label FROM api_tokens WHERE token_hash = ?');
    $st->execute([$hash]);
    $row = $st->fetch();
    if (!$row) { return null; }
    db()->prepare('UPDATE api_tokens SET last_used = ? WHERE id = ?')->execute([time(), (int)$row['id']]);
    $principal = ['label' => (string)$row['label']];
    return $principal;
}

function logged_in(): bool
{
    return isset($_SESSION['uid']);
}

function current_role(): string
{
    if (bearer_principal() !== null) { return 'admin'; }
    return (string)($_SESSION['role'] ?? 'admin');
}

function is_admin(): bool
{
    return current_role() === 'admin';
}

function require_login_page(): void
{
    if (!logged_in()) {
        header('Location: /login');
        exit;
    }
}

function require_login_api(): void
{
    if (!logged_in() && bearer_principal() === null) {
        json_out(['ok' => false, 'error' => 'unauthenticated'], 401);
    }
}

function require_admin_api(): void
{
    require_login_api();
    if (!is_admin()) {
        json_out(['ok' => false, 'error' => 'admin role required'], 403);
    }
}

function json_out(array $payload, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

function client_ip(): string
{
    return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function audit(string $action, string $detail = ''): void
{
    $bp = bearer_principal();
    $who = $bp !== null ? 'token:' . $bp['label'] : (string)($_SESSION['uname'] ?? '-');
    $st = db()->prepare(
        'INSERT INTO audit (ts, user, ip, action, detail) VALUES (?,?,?,?,?)'
    );
    $st->execute([
        time(),
        $who,
        client_ip(),
        $action,
        $detail,
    ]);
}

function render(string $view, array $data = []): void
{
    extract($data, EXTR_SKIP);
    require __DIR__ . '/views/' . $view . '.php';
    exit;
}
