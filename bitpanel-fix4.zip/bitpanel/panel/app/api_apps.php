<?php
declare(strict_types=1);

/** /api/app/* and /api/wp/* — included by public/index.php. */

function ap_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$apRoute = substr($path, strlen('/api/'));

switch ($apRoute . ':' . $method) {

    case 'app/catalog:GET':
        json_out(AgentClient::call('app.catalog'));

    case 'app/wordpress:POST':
        csrf_check();
        $b = ap_body();
        $res = AgentClient::call('app.wp_install', [
            'site_id' => (string)($b['site_id'] ?? ''), 'title' => (string)($b['title'] ?? ''),
            'admin_user' => (string)($b['admin_user'] ?? ''), 'admin_email' => (string)($b['admin_email'] ?? ''),
        ], 240);
        audit('app.wordpress', (string)($b['site_id'] ?? '') . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'app/phpmyadmin:POST':
        csrf_check();
        $b = ap_body();
        $res = AgentClient::call('app.pma_install', ['site_id' => (string)($b['site_id'] ?? '')], 120);
        audit('app.phpmyadmin', (string)($b['site_id'] ?? ''));
        json_out($res);

    case 'wp/list:GET':
        json_out(AgentClient::call('wp.list', [], 60));

    case 'wp/core-update:POST':
        csrf_check();
        $b = ap_body();
        $res = AgentClient::call('wp.core_update', ['site_id' => (string)($b['site_id'] ?? '')], 200);
        audit('wp.core_update', (string)($b['site_id'] ?? ''));
        json_out($res);

    case 'wp/plugins-update:POST':
        csrf_check();
        $b = ap_body();
        $res = AgentClient::call('wp.plugins_update', ['site_id' => (string)($b['site_id'] ?? '')], 320);
        audit('wp.plugins_update', (string)($b['site_id'] ?? ''));
        json_out($res);

    case 'wp/themes-update:POST':
        csrf_check();
        $b = ap_body();
        $res = AgentClient::call('wp.themes_update', ['site_id' => (string)($b['site_id'] ?? '')], 320);
        audit('wp.themes_update', (string)($b['site_id'] ?? ''));
        json_out($res);

    case 'wp/harden:POST':
        csrf_check();
        $b = ap_body();
        $res = AgentClient::call('wp.harden', ['site_id' => (string)($b['site_id'] ?? '')], 20);
        audit('wp.harden', (string)($b['site_id'] ?? ''));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
