<?php
declare(strict_types=1);

/** /api/php/* — included by public/index.php. */

function php_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$phpRoute = substr($path, strlen('/api/'));

switch ($phpRoute . ':' . $method) {

    case 'php/versions:GET':
        json_out(AgentClient::call('php.versions'));

    case 'php/settings:GET':
        json_out(AgentClient::call('php.settings_get', ['version' => (string)($_GET['version'] ?? '')]));

    case 'php/settings:POST':
        csrf_check();
        $b = php_body();
        $res = AgentClient::call('php.settings_set', [
            'version' => (string)($b['version'] ?? ''),
            'values'  => is_array($b['values'] ?? null) ? $b['values'] : [],
        ], 40);
        audit('php.settings', (string)($b['version'] ?? ''));
        json_out($res);

    case 'php/extensions:GET':
        json_out(AgentClient::call('php.ext_list', ['version' => (string)($_GET['version'] ?? '')]));

    case 'php/ext-toggle:POST':
        csrf_check();
        $b = php_body();
        $res = AgentClient::call('php.ext_toggle', [
            'version' => (string)($b['version'] ?? ''), 'ext' => (string)($b['ext'] ?? ''),
            'enable' => !empty($b['enable']),
        ], 340);
        audit('php.ext', (string)($b['version'] ?? '') . ' ' . (string)($b['ext'] ?? '') . '=' . (!empty($b['enable']) ? '1' : '0'));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
