<?php
declare(strict_types=1);

/**
 * /api/fs/* sub-router. Included by public/index.php.
 * Session is already verified; CSRF verified here for mutations.
 */

const BP_UPTMP = '/opt/bitpanel/data/uptmp';
const BP_DLTMP = '/opt/bitpanel/data/dltmp';

$fsRoute = substr($path, strlen('/api/fs/'));

function fs_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

function fs_path_arg(array $src, string $key = 'path'): string
{
    $p = (string)($src[$key] ?? '');
    if ($p === '' || $p[0] !== '/' || strlen($p) > 4096) {
        json_out(['ok' => false, 'error' => 'invalid path'], 400);
    }
    return $p;
}

switch ($fsRoute . ':' . $method) {

    case 'list:GET':
        json_out(AgentClient::call('fs.list', ['path' => fs_path_arg($_GET)]));

    case 'read:GET':
        json_out(AgentClient::call('fs.read', ['path' => fs_path_arg($_GET)]));

    case 'write:POST':
        csrf_check();
        $b = fs_body();
        $p = fs_path_arg($b);
        $res = AgentClient::call('fs.write', [
            'path'        => $p,
            'content_b64' => (string)($b['content_b64'] ?? ''),
            'create'      => !empty($b['create']),
        ], 60);
        audit('fs.write', $p . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'mkdir:POST':
        csrf_check();
        $p = fs_path_arg(fs_body());
        $res = AgentClient::call('fs.mkdir', ['path' => $p]);
        audit('fs.mkdir', $p);
        json_out($res);

    case 'delete:POST':
        csrf_check();
        $p = fs_path_arg(fs_body());
        $res = AgentClient::call('fs.delete', ['path' => $p], 300);
        audit('fs.delete', $p . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'rename:POST':
        csrf_check();
        $b = fs_body();
        $from = fs_path_arg($b, 'from');
        $to   = fs_path_arg($b, 'to');
        $res  = AgentClient::call('fs.rename', ['from' => $from, 'to' => $to]);
        audit('fs.rename', $from . ' → ' . $to);
        json_out($res);

    case 'chmod:POST':
        csrf_check();
        $b = fs_body();
        $p = fs_path_arg($b);
        $res = AgentClient::call('fs.chmod', [
            'path'      => $p,
            'mode'      => (string)($b['mode'] ?? ''),
            'recursive' => !empty($b['recursive']),
        ], 120);
        audit('fs.chmod', $p . ' mode=' . (string)($b['mode'] ?? ''));
        json_out($res);

    case 'chown:POST':
        csrf_check();
        $b = fs_body();
        $p = fs_path_arg($b);
        $res = AgentClient::call('fs.chown', [
            'path'      => $p,
            'owner'     => (string)($b['owner'] ?? ''),
            'group'     => (string)($b['group'] ?? ''),
            'recursive' => !empty($b['recursive']),
        ], 120);
        audit('fs.chown', $p . ' → ' . (string)($b['owner'] ?? ''));
        json_out($res);

    case 'compress:POST':
        csrf_check();
        $p = fs_path_arg(fs_body());
        $res = AgentClient::call('fs.compress', ['path' => $p], 600);
        audit('fs.compress', $p);
        json_out($res);

    case 'extract:POST':
        csrf_check();
        $p = fs_path_arg(fs_body());
        $res = AgentClient::call('fs.extract', ['path' => $p], 600);
        audit('fs.extract', $p);
        json_out($res);

    case 'upload:POST':
        csrf_check();
        $dest = fs_path_arg($_POST, 'dest');
        if (empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
            json_out(['ok' => false, 'error' => 'no file received (check size limits)'], 400);
        }
        $orig = (string)$_FILES['file']['name'];
        if (!is_dir(BP_UPTMP)) {
            @mkdir(BP_UPTMP, 0770, true);
        }
        $token  = bin2hex(random_bytes(16));
        $staged = BP_UPTMP . '/' . $token;
        if (!move_uploaded_file($_FILES['file']['tmp_name'], $staged)) {
            json_out(['ok' => false, 'error' => 'staging failed'], 500);
        }
        @chmod($staged, 0640);
        $res = AgentClient::call('fs.deploy', [
            'staged'    => $token,
            'dest_dir'  => $dest,
            'name'      => $orig,
            'overwrite' => !empty($_POST['overwrite']),
        ], 120);
        if (empty($res['ok'])) {
            @unlink($staged);
        }
        audit('fs.upload', $dest . '/' . $orig . ' → ' . (!empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err')));
        json_out($res);

    case 'download:GET':
        $p   = fs_path_arg($_GET);
        $res = AgentClient::call('fs.stage_out', ['path' => $p], 300);
        if (empty($res['ok'])) {
            json_out($res, 400);
        }
        $token = (string)$res['data']['token'];
        if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
            json_out(['ok' => false, 'error' => 'bad staging token'], 500);
        }
        $file = BP_DLTMP . '/' . $token;
        if (!is_file($file)) {
            json_out(['ok' => false, 'error' => 'staged file missing'], 500);
        }
        audit('fs.download', $p);
        session_write_close();
        set_time_limit(0);
        header('Content-Type: application/octet-stream');
        header('Content-Length: ' . (string)$res['data']['size']);
        header('Content-Disposition: attachment; filename="'
            . rawurlencode((string)$res['data']['name']) . '"');
        $in = fopen($file, 'rb');
        if ($in !== false) {
            while (!feof($in)) {
                echo fread($in, 262144);
                flush();
            }
            fclose($in);
        }
        @unlink($file);
        exit;

    default:
        json_out(['ok' => false, 'error' => 'unknown fs endpoint'], 404);
}
