<?php
declare(strict_types=1);

/** /api/mail/* — included by public/index.php. */

function ml_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$mlRoute = substr($path, strlen('/api/'));

switch ($mlRoute . ':' . $method) {

    case 'mail/status:GET':
        json_out(AgentClient::call('mail.status'));

    case 'mail/setup:POST':
        csrf_check();
        $res = AgentClient::call('mail.setup', [], 600);
        audit('mail.setup', !empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err'));
        json_out($res);

    case 'mail/hostname:GET':
        json_out(AgentClient::call('mail.hostname_get'));

    case 'mail/hostname:POST':
        csrf_check();
        $b = ml_body();
        $res = AgentClient::call('mail.hostname_set', ['hostname' => (string)($b['hostname'] ?? '')], 40);
        audit('mail.hostname', (string)($b['hostname'] ?? ''));
        json_out($res);

    case 'mail/ssl:POST':
        csrf_check();
        $res = AgentClient::call('mail.ssl_issue', [], 340);
        audit('mail.ssl', !empty($res['ok']) ? 'ok' : (string)($res['error'] ?? 'err'));
        json_out($res);

    case 'mail/domains:GET':
        json_out(AgentClient::call('mail.domain_list'));

    case 'mail/domains:POST':
        csrf_check();
        $b = ml_body();
        $res = AgentClient::call('mail.domain_add', ['domain' => (string)($b['domain'] ?? '')], 40);
        audit('mail.domain_add', (string)($b['domain'] ?? ''));
        json_out($res);

    case 'mail/domain-delete:POST':
        csrf_check();
        $b = ml_body();
        $res = AgentClient::call('mail.domain_delete', ['domain' => (string)($b['domain'] ?? '')], 40);
        audit('mail.domain_delete', (string)($b['domain'] ?? ''));
        json_out($res);

    case 'mail/domain-records:GET':
        json_out(AgentClient::call('mail.domain_records', ['domain' => (string)($_GET['domain'] ?? '')]));

    case 'mail/mailboxes:GET':
        json_out(AgentClient::call('mail.mailbox_list', ['domain' => (string)($_GET['domain'] ?? '')]));

    case 'mail/mailboxes:POST':
        csrf_check();
        $b = ml_body();
        $res = AgentClient::call('mail.mailbox_add', [
            'email' => (string)($b['email'] ?? ''), 'password' => (string)($b['password'] ?? ''),
        ], 30);
        audit('mail.mailbox_add', (string)($b['email'] ?? ''));
        json_out($res);

    case 'mail/mailbox-delete:POST':
        csrf_check();
        $b = ml_body();
        $res = AgentClient::call('mail.mailbox_delete', ['email' => (string)($b['email'] ?? '')], 30);
        audit('mail.mailbox_delete', (string)($b['email'] ?? ''));
        json_out($res);

    case 'mail/mailbox-password:POST':
        csrf_check();
        $b = ml_body();
        $res = AgentClient::call('mail.mailbox_password', [
            'email' => (string)($b['email'] ?? ''), 'password' => (string)($b['password'] ?? ''),
        ], 30);
        audit('mail.mailbox_password', (string)($b['email'] ?? ''));
        json_out($res);

    case 'mail/aliases:GET':
        json_out(AgentClient::call('mail.alias_list'));

    case 'mail/aliases:POST':
        csrf_check();
        $b = ml_body();
        $res = AgentClient::call('mail.alias_add', [
            'from' => (string)($b['from'] ?? ''), 'to' => (string)($b['to'] ?? ''),
        ], 30);
        audit('mail.alias_add', (string)($b['from'] ?? '') . ' → ' . (string)($b['to'] ?? ''));
        json_out($res);

    case 'mail/alias-delete:POST':
        csrf_check();
        $b = ml_body();
        $res = AgentClient::call('mail.alias_delete', ['from' => (string)($b['from'] ?? '')], 30);
        audit('mail.alias_delete', (string)($b['from'] ?? ''));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
