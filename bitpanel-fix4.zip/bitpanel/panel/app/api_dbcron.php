<?php
declare(strict_types=1);

/** /api/db/* and /api/cron/* — included by public/index.php. */

function dc_body(): array
{
    $b = json_decode((string)file_get_contents('php://input'), true);
    return is_array($b) ? $b : [];
}

$dcRoute = substr($path, strlen('/api/'));

switch ($dcRoute . ':' . $method) {

    /* ---- databases ---- */
    case 'db/status:GET':
        json_out(AgentClient::call('db.status'));

    case 'db/list:GET':
        json_out(AgentClient::call('db.list'));

    case 'db/users:GET':
        json_out(AgentClient::call('db.users'));

    case 'db/create:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('db.create', [
            'name' => (string)($b['name'] ?? ''), 'charset' => (string)($b['charset'] ?? 'utf8mb4'),
        ], 30);
        audit('db.create', (string)($b['name'] ?? ''));
        json_out($res);

    case 'db/drop:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('db.drop', ['name' => (string)($b['name'] ?? '')], 30);
        audit('db.drop', (string)($b['name'] ?? ''));
        json_out($res);

    case 'db/user-create:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('db.user_create', [
            'user' => (string)($b['user'] ?? ''), 'host' => (string)($b['host'] ?? 'localhost'),
            'password' => (string)($b['password'] ?? ''), 'database' => (string)($b['database'] ?? ''),
        ], 30);
        audit('db.user_create', (string)($b['user'] ?? '') . '@' . (string)($b['host'] ?? ''));
        json_out($res);

    case 'db/user-drop:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('db.user_drop', [
            'user' => (string)($b['user'] ?? ''), 'host' => (string)($b['host'] ?? ''),
        ], 30);
        audit('db.user_drop', (string)($b['user'] ?? '') . '@' . (string)($b['host'] ?? ''));
        json_out($res);

    case 'db/user-password:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('db.user_password', [
            'user' => (string)($b['user'] ?? ''), 'host' => (string)($b['host'] ?? ''),
            'password' => (string)($b['password'] ?? ''),
        ], 30);
        audit('db.user_password', (string)($b['user'] ?? '') . '@' . (string)($b['host'] ?? ''));
        json_out($res);

    case 'db/tables:GET':
        json_out(AgentClient::call('db.tables', ['database' => (string)($_GET['database'] ?? '')]));

    case 'db/query:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('db.query', [
            'database' => (string)($b['database'] ?? ''), 'sql' => (string)($b['sql'] ?? ''),
        ], 70);
        audit('db.query', (string)($b['database'] ?? '') . ': ' . substr((string)($b['sql'] ?? ''), 0, 80));
        json_out($res);

    /* ---- cron ---- */
    case 'cron/users:GET':
        json_out(AgentClient::call('cron.users'));

    case 'cron/list:GET':
        json_out(AgentClient::call('cron.list', ['user' => (string)($_GET['user'] ?? 'root')]));

    case 'cron/add:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('cron.add', [
            'user' => (string)($b['user'] ?? 'root'),
            'schedule' => (string)($b['schedule'] ?? ''),
            'command' => (string)($b['command'] ?? ''),
        ], 20);
        audit('cron.add', (string)($b['user'] ?? '') . ': ' . (string)($b['schedule'] ?? ''));
        json_out($res);

    case 'cron/delete:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('cron.delete', [
            'user' => (string)($b['user'] ?? 'root'), 'index' => (int)($b['index'] ?? -1),
        ], 20);
        audit('cron.delete', (string)($b['user'] ?? '') . ' #' . (string)($b['index'] ?? ''));
        json_out($res);

    case 'cron/toggle:POST':
        csrf_check();
        $b = dc_body();
        $res = AgentClient::call('cron.toggle', [
            'user' => (string)($b['user'] ?? 'root'), 'index' => (int)($b['index'] ?? -1),
        ], 20);
        audit('cron.toggle', (string)($b['user'] ?? '') . ' #' . (string)($b['index'] ?? ''));
        json_out($res);

    default:
        json_out(['ok' => false, 'error' => 'unknown endpoint'], 404);
}
