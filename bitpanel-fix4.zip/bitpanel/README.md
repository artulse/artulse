# BitPanel — Complete (Phases 1–10)

Self-hosted server console for Ubuntu 24.04. Replaces day-to-day SSH work
with a web panel, aaPanel-style, fully owned by BitHook.

## Install (fresh server)

```bash
scp bitpanel.zip ubuntu@SERVER_IP:~
ssh ubuntu@SERVER_IP
unzip bitpanel.zip && cd bitpanel
sudo bash install.sh            # component checklist appears here
```

Custom port: `PANEL_PORT=9001 sudo -E bash install.sh`

The installer shows a **multi-select checklist** — Nginx/Apache, MySQL/MariaDB/PostgreSQL,
PHP 8.1/8.2/8.3, Node.js, Redis, Memcached, Docker, ttyd, Fail2ban, UFW.
Panel core (PHP 8.3 + SQLite + a dedicated Nginx vhost) always installs.

At the end it prints the URL and a generated admin password
(also saved to `/root/.bitpanel-credentials`). Change it in **Settings** after first login.

## Upgrade (server already running an earlier release)

```bash
unzip bitpanel.zip && cd bitpanel
sudo bash upgrade.sh            # keeps panel.db, agent.key, ssl certs
```

Then hard-refresh the browser (Ctrl+Shift+R) to pick up new JS/CSS.

## AWS notes

- Open the panel port (default **8899/tcp**) in the Security Group, source = office IP only.
- Keep **22/tcp (SSH)** as break-glass access. Never remove it.
- Panel uses a self-signed cert; the first-visit browser warning is expected.

## Architecture

```
Browser ─HTTPS:8899─> Nginx ─> PHP-FPM pool (user: bitpanel, unprivileged)
                          │        │  JSON over Unix socket + shared key
                          │        ▼
                          │   bitpanel-agent (root, systemd)
                          │   strict op allowlist — the ONLY root code
                          │
                          └─/term/─> ttyd @127.0.0.1:7681 (auth_request gated)
```

- Panel state in **SQLite** so it keeps working when managed MySQL is down.
- The agent refuses anything outside its allowlist. Every privileged feature
  is a discrete op — never raw shell from the web tier.

## Phase 1

Auth (bcrypt, IP rate-limit, CSRF, audit log) · live dashboard
(CPU/RAM/disks/net/load/uptime) · service control (start/stop/restart/reload) ·
password change · component installer.

## Phase 2 — file manager + web terminal

**File manager**
- Browse the whole filesystem; sortable listing (dirs first) with size, octal
  perms, owner:group, mtime.
- Create / rename / move / delete (recursive) files and folders.
- In-browser editor for text files up to 2 MB (Ctrl+S to save, tab-to-indent,
  dark editor pane). Binary files offer download instead.
- Upload with real per-file progress (up to 256 MB); overwrite prompt on clash.
- Streamed download of any file up to 512 MB.
- chmod (octal, optional recursive) and chown (owner:group, optional recursive).
- Compress to .zip; extract .zip / .tar.gz / .tgz / .tar in place.

**Web terminal**
- One-click enable: installs ttyd, binds it to 127.0.0.1 only, registers a
  systemd unit, and proxies it through the panel.
- Every terminal request passes an Nginx `auth_request` subrequest against your
  panel session — no session, no socket.
- The shell opens a standard `login` prompt: authenticate as a real system user
  (e.g. `ubuntu`), exactly like the AWS console.

## Phase 3 (this release) — Sites & SSL

**Sites** (Nginx vhosts, all generated + validated by the root agent)
- Create PHP sites (pick any installed PHP-FPM version), static sites, or reverse proxies.
- Auto-creates the document root under `/var/www/<id>` with a placeholder page, owned by www-data.
- Enable / disable (symlink toggle) and delete. Delete removes the vhost + cert but **never** the document root.
- Every change runs `nginx -t` first and rolls back if the config is invalid — a bad site can't take nginx down.

**SSL** (Let's Encrypt via acme.sh, per site)
- One-click "Secure": installs acme.sh on first use, issues over HTTP-01 using a shared
  `/var/www/_letsencrypt` webroot, installs the cert under `/opt/bitpanel/data/ssl/sites/<id>/`,
  and rewrites the vhost with a 443 block.
- Optional forced HTTP → HTTPS redirect per site.
- **Auto-renew is handled by acme.sh's own cron**, with `--reloadcmd "systemctl reload nginx"`
  remembered so renewed certs reload automatically. Nothing else to schedule.
- Requires the domain's DNS pointed here and ports 80/443 open in the AWS Security Group.

### Safety model for the file manager

The agent canonicalises every path and enforces:
- **Secret denylist** — `agent.key` and `panel.db` are never readable or writable
  through the panel.
- **Write denylist** — refuses to modify `/`, `/etc`, `/usr`, `/bin`, `/boot`,
  `/proc`, `/sys`, `/dev`, the panel's own code, and other critical roots.
- Deletes use `rm -rf --one-file-system` and never follow symlinks to their target.
- Uploads are staged to a private temp dir, then atomically placed by the agent.

## Phase 4 (this release) — Databases & Cron

**Databases** (MySQL / MariaDB, auto-detected)
- Connects as root through the local socket (uses `/etc/mysql/debian.cnf` so it works
  even when the MySQL root account has a password).
- Create / drop databases with charset (utf8mb4 / utf8 / latin1); size and table count per db.
- Create / drop users, set host (localhost or %), change passwords, and grant ALL on one
  database at creation. User→database grants are shown in the list.
- All identifiers are validated (`[A-Za-z0-9_]`) and passwords are escaped before reaching SQL.

**Cron**
- Manage crontabs per system user (root, www-data, and human login accounts).
- Add tasks with a 5-field schedule or an `@daily`-style shortcut; delete tasks;
  enable/disable in place (disabled tasks are commented with a BitPanel marker, not removed).
- Schedules and commands are validated; the whole crontab is written atomically via a temp file.

## Phase 5 (this release) — Two-factor authentication

- Time-based one-time codes (RFC 6238 TOTP), self-contained — no external PHP library.
- Enrol from **Settings**: scan the QR (or type the secret) into any authenticator app
  (Google Authenticator, Authy, 1Password, …), confirm one code, and it's on.
- Every login then requires the 6-digit code after the password. Code attempts share the
  same IP rate-limit as passwords, so the 6-digit space can't be brute-forced.
- Disable requires a current code. The secret is stored only in the panel's SQLite users table.
- Locked out (lost authenticator)? Clear it from the server:
  ```bash
  sudo -u bitpanel php -r '$p=new PDO("sqlite:/opt/bitpanel/data/panel.db");$p->exec("UPDATE users SET totp_secret=NULL");'
  ```

## Phase 6 (this release) — Firewall

**UFW**
- Status (active/inactive + default policies), full numbered rule list.
- Add allow/deny/reject/limit rules by port + protocol, optionally scoped to an IP or CIDR source.
- Delete rules by number.
- **Enable is lockout-safe**: the agent detects your real SSH port and this panel's port and
  opens both before turning the firewall on. Installs UFW automatically if it isn't present.

**Fail2ban**
- Lists active jails and, per jail, current bans + failure counts.
- Shows every banned IP with a one-click unban. Manual ban is available via the API.

## Phase 7 (this release) — Software, Backups, Docker, FTP, Logs, Users & API

**Software store** — one-click install/uninstall of Nginx, Apache, MySQL, MariaDB,
PostgreSQL, Redis, Memcached, PHP 8.1/8.2/8.3, Node.js 22, Docker, Fail2ban, UFW, vsftpd.
Panel-critical components (Nginx, PHP 8.3) are locked against removal.

**Backups** — create tar.gz backups of a site's document root, an arbitrary path, or a
mysqldump of a database. List, download, and delete. **Optional S3**: save bucket/region/
credentials (stored root-only) and push any backup to Amazon S3 (installs awscli on demand).

**Docker** — list containers (running or all) and images; start/stop/restart/remove
containers; view container logs. Hidden until Docker is installed.

**FTP** — set up a hardened vsftpd (chrooted local users, passive 40000–40100). Create/delete
FTP accounts and reset passwords; accounts are system users tagged to a dedicated group.

**Logs** — read-only tail of an allowlisted set (nginx, panel, PHP-FPM, MySQL, fail2ban,
auth, syslog), 100–1000 lines.

**Panel users & roles** — add panel accounts as **admin** (full control) or **viewer**
(read-only: can see every page and GET endpoint, blocked from all mutations). The last admin
can't be demoted or deleted. Each user has independent 2FA.

**REST API + tokens** — issue bearer tokens (shown once, stored only as a SHA-256 hash) with
admin rights. Any `/api/…` endpoint accepts `Authorization: Bearer <token>` — no session or
CSRF needed for token calls. Revoke anytime; last-used is tracked.

### API example
```bash
TOKEN=bp_xxxxxxxx…
BASE=https://SERVER:8899
curl -sk -H "Authorization: Bearer $TOKEN" $BASE/api/stats
curl -sk -H "Authorization: Bearer $TOKEN" $BASE/api/sites
curl -sk -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
     -d '{"type":"db","target":"app_production"}' $BASE/api/backup/create
```

## Phase 8 (this release) — PHP manager, App daemons, System tools, Scheduled backups, SQL console

Inspired by the standout modules in cPanel, aaPanel, and CentOS Web Panel — adapted for a single AWS host.

**PHP Manager** — per installed version: edit the common `php.ini` directives
(memory_limit, upload/post size, execution/input time, input vars, display_errors, timezone)
via a managed drop-in, and install/remove common extensions (gd, mbstring, intl, redis,
imagick, …). FPM is restarted on save.

**App Daemons (Supervisor)** — run any long-running app (Node, Python/gunicorn, a worker)
as an auto-restarting systemd service: name + command + working dir + run-as user. Start/stop/
restart, view live logs (journalctl), delete. This is how you host non-PHP apps behind a
reverse-proxy site.

**System** — one page for: package updates (apt refresh + list upgradable + upgrade all),
top processes by CPU or memory with a guarded kill (never the agent or PID 1), and all
listening ports with their owning process.

**Scheduled Backups** — turn any backup target (site / database / path) into a recurring job
with a cron schedule and keep-last-N retention, optionally auto-pushed to S3. A root cron.d
entry runs a backup-runner that creates the archive, prunes old ones, and uploads.

**SQL Console** — on the Databases page: browse a database's tables (rows + size), one-click
"browse" a table, and run arbitrary SQL with results rendered as a table. Admin-only; non-SELECT
statements prompt for confirmation.

### Why no mail or authoritative DNS
On AWS, outbound port 25 is blocked by default (mail deliverability needs a lifted block +
reverse DNS), and DNS is almost always handled by Route 53 rather than an authoritative BIND on
the instance. A half-configured mail server or DNS zone does more harm than good, so these are
intentionally left out; the panel focuses on what a single web host actually runs.

## Phase 9 (this release) — Mail server + Data cleanup

**Mail server** — Postfix (virtual mailboxes) + Dovecot (IMAP/SASL) + OpenDKIM, inspired by
cPanel/aaPanel/CWP's mail modules but scoped to a single AWS host:
- Virtual domains/mailboxes/aliases, no system accounts per mailbox — a dedicated `vmail` user
  owns all mail storage (`/var/vmail/domain/user/`, Maildir format).
- **Not an open relay by default.** Port 25 only accepts mail for domains you've added; sending
  out requires an authenticated login on port 587 (SASL via Dovecot). This is the single most
  important thing to get right on a mail server, so it's hardcoded, not a toggle.
- One-click "Add domain" generates a 2048-bit DKIM key and shows the exact MX / SPF / DKIM /
  DMARC records to add — BitPanel doesn't manage DNS, so you paste these into Route 53 or
  wherever the domain's DNS actually lives.
- Mailboxes and aliases/forwards, each mailbox usable from any IMAP client (Thunderbird,
  Outlook, Apple Mail) on port 993 (IMAP+TLS) / 587 (SMTP submission).
- Mail hostname + its own Let's Encrypt certificate, issued the same way as site certs.

  **Read before using**: as of this release, AWS blocks outbound port 25 by default on every
  EC2 instance (a long-standing anti-spam measure) — inbound mail and the whole mailbox/IMAP
  side work immediately, but *sending to the outside world* needs AWS's "Remove email sending
  limitations" form approved first (submit from the EC2 console; approval isn't guaranteed and
  depends on account history). Until then, incoming mail and internal mailboxes work fine, but
  outbound delivery to Gmail/Outlook/etc. won't. Even once unblocked, a fresh IP has no sending
  reputation — expect early mail to land in spam until SPF/DKIM/DMARC are set and the IP warms
  up. **Not included in this pass**: webmail (use a real IMAP client instead), per-mailbox
  quota enforcement, and greylisting/spam filtering beyond DKIM signing.

**Data cleanup** — a disk-usage breakdown (top space consumers: sites, logs, backups, APT
cache, MySQL data, Docker, mail, journal) plus one-click reclaim actions: APT cache +
autoremove, systemd journal vacuum (cap 200 MB), delete backups older than 30 days, truncate
oversized logs (>20 MB, in place — same technique as `logrotate copytruncate`, doesn't disrupt
the process still writing to it), clear stale panel upload/download temp files, and Docker
`system prune` (containers + images + networks, volumes left alone) when Docker is installed.

## Phase 10 (this release) — closing the aaPanel gap list

**WAF** — native nginx pattern filtering (SQLi/XSS/path-traversal/scanner-UA blocking +
rate limiting), toggled per site from the Sites page. Not ModSecurity/OWASP CRS — no
HTTP-body inspection — but real protection against the automated-scanner traffic that
hits every public IP within minutes of a site going live.

**App Store** — one-click WordPress (WP-CLI powered: downloads core, creates the database,
completes the install wizard, hands back the admin password once) and phpMyAdmin (installs
the official latest-stable build into `/phpmyadmin` under a chosen site).

**WP Toolkit** — auto-detects any site with a `wp-config.php`, not just App Store installs.
Shows core/plugin/theme update counts per site, one-click "update all," and a hardening
toggle (disables the in-dashboard file editor).

**Monitor history** — a root cron job records CPU/mem/disk every 5 minutes into the panel's
own SQLite database (30-day retention, auto-pruned). Dashboard now has a history chart
(24h/7d/30d) alongside the live numbers.

**Security page** — SSH port change, root-login toggle, ping (ICMP) toggle, and an Nginx-level
IP allowlist for the panel itself. All lockout-safety-checked: changing the SSH port opens the
new port in UFW *before* restarting sshd, and the allowlist save is refused server-side if your
own current IP isn't in the list you're submitting.

**Dashboard rollup** — at-a-glance counts (sites running/total, FTP accounts, mail domains/
mailboxes, databases, running containers), matching the summary aaPanel shows on its home page.

## Roadmap — complete

Shipped: dashboard (+ history + rollup), files, terminal, sites, SSL, WAF, mail server
(Postfix/Dovecot/OpenDKIM), databases + SQL console, PHP manager, cron, app daemons, firewall,
security page, software store, system tools, data cleanup, backups (local + S3 + scheduled),
docker, FTP, logs, App Store (WordPress/phpMyAdmin), WP Toolkit, multi-user roles, and a
token-authenticated REST API.

Intentionally not built: authoritative DNS (use Route 53), webmail (use any IMAP client),
per-mailbox quota enforcement, and true cPanel-style per-client tenant isolation (every panel
user currently sees the whole server; admin/viewer are the only two roles) — each is a real
project on its own and the honest move is to leave them out rather than ship something
half-working.

## Ops

```bash
systemctl status bitpanel-agent           # agent health
journalctl -u bitpanel-agent -f           # agent logs
systemctl status bitpanel-ttyd            # terminal daemon
tail -f /var/log/nginx/bitpanel.error.log
crontab -u www-data -l                    # inspect a managed crontab
ls /opt/bitpanel/data/backups             # backup archives
sudo -u bitpanel php -r '$p=new PDO("sqlite:/opt/bitpanel/data/panel.db");foreach($p->query("SELECT username,role FROM users") as $r)echo implode(" ",$r),"\n";'  # list panel users
php /opt/bitpanel/panel/bin/init_db.php admin NEWPASS   # reset admin password
```
