#!/usr/bin/env php
<?php
/**
 * BitPanel agent v2 — the ONLY component that runs as root.
 * JSON-per-line over a Unix socket. Strict op allowlist.
 */
declare(strict_types=1);

const SOCK_PATH = '/run/bitpanel/agent.sock';
const KEY_FILE  = '/opt/bitpanel/data/agent.key';
const UPTMP     = '/opt/bitpanel/data/uptmp';   // panel writes uploads here
const DLTMP     = '/opt/bitpanel/data/dltmp';   // agent stages downloads here
const MAX_REQ   = 12 * 1024 * 1024;             // 12 MB request line
const EDIT_MAX  = 2  * 1024 * 1024;             // in-browser editor limit
const DL_MAX    = 512 * 1024 * 1024;            // download staging cap
const PANEL_GRP = 'bitpanel';
const SITES_DIR    = '/opt/bitpanel/data/sites';      // per-site JSON metadata
const SSL_SITES    = '/opt/bitpanel/data/ssl/sites';  // issued certs per site
const ACME_WEBROOT = '/var/www/_letsencrypt';         // shared HTTP-01 webroot
const NG_AVAIL     = '/etc/nginx/sites-available';
const NG_ENABLED   = '/etc/nginx/sites-enabled';
const ACME_SH      = '/root/.acme.sh/acme.sh';

const ALLOWED_UNITS = [
    'nginx', 'apache2', 'mysql', 'mariadb', 'postgresql',
    'redis-server', 'memcached', 'docker', 'fail2ban', 'ttyd', 'bitpanel-ttyd', 'vsftpd',
    'postfix', 'dovecot', 'opendkim',
    'php8.1-fpm', 'php8.2-fpm', 'php8.3-fpm',
];
const ALLOWED_ACTIONS = ['start', 'stop', 'restart', 'reload'];

/** Paths that fs write/delete must never touch (exact match). */
const DENY_EXACT = [
    '/', '/etc', '/usr', '/var', '/bin', '/sbin', '/lib', '/lib64',
    '/boot', '/proc', '/sys', '/dev', '/run', '/root', '/home', '/opt',
    '/opt/bitpanel', '/opt/bitpanel/data',
];
/** Prefixes that fs write/delete must never touch. */
const DENY_PREFIX = [
    '/proc/', '/sys/', '/dev/', '/run/', '/boot/',
    '/opt/bitpanel/agent', '/opt/bitpanel/panel',
];
/** Never readable or writable through the panel. */
const DENY_SECRET = [
    '/opt/bitpanel/data/agent.key',
    '/opt/bitpanel/data/panel.db',
];

if (function_exists('posix_geteuid') && posix_geteuid() !== 0) {
    fwrite(STDERR, "bitpanel-agent must run as root\n");
    exit(1);
}
$key = trim((string)@file_get_contents(KEY_FILE));
if ($key === '') {
    fwrite(STDERR, "missing agent key\n");
    exit(1);
}

ensure_dirs();

@mkdir(dirname(SOCK_PATH), 0755, true);
@unlink(SOCK_PATH);
$server = stream_socket_server('unix://' . SOCK_PATH, $errno, $errstr);
if ($server === false) {
    fwrite(STDERR, "bind failed: {$errstr}\n");
    exit(1);
}
@chmod(SOCK_PATH, 0660);
@chgrp(SOCK_PATH, PANEL_GRP);
fwrite(STDOUT, "bitpanel-agent v2 listening on " . SOCK_PATH . "\n");

/* ---- constants hoisted above the accept loop (PHP does not hoist const) ---- */
const TTYD_UNIT = '/etc/systemd/system/bitpanel-ttyd.service';
const TTYD_DEF  = <<<UNIT
[Unit]
Description=BitPanel web terminal (ttyd)
After=network.target

[Service]
ExecStart=/usr/bin/ttyd -i 127.0.0.1 -p 7681 -b /term -W /bin/login
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
UNIT;
const DOMAIN_RE   = '/^(?=.{1,253}$)(?!-)[a-z0-9-]{1,63}(?<!-)(\.(?!-)[a-z0-9-]{1,63}(?<!-))+$/i';
const UPSTREAM_RE = '#^https?://(\[[0-9a-fA-F:]+\]|[a-zA-Z0-9.-]+)(:\d{1,5})?(/[A-Za-z0-9._~/-]*)?$#';
const ID_RE       = '/^[a-z0-9]([a-z0-9.-]{0,58}[a-z0-9])?$/';
const WAF_DIR  = '/etc/nginx/waf';
const WAF_CONF = WAF_DIR . '/bitpanel-waf.conf';
const WAF_ZONE = '/etc/nginx/conf.d/bitpanel-waf-zone.conf';
const IDENT_RE = '/^[A-Za-z0-9_]{1,64}$/';
const HOST_RE  = '/^(localhost|%|[A-Za-z0-9_.:%\-]{1,255})$/';
const SYS_DBS  = ['information_schema', 'performance_schema', 'mysql', 'sys'];
const SYS_USERS = ['root', 'mysql.sys', 'mysql.session', 'mysql.infoschema',
                   'debian-sys-maint', 'mariadb.sys', 'PUBLIC', ''];
const CRON_USER_RE = '/^[a-z_][a-z0-9_-]{0,31}$/';
const CRON_OFF     = '#BITPANEL-OFF# ';
const CRON_SPECIAL = '/^@(reboot|yearly|annually|monthly|weekly|daily|midnight|hourly)$/';
const JAIL_RE = '/^[a-zA-Z0-9_.\-]{1,64}$/';
const DOCKER_ID_RE = '/^[a-zA-Z0-9_.\-]{1,64}$/';
const BACKUP_DIR  = '/opt/bitpanel/data/backups';
const S3_CONF     = '/opt/bitpanel/data/s3.json';
const BACKUP_NAME = '/^[A-Za-z0-9._\-]{1,200}$/';
const BUCKET_RE   = '/^[a-z0-9][a-z0-9.\-]{1,61}[a-z0-9]$/';
const FTP_GROUP  = 'bpftp';
const FTP_USER_RE = '/^[a-z_][a-z0-9_\-]{0,31}$/';
const VSFTPD_CONF = <<<CONF
# Managed by BitPanel
listen=YES
listen_ipv6=NO
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022
dirmessage_enable=YES
use_localtime=YES
xferlog_enable=YES
connect_from_port_20=YES
chroot_local_user=YES
allow_writeable_chroot=YES
secure_chroot_dir=/var/run/vsftpd/empty
pam_service_name=vsftpd
pasv_enable=YES
pasv_min_port=40000
pasv_max_port=40100
user_sub_token=\$USER
CONF;
const DAEMON_DIR   = '/opt/bitpanel/data/daemons';
const DAEMON_NAME_RE = '/^[a-z0-9][a-z0-9_\-]{0,39}$/';
const BKJOB_DIR = '/opt/bitpanel/data/bkjobs';
const BKJOB_ID_RE = '/^[a-z0-9][a-z0-9._\-]{0,80}$/';
const MAIL_DIR      = '/opt/bitpanel/data/mail';
const MAIL_CONF     = MAIL_DIR . '/config.json';
const MAIL_DOMAINS  = MAIL_DIR . '/domains.json';
const MAIL_BOXES    = MAIL_DIR . '/mailboxes.json';
const MAIL_ALIASES  = MAIL_DIR . '/aliases.json';
const MAIL_SSL_DIR  = '/opt/bitpanel/data/ssl/mail';
const VMAIL_HOME    = '/var/vmail';
const VMAIL_USER    = 'vmail';
const OPENDKIM_KEYS = '/etc/opendkim/keys';
const EMAIL_RE      = '/^[A-Za-z0-9][A-Za-z0-9._%+\-]{0,63}@[A-Za-z0-9.\-]{1,253}$/';
const WP_CLI_BIN  = '/usr/local/bin/wp';
const WP_CLI_URL  = 'https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar';
const PMA_URL     = 'https://www.phpmyadmin.net/downloads/phpMyAdmin-latest-all-languages.zip';
const APP_ID_RE   = '/^[A-Za-z0-9_. \-]{1,120}$/';
const APP_USER_RE = '/^[A-Za-z0-9_.\-]{1,60}$/';
const SSHD_CONF        = '/etc/ssh/sshd_config';
const SYSCTL_BITPANEL  = '/etc/sysctl.d/99-bitpanel.conf';
const PANEL_ALLOWLIST  = '/etc/nginx/snippets/bitpanel-allowlist.conf';


while (true) {
    $conn = @stream_socket_accept($server, -1);
    if ($conn === false) {
        continue;
    }
    stream_set_timeout($conn, 60);
    $line = read_line($conn, MAX_REQ);
    $out  = ['ok' => false, 'error' => 'bad request'];

    if ($line !== null && $line !== '') {
        $req = json_decode($line, true);
        if (is_array($req) && hash_equals($key, (string)($req['token'] ?? ''))) {
            $op   = (string)($req['op'] ?? '');
            $args = is_array($req['args'] ?? null) ? $req['args'] : [];
            try {
                $out = bp_handle($op, $args);
            } catch (Throwable $e) {
                $out = ['ok' => false, 'error' => 'agent exception: ' . $e->getMessage()];
            }
        } else {
            $out = ['ok' => false, 'error' => 'auth failed'];
        }
    }
    write_all($conn, json_encode($out) . "\n");
    @fclose($conn);
}

/* ======================= framing ========================== */

function read_line($conn, int $max): ?string
{
    $buf = '';
    while (strlen($buf) < $max) {
        $chunk = fgets($conn, 65536);
        if ($chunk === false) {
            break;
        }
        $buf .= $chunk;
        if (substr($buf, -1) === "\n") {
            return $buf;
        }
    }
    return $buf === '' ? null : $buf;
}

function write_all($conn, string $data): void
{
    $len = strlen($data);
    $off = 0;
    while ($off < $len) {
        $n = @fwrite($conn, substr($data, $off, 262144));
        if ($n === false || $n === 0) {
            return;
        }
        $off += $n;
    }
}

/* ======================= dispatch ========================= */

function bp_handle(string $op, array $args): array
{
    switch ($op) {
        case 'ping':            return ['ok' => true, 'data' => 'pong'];
        case 'sys.stats':       return ['ok' => true, 'data' => sys_stats()];
        case 'service.status':  return ['ok' => true, 'data' => service_status()];
        case 'service.action':
            return service_action((string)($args['unit'] ?? ''), (string)($args['action'] ?? ''));

        case 'fs.list':     return fs_list((string)($args['path'] ?? ''));
        case 'fs.read':     return fs_read((string)($args['path'] ?? ''));
        case 'fs.write':    return fs_write((string)($args['path'] ?? ''), (string)($args['content_b64'] ?? ''), !empty($args['create']));
        case 'fs.mkdir':    return fs_mkdir((string)($args['path'] ?? ''));
        case 'fs.delete':   return fs_delete((string)($args['path'] ?? ''));
        case 'fs.rename':   return fs_rename((string)($args['from'] ?? ''), (string)($args['to'] ?? ''));
        case 'fs.chmod':    return fs_chmod((string)($args['path'] ?? ''), (string)($args['mode'] ?? ''), !empty($args['recursive']));
        case 'fs.chown':    return fs_chown((string)($args['path'] ?? ''), (string)($args['owner'] ?? ''), (string)($args['group'] ?? ''), !empty($args['recursive']));
        case 'fs.stage_out':return fs_stage_out((string)($args['path'] ?? ''));
        case 'fs.deploy':   return fs_deploy((string)($args['staged'] ?? ''), (string)($args['dest_dir'] ?? ''), (string)($args['name'] ?? ''), !empty($args['overwrite']));
        case 'fs.compress': return fs_compress((string)($args['path'] ?? ''));
        case 'fs.extract':  return fs_extract((string)($args['path'] ?? ''));

        case 'term.status': return term_status();
        case 'term.setup':  return term_setup();

        case 'php.versions': return ['ok' => true, 'data' => php_versions()];
        case 'site.list':    return ['ok' => true, 'data' => site_list()];
        case 'site.create':  return site_create($args);
        case 'site.delete':  return site_delete((string)($args['id'] ?? ''));
        case 'site.toggle':  return site_toggle((string)($args['id'] ?? ''), !empty($args['enable']));
        case 'ssl.issue':    return ssl_issue((string)($args['id'] ?? ''), !empty($args['force_https']));
        case 'ssl.status':   return ['ok' => true, 'data' => ssl_status((string)($args['id'] ?? ''))];

        case 'db.status':        return ['ok' => true, 'data' => db_status()];
        case 'db.list':          return db_list();
        case 'db.create':        return db_create((string)($args['name'] ?? ''), (string)($args['charset'] ?? 'utf8mb4'));
        case 'db.drop':          return db_drop((string)($args['name'] ?? ''));
        case 'db.users':         return db_users();
        case 'db.user_create':   return db_user_create($args);
        case 'db.user_drop':     return db_user_drop((string)($args['user'] ?? ''), (string)($args['host'] ?? ''));
        case 'db.user_password': return db_user_password((string)($args['user'] ?? ''), (string)($args['host'] ?? ''), (string)($args['password'] ?? ''));

        case 'cron.users':  return ['ok' => true, 'data' => cron_users()];
        case 'cron.list':   return cron_list((string)($args['user'] ?? 'root'));
        case 'cron.add':    return cron_add((string)($args['user'] ?? 'root'), (string)($args['schedule'] ?? ''), (string)($args['command'] ?? ''));
        case 'cron.delete': return cron_delete((string)($args['user'] ?? 'root'), (int)($args['index'] ?? -1));
        case 'cron.toggle': return cron_toggle((string)($args['user'] ?? 'root'), (int)($args['index'] ?? -1));

        case 'fw.status': return ['ok' => true, 'data' => fw_status()];
        case 'fw.rules':  return fw_rules();
        case 'fw.add':    return fw_add($args);
        case 'fw.delete': return fw_delete((int)($args['num'] ?? -1));
        case 'fw.toggle': return fw_toggle(!empty($args['enable']));

        case 'f2b.status': return ['ok' => true, 'data' => f2b_status()];
        case 'f2b.jail':   return f2b_jail((string)($args['jail'] ?? ''));
        case 'f2b.unban':  return f2b_action('unbanip', (string)($args['jail'] ?? ''), (string)($args['ip'] ?? ''));
        case 'f2b.ban':    return f2b_action('banip', (string)($args['jail'] ?? ''), (string)($args['ip'] ?? ''));

        case 'soft.catalog':   return ['ok' => true, 'data' => soft_catalog()];
        case 'soft.install':   return soft_install((string)($args['key'] ?? ''));
        case 'soft.uninstall': return soft_uninstall((string)($args['key'] ?? ''));

        case 'log.list': return ['ok' => true, 'data' => log_list()];
        case 'log.tail': return log_tail((string)($args['path'] ?? ''), (int)($args['lines'] ?? 200));

        case 'docker.ps':     return docker_ps(!empty($args['all']));
        case 'docker.images': return docker_images();
        case 'docker.action': return docker_action((string)($args['id'] ?? ''), (string)($args['action'] ?? ''));
        case 'docker.logs':   return docker_logs((string)($args['id'] ?? ''), (int)($args['lines'] ?? 200));

        case 'backup.list':   return ['ok' => true, 'data' => backup_list()];
        case 'backup.create': return backup_create($args);
        case 'backup.delete': return backup_delete((string)($args['name'] ?? ''));
        case 's3.get':        return ['ok' => true, 'data' => s3_get()];
        case 's3.set':        return s3_set($args);
        case 's3.push':       return s3_push((string)($args['name'] ?? ''));

        case 'ftp.status':   return ['ok' => true, 'data' => ftpacct_status()];
        case 'ftp.setup':    return ftpacct_setup();
        case 'ftp.users':    return ['ok' => true, 'data' => ftpacct_users()];
        case 'ftp.add':      return ftpacct_add($args);
        case 'ftp.delete':   return ftpacct_delete((string)($args['user'] ?? ''));
        case 'ftp.password': return ftpacct_password((string)($args['user'] ?? ''), (string)($args['password'] ?? ''));

        case 'php.settings_get': return php_settings_get((string)($args['version'] ?? ''));
        case 'php.settings_set': return php_settings_set((string)($args['version'] ?? ''), is_array($args['values'] ?? null) ? $args['values'] : []);
        case 'php.ext_list':     return php_ext_list((string)($args['version'] ?? ''));
        case 'php.ext_toggle':   return php_ext_toggle((string)($args['version'] ?? ''), (string)($args['ext'] ?? ''), !empty($args['enable']));

        case 'daemon.list':   return ['ok' => true, 'data' => daemon_list()];
        case 'daemon.create': return daemon_create($args);
        case 'daemon.action': return daemon_action((string)($args['name'] ?? ''), (string)($args['action'] ?? ''));
        case 'daemon.delete': return daemon_delete((string)($args['name'] ?? ''));
        case 'daemon.logs':   return daemon_logs((string)($args['name'] ?? ''), (int)($args['lines'] ?? 200));

        case 'sys.updates': return sys_updates();
        case 'sys.upgrade': return sys_upgrade();
        case 'proc.top':    return ['ok' => true, 'data' => proc_top((string)($args['sort'] ?? 'cpu'))];
        case 'proc.kill':   return proc_kill((int)($args['pid'] ?? -1), (string)($args['signal'] ?? 'TERM'));
        case 'net.listening': return ['ok' => true, 'data' => net_listening()];

        case 'bkjob.list':   return ['ok' => true, 'data' => bkjob_list()];
        case 'bkjob.create': return bkjob_create($args);
        case 'bkjob.delete': return bkjob_delete((string)($args['id'] ?? ''));

        case 'db.tables': return db_tables((string)($args['database'] ?? ''));
        case 'db.query':  return db_query((string)($args['database'] ?? ''), (string)($args['sql'] ?? ''));

        case 'mail.status':        return ['ok' => true, 'data' => mail_status()];
        case 'mail.setup':         return mail_setup();
        case 'mail.hostname_get':  return ['ok' => true, 'data' => mail_config_get()];
        case 'mail.hostname_set':  return mail_hostname_set((string)($args['hostname'] ?? ''));
        case 'mail.ssl_issue':     return mail_ssl_issue();
        case 'mail.domain_list':   return ['ok' => true, 'data' => mail_domain_list()];
        case 'mail.domain_add':    return mail_domain_add((string)($args['domain'] ?? ''));
        case 'mail.domain_delete': return mail_domain_delete((string)($args['domain'] ?? ''));
        case 'mail.domain_records':return mail_domain_records((string)($args['domain'] ?? ''));
        case 'mail.mailbox_list':  return ['ok' => true, 'data' => mail_mailbox_list((string)($args['domain'] ?? ''))];
        case 'mail.mailbox_add':   return mail_mailbox_add((string)($args['email'] ?? ''), (string)($args['password'] ?? ''));
        case 'mail.mailbox_delete':return mail_mailbox_delete((string)($args['email'] ?? ''));
        case 'mail.mailbox_password': return mail_mailbox_password((string)($args['email'] ?? ''), (string)($args['password'] ?? ''));
        case 'mail.alias_list':    return ['ok' => true, 'data' => mail_alias_list()];
        case 'mail.alias_add':     return mail_alias_add((string)($args['from'] ?? ''), (string)($args['to'] ?? ''));
        case 'mail.alias_delete':  return mail_alias_delete((string)($args['from'] ?? ''));

        case 'cleanup.disk_usage': return ['ok' => true, 'data' => cleanup_disk_usage()];
        case 'cleanup.scan':       return ['ok' => true, 'data' => cleanup_scan()];
        case 'cleanup.run':        return cleanup_run((string)($args['action'] ?? ''), is_array($args['params'] ?? null) ? $args['params'] : []);

        case 'waf.status':      return ['ok' => true, 'data' => waf_status()];
        case 'site.waf_toggle': return site_waf_toggle((string)($args['id'] ?? ''), !empty($args['enable']));

        case 'app.catalog':      return ['ok' => true, 'data' => app_catalog()];
        case 'app.wp_install':   return app_wordpress_install($args);
        case 'app.pma_install':  return app_phpmyadmin_install((string)($args['site_id'] ?? ''));

        case 'wp.list':          return wp_list();
        case 'wp.core_update':   return wp_action((string)($args['site_id'] ?? ''), 'core update', 180);
        case 'wp.plugins_update':return wp_action((string)($args['site_id'] ?? ''), 'plugin update --all', 300);
        case 'wp.themes_update': return wp_action((string)($args['site_id'] ?? ''), 'theme update --all', 300);
        case 'wp.harden':        return wp_harden((string)($args['site_id'] ?? ''));

        case 'overview.summary': return ['ok' => true, 'data' => overview_summary()];

        case 'sec.get':             return ['ok' => true, 'data' => sec_get()];
        case 'sec.ssh_port_set':    return sec_ssh_port_set((int)($args['port'] ?? 0));
        case 'sec.root_login_set':  return sec_root_login_set(!empty($args['enabled']));
        case 'sec.ping_set':        return sec_ping_set(!empty($args['disabled']));
        case 'sec.allowlist_set':   return sec_allowlist_set(is_array($args['ips'] ?? null) ? $args['ips'] : []);

        default:
            return ['ok' => false, 'error' => "unknown op: {$op}"];
    }
}

function shell_out(string $cmd, int $timeout = 60): array
{
    $lines = [];
    $rc    = 1;
    exec('timeout ' . (int)$timeout . ' ' . $cmd . ' 2>&1', $lines, $rc);
    return [$rc, implode("\n", array_slice($lines, 0, 60))];
}

function ensure_dirs(): void
{
    foreach ([UPTMP, DLTMP] as $d) {
        if (!is_dir($d)) {
            @mkdir($d, 0770, true);
        }
        @chgrp($d, PANEL_GRP);
        @chown($d, PANEL_GRP);
        @chmod($d, 0770);
    }
}

/* ==================== path safety ========================= */

/** Canonicalise an absolute path. If $mustExist, resolves symlinks fully. */
function canon(string $p, bool $mustExist): ?string
{
    if ($p === '' || $p[0] !== '/' || strpos($p, "\0") !== false) {
        return null;
    }
    $parts = [];
    foreach (explode('/', $p) as $seg) {
        if ($seg === '' || $seg === '.') {
            continue;
        }
        if ($seg === '..') {
            array_pop($parts);
            continue;
        }
        $parts[] = $seg;
    }
    $clean = '/' . implode('/', $parts);
    if ($mustExist) {
        $rp = ($clean === '/') ? '/' : realpath($clean);
        return $rp === false ? null : $rp;
    }
    if (file_exists($clean)) {
        return $clean; // will be re-checked by caller with lstat semantics
    }
    $parent = realpath(dirname($clean));
    if ($parent === false || !is_dir($parent)) {
        return null;
    }
    return rtrim($parent, '/') . '/' . basename($clean);
}

function is_protected(string $canonical, bool $forWrite): ?string
{
    foreach (DENY_SECRET as $s) {
        if ($canonical === $s) {
            return 'this path is protected (panel secret)';
        }
    }
    if (!$forWrite) {
        return null;
    }
    foreach (DENY_EXACT as $d) {
        if ($canonical === $d) {
            return 'refusing to modify critical system path';
        }
    }
    foreach (DENY_PREFIX as $d) {
        if (strpos($canonical, $d) === 0) {
            return 'refusing to modify protected path';
        }
    }
    return null;
}

/* ====================== fs ops ============================ */

function fs_list(string $path): array
{
    $dir = canon($path, true);
    if ($dir === null || !is_dir($dir)) {
        return ['ok' => false, 'error' => 'directory not found'];
    }
    $names = @scandir($dir);
    if ($names === false) {
        return ['ok' => false, 'error' => 'cannot read directory'];
    }
    $entries = [];
    foreach ($names as $n) {
        if ($n === '.' || $n === '..') {
            continue;
        }
        $full = rtrim($dir, '/') . '/' . $n;
        $st   = @lstat($full);
        if ($st === false) {
            continue;
        }
        $isLink = is_link($full);
        $type   = $isLink ? 'link' : (is_dir($full) ? 'dir' : 'file');
        $pw = function_exists('posix_getpwuid') ? posix_getpwuid($st['uid']) : false;
        $gr = function_exists('posix_getgrgid') ? posix_getgrgid($st['gid']) : false;
        $entries[] = [
            'name'  => $n,
            'type'  => $type,
            'size'  => (float)$st['size'],
            'mode'  => substr(sprintf('%o', $st['mode']), -4),
            'owner' => $pw['name'] ?? (string)$st['uid'],
            'group' => $gr['name'] ?? (string)$st['gid'],
            'mtime' => (int)$st['mtime'],
            'target'=> $isLink ? (string)@readlink($full) : null,
        ];
    }
    usort($entries, static function ($a, $b) {
        $ad = $a['type'] === 'dir' ? 0 : 1;
        $bd = $b['type'] === 'dir' ? 0 : 1;
        return $ad === $bd ? strcasecmp($a['name'], $b['name']) : $ad <=> $bd;
    });
    return ['ok' => true, 'data' => ['path' => $dir, 'entries' => $entries]];
}

function fs_read(string $path): array
{
    $f = canon($path, true);
    if ($f === null || !is_file($f)) {
        return ['ok' => false, 'error' => 'file not found'];
    }
    if ($err = is_protected($f, false)) {
        return ['ok' => false, 'error' => $err];
    }
    $size = (int)filesize($f);
    if ($size > EDIT_MAX) {
        return ['ok' => false, 'error' => 'file larger than 2 MB — use Download'];
    }
    $content = (string)@file_get_contents($f);
    $binary  = strpos(substr($content, 0, 8192), "\0") !== false;
    return ['ok' => true, 'data' => [
        'path' => $f, 'size' => $size, 'binary' => $binary,
        'content_b64' => $binary ? '' : base64_encode($content),
    ]];
}

function fs_write(string $path, string $b64, bool $create): array
{
    $f = canon($path, false);
    if ($f === null) {
        return ['ok' => false, 'error' => 'invalid path (parent must exist)'];
    }
    if ($err = is_protected($f, true)) {
        return ['ok' => false, 'error' => $err];
    }
    if (is_link($f) || is_dir($f)) {
        return ['ok' => false, 'error' => 'target is a directory or symlink'];
    }
    if (!file_exists($f) && !$create) {
        return ['ok' => false, 'error' => 'file does not exist'];
    }
    $content = base64_decode($b64, true);
    if ($content === false) {
        return ['ok' => false, 'error' => 'bad content encoding'];
    }
    $existed = file_exists($f);
    if (@file_put_contents($f, $content) === false) {
        return ['ok' => false, 'error' => 'write failed'];
    }
    if (!$existed) {
        @chmod($f, 0644);
    }
    return ['ok' => true, 'data' => ['path' => $f, 'size' => strlen($content)]];
}

function fs_mkdir(string $path): array
{
    $d = canon($path, false);
    if ($d === null) {
        return ['ok' => false, 'error' => 'invalid path (parent must exist)'];
    }
    if ($err = is_protected($d, true)) {
        return ['ok' => false, 'error' => $err];
    }
    if (file_exists($d)) {
        return ['ok' => false, 'error' => 'already exists'];
    }
    return @mkdir($d, 0755)
        ? ['ok' => true, 'data' => $d]
        : ['ok' => false, 'error' => 'mkdir failed'];
}

function fs_delete(string $path): array
{
    // Use lstat semantics: never follow a symlink to its target.
    $c = canon($path, false);
    if ($c === null || !file_exists($c) && !is_link($c)) {
        return ['ok' => false, 'error' => 'not found'];
    }
    $guard = is_link($c) ? $c : (realpath($c) ?: $c);
    if ($err = is_protected($guard, true)) {
        return ['ok' => false, 'error' => $err];
    }
    if (is_link($c) || is_file($c)) {
        return @unlink($c)
            ? ['ok' => true, 'data' => 'deleted']
            : ['ok' => false, 'error' => 'unlink failed'];
    }
    [$rc, $out] = shell_out('rm -rf --one-file-system -- ' . escapeshellarg($c), 300);
    return $rc === 0
        ? ['ok' => true, 'data' => 'deleted']
        : ['ok' => false, 'error' => "rm failed: {$out}"];
}

function fs_rename(string $from, string $to): array
{
    $src = canon($from, true);
    $dst = canon($to, false);
    if ($src === null || $dst === null) {
        return ['ok' => false, 'error' => 'invalid path'];
    }
    if (($err = is_protected($src, true)) || ($err = is_protected($dst, true))) {
        return ['ok' => false, 'error' => $err];
    }
    if (file_exists($dst)) {
        return ['ok' => false, 'error' => 'destination already exists'];
    }
    return @rename($src, $dst)
        ? ['ok' => true, 'data' => $dst]
        : ['ok' => false, 'error' => 'rename failed'];
}

function fs_chmod(string $path, string $mode, bool $recursive): array
{
    $c = canon($path, true);
    if ($c === null) {
        return ['ok' => false, 'error' => 'not found'];
    }
    if ($err = is_protected($c, true)) {
        return ['ok' => false, 'error' => $err];
    }
    if (!preg_match('/^[0-7]{3,4}$/', $mode)) {
        return ['ok' => false, 'error' => 'mode must be octal like 644 or 0755'];
    }
    $flag = $recursive && is_dir($c) ? '-R ' : '';
    [$rc, $out] = shell_out('chmod ' . $flag . escapeshellarg($mode) . ' -- ' . escapeshellarg($c), 120);
    return $rc === 0
        ? ['ok' => true, 'data' => 'mode set']
        : ['ok' => false, 'error' => "chmod failed: {$out}"];
}

function fs_chown(string $path, string $owner, string $group, bool $recursive): array
{
    $c = canon($path, true);
    if ($c === null) {
        return ['ok' => false, 'error' => 'not found'];
    }
    if ($err = is_protected($c, true)) {
        return ['ok' => false, 'error' => $err];
    }
    $re = '/^[a-z_][a-z0-9_.-]{0,31}$/';
    if (!preg_match($re, $owner) || ($group !== '' && !preg_match($re, $group))) {
        return ['ok' => false, 'error' => 'invalid owner or group name'];
    }
    $spec = $owner . ($group !== '' ? ':' . $group : '');
    $flag = $recursive && is_dir($c) ? '-R ' : '';
    [$rc, $out] = shell_out('chown ' . $flag . escapeshellarg($spec) . ' -- ' . escapeshellarg($c), 120);
    return $rc === 0
        ? ['ok' => true, 'data' => 'owner set']
        : ['ok' => false, 'error' => "chown failed: {$out}"];
}

function fs_stage_out(string $path): array
{
    $f = canon($path, true);
    if ($f === null || !is_file($f)) {
        return ['ok' => false, 'error' => 'file not found'];
    }
    if ($err = is_protected($f, false)) {
        return ['ok' => false, 'error' => $err];
    }
    $size = (int)filesize($f);
    if ($size > DL_MAX) {
        return ['ok' => false, 'error' => 'file larger than 512 MB — use scp/rsync'];
    }
    ensure_dirs();
    $token = bin2hex(random_bytes(16));
    $dst   = DLTMP . '/' . $token;
    if (!@copy($f, $dst)) {
        return ['ok' => false, 'error' => 'staging copy failed'];
    }
    @chgrp($dst, PANEL_GRP);
    @chmod($dst, 0640);
    return ['ok' => true, 'data' => ['token' => $token, 'size' => $size, 'name' => basename($f)]];
}

function fs_deploy(string $staged, string $destDir, string $name, bool $overwrite): array
{
    if (!preg_match('/^[a-f0-9]{32}$/', $staged)) {
        return ['ok' => false, 'error' => 'bad staging token'];
    }
    $src = realpath(UPTMP . '/' . $staged);
    if ($src === false || strpos($src, UPTMP . '/') !== 0 || !is_file($src)) {
        return ['ok' => false, 'error' => 'staged upload not found'];
    }
    $dir = canon($destDir, true);
    if ($dir === null || !is_dir($dir)) {
        return ['ok' => false, 'error' => 'destination directory not found'];
    }
    $name = basename($name);
    if ($name === '' || $name === '.' || $name === '..' || strpos($name, "\0") !== false) {
        return ['ok' => false, 'error' => 'bad file name'];
    }
    $dest = rtrim($dir, '/') . '/' . $name;
    if ($err = is_protected($dest, true)) {
        return ['ok' => false, 'error' => $err];
    }
    if (file_exists($dest) && !$overwrite) {
        return ['ok' => false, 'error' => 'exists', 'exists' => true];
    }
    if (!@rename($src, $dest)) {
        if (!@copy($src, $dest)) {
            return ['ok' => false, 'error' => 'could not place file'];
        }
        @unlink($src);
    }
    @chmod($dest, 0644);
    return ['ok' => true, 'data' => $dest];
}

function fs_compress(string $path): array
{
    $c = canon($path, true);
    if ($c === null || $c === '/') {
        return ['ok' => false, 'error' => 'not found'];
    }
    $dest = $c . '.zip';
    $i = 1;
    while (file_exists($dest)) {
        $dest = $c . '-' . (++$i) . '.zip';
    }
    if ($err = is_protected($dest, true)) {
        return ['ok' => false, 'error' => $err];
    }
    $parent = dirname($c);
    [$rc, $out] = shell_out(
        'cd ' . escapeshellarg($parent) . ' && zip -qry ' . escapeshellarg($dest)
        . ' -- ' . escapeshellarg(basename($c)),
        600
    );
    return $rc === 0
        ? ['ok' => true, 'data' => $dest]
        : ['ok' => false, 'error' => "zip failed: {$out}"];
}

function fs_extract(string $path): array
{
    $f = canon($path, true);
    if ($f === null || !is_file($f)) {
        return ['ok' => false, 'error' => 'archive not found'];
    }
    $dir = dirname($f);
    if ($err = is_protected(rtrim($dir, '/') . '/x', true)) {
        return ['ok' => false, 'error' => $err];
    }
    $lower = strtolower($f);
    if (substr($lower, -4) === '.zip') {
        $cmd = 'unzip -oq ' . escapeshellarg($f) . ' -d ' . escapeshellarg($dir);
    } elseif (substr($lower, -7) === '.tar.gz' || substr($lower, -4) === '.tgz') {
        $cmd = 'tar -xzf ' . escapeshellarg($f) . ' -C ' . escapeshellarg($dir);
    } elseif (substr($lower, -4) === '.tar') {
        $cmd = 'tar -xf ' . escapeshellarg($f) . ' -C ' . escapeshellarg($dir);
    } else {
        return ['ok' => false, 'error' => 'supported: .zip .tar.gz .tgz .tar'];
    }
    [$rc, $out] = shell_out($cmd, 600);
    return $rc === 0
        ? ['ok' => true, 'data' => $dir]
        : ['ok' => false, 'error' => "extract failed: {$out}"];
}

/* ===================== terminal =========================== */


function term_status(): array
{
    $bin = is_file('/usr/bin/ttyd');
    $st  = unit_state('bitpanel-ttyd');
    return ['ok' => true, 'data' => [
        'installed' => $bin,
        'unit'      => $st['load'] !== 'not-found',
        'active'    => $st['active'] === 'active',
        'state'     => $st,
    ]];
}

function term_setup(): array
{
    if (!is_file('/usr/bin/ttyd')) {
        [$rc, $out] = shell_out('DEBIAN_FRONTEND=noninteractive apt-get install -y ttyd', 300);
        if ($rc !== 0 || !is_file('/usr/bin/ttyd')) {
            return ['ok' => false, 'error' => "ttyd install failed: {$out}"];
        }
    }
    if (@file_put_contents(TTYD_UNIT, TTYD_DEF . "\n") === false) {
        return ['ok' => false, 'error' => 'could not write systemd unit'];
    }
    shell_out('systemctl daemon-reload', 60);
    [$rc, $out] = shell_out('systemctl enable --now bitpanel-ttyd', 60);
    if ($rc !== 0) {
        return ['ok' => false, 'error' => "enable failed: {$out}"];
    }
    return term_status();
}

/* ================== stats & services ====================== */

function cpu_times(): array
{
    $first = strtok((string)@file_get_contents('/proc/stat'), "\n");
    $parts = preg_split('/\s+/', trim((string)$first));
    array_shift($parts);
    return array_map('intval', $parts);
}

function cpu_percent(): float
{
    $a = cpu_times();
    usleep(250000);
    $b = cpu_times();
    if (count($a) < 5 || count($b) < 5) {
        return 0.0;
    }
    $dTot  = array_sum($b) - array_sum($a);
    $dIdle = ($b[3] + $b[4]) - ($a[3] + $a[4]);
    return $dTot > 0 ? round(100.0 * (1.0 - $dIdle / $dTot), 1) : 0.0;
}

function meminfo(): array
{
    $out = [];
    foreach (explode("\n", (string)@file_get_contents('/proc/meminfo')) as $line) {
        if (preg_match('/^(\w+):\s+(\d+)/', $line, $m)) {
            $out[$m[1]] = (int)$m[2] * 1024;
        }
    }
    return [
        'total'      => $out['MemTotal']     ?? 0,
        'available'  => $out['MemAvailable'] ?? 0,
        'swap_total' => $out['SwapTotal']    ?? 0,
        'swap_free'  => $out['SwapFree']     ?? 0,
    ];
}

function disks(): array
{
    $seen = [];
    $res  = [];
    foreach (explode("\n", (string)@file_get_contents('/proc/mounts')) as $line) {
        $p = explode(' ', $line);
        if (count($p) < 2 || strpos($p[0], '/dev/') !== 0) {
            continue;
        }
        $mount = str_replace('\\040', ' ', $p[1]);
        if (isset($seen[$p[0]]) || count($res) >= 8) {
            continue;
        }
        $seen[$p[0]] = true;
        $total = @disk_total_space($mount);
        $free  = @disk_free_space($mount);
        if ($total === false || $free === false || $total <= 0) {
            continue;
        }
        $res[] = ['mount' => $mount, 'total' => (float)$total, 'used' => (float)($total - $free)];
    }
    return $res;
}

function net_totals(): array
{
    $rx = 0;
    $tx = 0;
    foreach (explode("\n", (string)@file_get_contents('/proc/net/dev')) as $line) {
        if (strpos($line, ':') === false) {
            continue;
        }
        [$iface, $rest] = explode(':', $line, 2);
        if (trim($iface) === 'lo') {
            continue;
        }
        $f = preg_split('/\s+/', trim($rest));
        if (count($f) >= 9) {
            $rx += (int)$f[0];
            $tx += (int)$f[8];
        }
    }
    return ['rx' => $rx, 'tx' => $tx, 'ts' => microtime(true)];
}

function sys_stats(): array
{
    $load  = function_exists('sys_getloadavg') ? sys_getloadavg() : [0, 0, 0];
    $osrel = (string)@file_get_contents('/etc/os-release');
    $os    = preg_match('/PRETTY_NAME="([^"]+)"/', $osrel, $m) ? $m[1] : PHP_OS;
    $cores = (int)substr_count((string)@file_get_contents('/proc/cpuinfo'), "\nprocessor") + 1;
    return [
        'hostname' => (string)gethostname(),
        'os'       => $os,
        'kernel'   => php_uname('r'),
        'cores'    => max(1, $cores),
        'uptime'   => (float)strtok((string)@file_get_contents('/proc/uptime'), ' '),
        'load'     => array_map(static fn($v) => round((float)$v, 2), $load),
        'cpu'      => cpu_percent(),
        'mem'      => meminfo(),
        'disks'    => disks(),
        'net'      => net_totals(),
        'time'     => time(),
    ];
}

function unit_state(string $unit): array
{
    [$rc, $out] = shell_out('systemctl show ' . escapeshellarg($unit . '.service')
        . ' --property=LoadState,ActiveState,SubState --no-pager', 20);
    $props = [];
    foreach (explode("\n", $out) as $line) {
        if (strpos($line, '=') !== false) {
            [$k, $v] = explode('=', $line, 2);
            $props[$k] = $v;
        }
    }
    return [
        'load'   => $props['LoadState']   ?? 'unknown',
        'active' => $props['ActiveState'] ?? 'unknown',
        'sub'    => $props['SubState']    ?? 'unknown',
    ];
}

function service_status(): array
{
    $res = [];
    foreach (ALLOWED_UNITS as $unit) {
        $st = unit_state($unit);
        if ($st['load'] === 'not-found') {
            continue;
        }
        $res[] = ['unit' => $unit] + $st;
    }
    return $res;
}

function service_action(string $unit, string $action): array
{
    if (!in_array($unit, ALLOWED_UNITS, true)) {
        return ['ok' => false, 'error' => 'unit not in allowlist'];
    }
    if (!in_array($action, ALLOWED_ACTIONS, true)) {
        return ['ok' => false, 'error' => 'action not allowed'];
    }
    [$rc, $out] = shell_out('systemctl ' . escapeshellarg($action) . ' '
        . escapeshellarg($unit . '.service'), 60);
    return $rc === 0
        ? ['ok' => true, 'data' => "{$unit} {$action}: done"]
        : ['ok' => false, 'error' => "systemctl rc={$rc}: {$out}"];
}

/* ================= sites & SSL =========================== */


function sites_ensure(): void
{
    foreach ([SITES_DIR, SSL_SITES] as $d) {
        if (!is_dir($d)) { @mkdir($d, 0750, true); }
    }
    if (!is_dir(ACME_WEBROOT)) {
        @mkdir(ACME_WEBROOT . '/.well-known/acme-challenge', 0755, true);
        @shell_exec('chown -R www-data:www-data ' . escapeshellarg(ACME_WEBROOT));
    }
}

function php_versions(): array
{
    $out = [];
    foreach (glob('/run/php/php*-fpm.sock') ?: [] as $sock) {
        if (preg_match('/php(\d+\.\d+)-fpm\.sock$/', $sock, $m)) {
            $out[] = ['version' => $m[1], 'sock' => $sock];
        }
    }
    usort($out, static fn($a, $b) => version_compare($b['version'], $a['version']));
    return $out;
}

function site_path(string $id): string { return SITES_DIR . '/' . $id . '.json'; }
function ng_conf(string $id): string   { return NG_AVAIL . '/bitpanel-' . $id . '.conf'; }
function ng_link(string $id): string   { return NG_ENABLED . '/bitpanel-' . $id . '.conf'; }

function site_load(string $id): ?array
{
    if (!preg_match(ID_RE, $id)) { return null; }
    $j = @file_get_contents(site_path($id));
    if ($j === false) { return null; }
    $s = json_decode($j, true);
    return is_array($s) ? $s : null;
}

function site_save(array $s): void
{
    @file_put_contents(site_path($s['id']), json_encode($s, JSON_PRETTY_PRINT));
    @chmod(site_path($s['id']), 0640);
}

function cert_expiry(string $id): ?int
{
    $fc = SSL_SITES . '/' . $id . '/fullchain.pem';
    if (!is_file($fc)) { return null; }
    $out = (string)@shell_exec('openssl x509 -enddate -noout -in ' . escapeshellarg($fc) . ' 2>/dev/null');
    if (preg_match('/notAfter=(.+)/', $out, $m)) {
        $ts = strtotime(trim($m[1]));
        return $ts !== false ? $ts : null;
    }
    return null;
}

function site_list(): array
{
    sites_ensure();
    $res = [];
    foreach (glob(SITES_DIR . '/*.json') ?: [] as $f) {
        $s = json_decode((string)@file_get_contents($f), true);
        if (!is_array($s)) { continue; }
        $s['enabled'] = is_link(ng_link($s['id'])) || is_file(ng_link($s['id']));
        $s['cert_expiry'] = !empty($s['ssl']) ? cert_expiry($s['id']) : null;
        $res[] = $s;
    }
    usort($res, static fn($a, $b) => strcmp($a['id'], $b['id']));
    return $res;
}

function render_conf(array $s): string
{
    $names = implode(' ', $s['domains']);
    $acme  = "    location ^~ /.well-known/acme-challenge/ {\n"
           . "        root " . ACME_WEBROOT . ";\n"
           . "        default_type \"text/plain\";\n"
           . "    }\n";

    // body that actually serves the site
    if ($s['type'] === 'proxy') {
        $body = "    location / {\n"
              . "        proxy_pass " . $s['upstream'] . ";\n"
              . "        proxy_http_version 1.1;\n"
              . "        proxy_set_header Host \$host;\n"
              . "        proxy_set_header X-Real-IP \$remote_addr;\n"
              . "        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;\n"
              . "        proxy_set_header X-Forwarded-Proto \$scheme;\n"
              . "        proxy_set_header Upgrade \$http_upgrade;\n"
              . "        proxy_set_header Connection \"upgrade\";\n"
              . "        proxy_read_timeout 300s;\n"
              . "    }\n";
        $rootline = '';
    } else {
        $rootline = "    root " . $s['root'] . ";\n    index index.php index.html index.htm;\n";
        if ($s['type'] === 'php') {
            $sock = '/run/php/php' . $s['php'] . '-fpm.sock';
            $body = "    location / {\n        try_files \$uri \$uri/ /index.php?\$query_string;\n    }\n"
                  . "    location ~ \\.php\$ {\n"
                  . "        include fastcgi_params;\n"
                  . "        fastcgi_split_path_info ^(.+\\.php)(/.+)\$;\n"
                  . "        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;\n"
                  . "        fastcgi_param PATH_INFO \$fastcgi_path_info;\n"
                  . "        fastcgi_pass unix:" . $sock . ";\n"
                  . "    }\n";
        } else {
            $body = "    location / {\n        try_files \$uri \$uri/ =404;\n    }\n";
        }
    }

    $hdr = "# Managed by BitPanel — edits may be overwritten\n";
    $ssl = !empty($s['ssl']);
    $waf = !empty($s['waf']) ? "    include /etc/nginx/waf/bitpanel-waf.conf;\n" : '';

    if ($ssl && !empty($s['force_https'])) {
        // HTTP: acme + redirect only
        $http = "server {\n    listen 80;\n    listen [::]:80;\n    server_name {$names};\n"
              . $acme
              . "    location / { return 301 https://\$host\$request_uri; }\n}\n";
    } else {
        $http = "server {\n    listen 80;\n    listen [::]:80;\n    server_name {$names};\n"
              . $waf . $rootline . $acme . $body . "}\n";
    }

    $https = '';
    if ($ssl) {
        $dir = SSL_SITES . '/' . $s['id'];
        $https = "server {\n    listen 443 ssl;\n    listen [::]:443 ssl;\n    server_name {$names};\n"
               . "    ssl_certificate {$dir}/fullchain.pem;\n"
               . "    ssl_certificate_key {$dir}/key.pem;\n"
               . "    ssl_protocols TLSv1.2 TLSv1.3;\n"
               . $waf . $rootline . $body . "}\n";
    }

    return $hdr . $http . $https;
}

/* ---- WAF (native nginx pattern filtering — not ModSecurity/OWASP CRS) ---- */


function waf_ensure_snippet(): void
{
    if (!is_dir(WAF_DIR)) { @mkdir(WAF_DIR, 0755, true); }
    if (!is_file(WAF_ZONE)) {
        @file_put_contents(WAF_ZONE, "limit_req_zone \$binary_remote_addr zone=bitpanel_waf:10m rate=20r/s;\n");
    }
    if (is_file(WAF_CONF)) { return; }
    $lines = [
        '# Managed by BitPanel — native nginx pattern filtering.',
        '# Blocks common SQLi/XSS/traversal/scanner patterns and rate-limits requests.',
        '# This is NOT ModSecurity/OWASP CRS — no full HTTP-body inspection.',
        'set $bp_block 0;',
        'if ($query_string ~* "(union.*select|select.*from|insert.*into|drop.*table|information_schema|benchmark' . '\\(' . '|sleep' . '\\(' . ')") { set $bp_block 1; }',
        'if ($query_string ~* "(<script|javascript:|onerror=|onload=|%3Cscript)") { set $bp_block 1; }',
        'if ($request_uri ~* "(\\.\\./|\\.\\.%2f|/etc/passwd|/proc/self)") { set $bp_block 1; }',
        'if ($request_uri ~* "\\.(env|git/config|sql|bak|swp)$") { set $bp_block 1; }',
        'if ($http_user_agent ~* "(sqlmap|nikto|nessus|acunetix|masscan|nmap|w3af)") { set $bp_block 1; }',
        'if ($bp_block = 1) { return 403; }',
        'limit_req zone=bitpanel_waf burst=40 nodelay;',
    ];
    @file_put_contents(WAF_CONF, implode("\n", $lines) . "\n");
}

function waf_status(): array
{
    waf_ensure_snippet();
    $enabled = 0;
    foreach (glob(SITES_DIR . '/*.json') ?: [] as $f) {
        $s = json_decode((string)@file_get_contents($f), true);
        if (is_array($s) && !empty($s['waf'])) { $enabled++; }
    }
    return ['installed' => is_file(WAF_CONF), 'sites_protected' => $enabled];
}

function site_waf_toggle(string $id, bool $enable): array
{
    $s = site_load($id);
    if ($s === null) { return ['ok' => false, 'error' => 'site not found']; }
    if ($enable) { waf_ensure_snippet(); }
    $s['waf'] = $enable;
    if (@file_put_contents(ng_conf($id), render_conf($s)) === false) {
        return ['ok' => false, 'error' => 'could not rewrite nginx config'];
    }
    $r = nginx_test_reload();
    if (!$r['ok']) { return $r; }
    site_save($s);
    return ['ok' => true, 'data' => $enable ? 'WAF enabled' : 'WAF disabled'];
}
{
    [$rc, $out] = shell_out('nginx -t', 30);
    if ($rc !== 0) { return ['ok' => false, 'error' => "nginx config test failed:\n" . $out]; }
    [$rc2, $out2] = shell_out('systemctl reload nginx', 30);
    return $rc2 === 0
        ? ['ok' => true]
        : ['ok' => false, 'error' => "reload failed: " . $out2];
}

function site_create(array $a): array
{
    sites_ensure();
    $domains = array_values(array_unique(array_filter(array_map(
        static fn($d) => strtolower(trim((string)$d)),
        (array)($a['domains'] ?? [])
    ))));
    if (!$domains) { return ['ok' => false, 'error' => 'at least one domain required']; }
    foreach ($domains as $d) {
        if (!preg_match(DOMAIN_RE, $d)) { return ['ok' => false, 'error' => "invalid domain: {$d}"]; }
    }
    $type = (string)($a['type'] ?? '');
    if (!in_array($type, ['php', 'static', 'proxy'], true)) {
        return ['ok' => false, 'error' => 'type must be php, static, or proxy'];
    }

    $id = strtolower((string)($a['id'] ?? $domains[0]));
    $id = preg_replace('/[^a-z0-9.-]/', '-', $id);
    $id = trim((string)$id, '-.');
    if (!preg_match(ID_RE, $id)) { return ['ok' => false, 'error' => 'could not derive a valid site id']; }
    if (site_load($id) !== null || file_exists(ng_conf($id))) {
        return ['ok' => false, 'error' => "site '{$id}' already exists"];
    }

    $s = ['id' => $id, 'domains' => $domains, 'type' => $type,
          'ssl' => false, 'force_https' => false, 'created' => time()];

    if ($type === 'proxy') {
        $up = (string)($a['upstream'] ?? '');
        if (!preg_match(UPSTREAM_RE, $up)) {
            return ['ok' => false, 'error' => 'upstream must look like http://127.0.0.1:3000'];
        }
        $s['upstream'] = $up;
    } else {
        $root = (string)($a['root'] ?? '');
        if ($root === '') { $root = '/var/www/' . $id; }
        $rc = canon($root, false);
        if ($rc === null) { return ['ok' => false, 'error' => 'invalid document root']; }
        if ($err = is_protected($rc, true)) { return ['ok' => false, 'error' => "root: {$err}"]; }
        if (!is_dir($rc)) {
            if (!@mkdir($rc, 0755, true)) { return ['ok' => false, 'error' => 'could not create document root']; }
            @shell_exec('chown -R www-data:www-data ' . escapeshellarg($rc));
            @file_put_contents($rc . '/index.html',
                "<!doctype html><title>{$id}</title><h1>{$id}</h1><p>Served by BitPanel.</p>\n");
        }
        $s['root'] = $rc;
        if ($type === 'php') {
            $ver = (string)($a['php'] ?? '');
            $ok = false;
            foreach (php_versions() as $pv) { if ($pv['version'] === $ver) { $ok = true; } }
            if (!$ok) { return ['ok' => false, 'error' => 'selected PHP version is not installed']; }
            $s['php'] = $ver;
        }
    }

    if (@file_put_contents(ng_conf($id), render_conf($s)) === false) {
        return ['ok' => false, 'error' => 'could not write nginx config'];
    }
    @symlink(ng_conf($id), ng_link($id));

    $r = nginx_test_reload();
    if (!$r['ok']) {
        @unlink(ng_link($id));
        @unlink(ng_conf($id));
        return $r;
    }
    site_save($s);
    return ['ok' => true, 'data' => $s];
}

function site_toggle(string $id, bool $enable): array
{
    $s = site_load($id);
    if ($s === null) { return ['ok' => false, 'error' => 'site not found']; }
    if ($enable) { @symlink(ng_conf($id), ng_link($id)); }
    else { @unlink(ng_link($id)); }
    $r = nginx_test_reload();
    if (!$r['ok']) { return $r; }
    return ['ok' => true, 'data' => $enable ? 'enabled' : 'disabled'];
}

function site_delete(string $id): array
{
    $s = site_load($id);
    if ($s === null) { return ['ok' => false, 'error' => 'site not found']; }
    @unlink(ng_link($id));
    @unlink(ng_conf($id));
    @unlink(site_path($id));
    $dir = SSL_SITES . '/' . $id;
    if (is_dir($dir)) { @shell_exec('rm -rf --one-file-system -- ' . escapeshellarg($dir)); }
    nginx_test_reload();
    // web root is user data — intentionally left in place
    return ['ok' => true, 'data' => 'deleted (document root left untouched)'];
}

function acme_ensure(): array
{
    if (is_file(ACME_SH)) { return ['ok' => true]; }
    [$rc, $out] = shell_out(
        'curl -fsSL https://get.acme.sh | sh -s -- --home /root/.acme.sh', 180
    );
    if (!is_file(ACME_SH)) {
        return ['ok' => false, 'error' => "acme.sh install failed (needs outbound network):\n" . $out];
    }
    shell_out(ACME_SH . ' --set-default-ca --server letsencrypt', 30);
    return ['ok' => true];
}

function ssl_issue(string $id, bool $forceHttps): array
{
    $s = site_load($id);
    if ($s === null) { return ['ok' => false, 'error' => 'site not found']; }
    sites_ensure();

    $e = acme_ensure();
    if (!$e['ok']) { return $e; }

    $dflag = '';
    foreach ($s['domains'] as $d) { $dflag .= ' -d ' . escapeshellarg($d); }

    [$rc, $out] = shell_out(
        ACME_SH . ' --issue' . $dflag
        . ' --webroot ' . escapeshellarg(ACME_WEBROOT)
        . ' --server letsencrypt --keylength 2048', 300
    );
    // rc==2 means "already issued / skipped" in acme.sh; treat as continue
    if ($rc !== 0 && $rc !== 2) {
        return ['ok' => false, 'error' => "certificate issuance failed:\n" . $out];
    }

    $dir = SSL_SITES . '/' . $id;
    if (!is_dir($dir)) { @mkdir($dir, 0750, true); }
    [$rc2, $out2] = shell_out(
        ACME_SH . ' --install-cert' . $dflag
        . ' --key-file ' . escapeshellarg($dir . '/key.pem')
        . ' --fullchain-file ' . escapeshellarg($dir . '/fullchain.pem')
        . ' --reloadcmd ' . escapeshellarg('systemctl reload nginx'), 120
    );
    if ($rc2 !== 0 || !is_file($dir . '/fullchain.pem')) {
        return ['ok' => false, 'error' => "cert install failed:\n" . $out2];
    }
    @chmod($dir . '/key.pem', 0600);

    $s['ssl'] = true;
    $s['force_https'] = $forceHttps;
    if (@file_put_contents(ng_conf($id), render_conf($s)) === false) {
        return ['ok' => false, 'error' => 'cert issued but nginx rewrite failed'];
    }
    if (!is_link(ng_link($id)) && !is_file(ng_link($id))) { @symlink(ng_conf($id), ng_link($id)); }

    $r = nginx_test_reload();
    if (!$r['ok']) { return $r; }
    site_save($s);
    return ['ok' => true, 'data' => ['expiry' => cert_expiry($id)]];
}

function ssl_status(string $id): array
{
    $s = site_load($id);
    if ($s === null) { return ['error' => 'not found']; }
    return ['ssl' => !empty($s['ssl']), 'force_https' => !empty($s['force_https']),
            'expiry' => cert_expiry($id)];
}

/* =================== databases =========================== */


function mysql_prefix(): string
{
    if (is_file('/etc/mysql/debian.cnf')) {
        return 'mysql --defaults-file=/etc/mysql/debian.cnf';
    }
    return 'mysql';
}

function mysql_q(string $sql): array
{
    $cmd = mysql_prefix() . ' --batch --skip-column-names -e ' . escapeshellarg($sql);
    return shell_out($cmd, 30);
}

function mysql_esc(string $s): string
{
    return str_replace(['\\', "'"], ['\\\\', "\\'"], $s);
}

function db_engine_unit(): ?string
{
    foreach (['mariadb', 'mysql'] as $u) {
        $st = unit_state($u);
        if ($st['load'] !== 'not-found') { return $u; }
    }
    return null;
}

function db_status(): array
{
    $unit = db_engine_unit();
    if ($unit === null) {
        return ['installed' => false, 'engine' => null, 'active' => false];
    }
    $st  = unit_state($unit);
    $ver = trim((string)@shell_exec('mysql --version 2>/dev/null'));
    $engine = stripos($ver, 'mariadb') !== false ? 'MariaDB' : 'MySQL';
    return ['installed' => true, 'engine' => $engine, 'unit' => $unit,
            'active' => $st['active'] === 'active'];
}

function db_list(): array
{
    if (db_engine_unit() === null) { return ['ok' => false, 'error' => 'no database server installed']; }
    [$rc, $out] = mysql_q(
        "SELECT table_schema, ROUND(SUM(data_length+index_length)), COUNT(*) "
        . "FROM information_schema.tables GROUP BY table_schema"
    );
    $sizes = [];
    foreach (explode("\n", trim($out)) as $line) {
        if ($line === '') { continue; }
        $c = explode("\t", $line);
        if (count($c) >= 3) { $sizes[$c[0]] = ['size' => (float)$c[1], 'tables' => (int)$c[2]]; }
    }
    [$rc2, $out2] = mysql_q("SHOW DATABASES");
    if ($rc2 !== 0) { return ['ok' => false, 'error' => "cannot connect to database server:\n" . $out2]; }
    $res = [];
    foreach (explode("\n", trim($out2)) as $name) {
        $name = trim($name);
        if ($name === '' || in_array($name, SYS_DBS, true)) { continue; }
        $res[] = ['name' => $name,
                  'size' => $sizes[$name]['size'] ?? 0.0,
                  'tables' => $sizes[$name]['tables'] ?? 0];
    }
    usort($res, static fn($a, $b) => strcmp($a['name'], $b['name']));
    return ['ok' => true, 'data' => $res];
}

function db_create(string $name, string $charset): array
{
    if (!preg_match(IDENT_RE, $name)) { return ['ok' => false, 'error' => 'invalid database name (letters, digits, underscore)']; }
    $charset = strtolower($charset);
    $map = ['utf8mb4' => 'utf8mb4_unicode_ci', 'utf8' => 'utf8_general_ci', 'latin1' => 'latin1_swedish_ci'];
    if (!isset($map[$charset])) { $charset = 'utf8mb4'; }
    [$rc, $out] = mysql_q("CREATE DATABASE `{$name}` CHARACTER SET {$charset} COLLATE {$map[$charset]}");
    return $rc === 0 ? ['ok' => true, 'data' => 'created'] : ['ok' => false, 'error' => trim($out)];
}

function db_drop(string $name): array
{
    if (!preg_match(IDENT_RE, $name) || in_array($name, SYS_DBS, true)) {
        return ['ok' => false, 'error' => 'invalid or protected database'];
    }
    [$rc, $out] = mysql_q("DROP DATABASE `{$name}`");
    return $rc === 0 ? ['ok' => true, 'data' => 'dropped'] : ['ok' => false, 'error' => trim($out)];
}

function db_users(): array
{
    if (db_engine_unit() === null) { return ['ok' => false, 'error' => 'no database server installed']; }
    [$rc, $out] = mysql_q("SELECT User, Host FROM mysql.user");
    if ($rc !== 0) { return ['ok' => false, 'error' => trim($out)]; }
    // db-level grants map
    [$rc2, $g] = mysql_q("SELECT User, Host, Db FROM mysql.db");
    $grants = [];
    foreach (explode("\n", trim($g)) as $line) {
        if ($line === '') { continue; }
        $c = explode("\t", $line);
        if (count($c) >= 3) { $grants[$c[0] . '@' . $c[1]][] = $c[2]; }
    }
    $res = [];
    foreach (explode("\n", trim($out)) as $line) {
        if ($line === '') { continue; }
        $c = explode("\t", $line);
        if (count($c) < 2) { continue; }
        [$u, $h] = $c;
        if (in_array($u, SYS_USERS, true)) { continue; }
        $res[] = ['user' => $u, 'host' => $h, 'databases' => $grants[$u . '@' . $h] ?? []];
    }
    usort($res, static fn($a, $b) => strcmp($a['user'], $b['user']));
    return ['ok' => true, 'data' => $res];
}

function db_user_create(array $a): array
{
    $user = (string)($a['user'] ?? '');
    $host = (string)($a['host'] ?? 'localhost');
    $pass = (string)($a['password'] ?? '');
    $db   = (string)($a['database'] ?? '');
    if (!preg_match(IDENT_RE, $user)) { return ['ok' => false, 'error' => 'invalid username']; }
    if (!preg_match(HOST_RE, $host)) { return ['ok' => false, 'error' => 'invalid host']; }
    if ($pass === '' || strlen($pass) > 128 || preg_match('/[\r\n]/', $pass)) {
        return ['ok' => false, 'error' => 'password required (max 128 chars, no newlines)'];
    }
    $p = mysql_esc($pass);
    [$rc, $out] = mysql_q("CREATE USER '{$user}'@'{$host}' IDENTIFIED BY '{$p}'");
    if ($rc !== 0) { return ['ok' => false, 'error' => trim($out)]; }
    if ($db !== '') {
        if (!preg_match(IDENT_RE, $db)) { return ['ok' => false, 'error' => 'user created, but grant database name invalid']; }
        [$rc2, $out2] = mysql_q("GRANT ALL PRIVILEGES ON `{$db}`.* TO '{$user}'@'{$host}'; FLUSH PRIVILEGES");
        if ($rc2 !== 0) { return ['ok' => false, 'error' => "user created, grant failed: " . trim($out2)]; }
    }
    return ['ok' => true, 'data' => 'user created'];
}

function db_user_drop(string $user, string $host): array
{
    if (!preg_match(IDENT_RE, $user) || in_array($user, SYS_USERS, true)) { return ['ok' => false, 'error' => 'invalid or protected user']; }
    if (!preg_match(HOST_RE, $host)) { return ['ok' => false, 'error' => 'invalid host']; }
    [$rc, $out] = mysql_q("DROP USER '{$user}'@'{$host}'");
    return $rc === 0 ? ['ok' => true, 'data' => 'dropped'] : ['ok' => false, 'error' => trim($out)];
}

function db_user_password(string $user, string $host, string $pass): array
{
    if (!preg_match(IDENT_RE, $user) || in_array($user, SYS_USERS, true)) { return ['ok' => false, 'error' => 'invalid or protected user']; }
    if (!preg_match(HOST_RE, $host)) { return ['ok' => false, 'error' => 'invalid host']; }
    if ($pass === '' || strlen($pass) > 128 || preg_match('/[\r\n]/', $pass)) {
        return ['ok' => false, 'error' => 'password required (max 128 chars)'];
    }
    $p = mysql_esc($pass);
    [$rc, $out] = mysql_q("ALTER USER '{$user}'@'{$host}' IDENTIFIED BY '{$p}'; FLUSH PRIVILEGES");
    return $rc === 0 ? ['ok' => true, 'data' => 'password changed'] : ['ok' => false, 'error' => trim($out)];
}

/* ====================== cron ============================= */


function cron_users(): array
{
    $res = [];
    foreach (explode("\n", (string)@file_get_contents('/etc/passwd')) as $line) {
        $c = explode(':', $line);
        if (count($c) < 7) { continue; }
        $name = $c[0];
        $uid  = (int)$c[2];
        $shell = $c[6];
        if (!preg_match(CRON_USER_RE, $name)) { continue; }
        $login = strpos($shell, 'nologin') === false && strpos($shell, 'false') === false;
        if ($uid === 0 || ($uid >= 1000 && $login) || $name === 'www-data') {
            $res[] = $name;
        }
    }
    $res = array_values(array_unique($res));
    sort($res);
    return $res;
}

function crontab_read(string $user): array
{
    $out = (string)@shell_exec('crontab -u ' . escapeshellarg($user) . ' -l 2>/dev/null');
    if ($out === '') { return []; }
    return explode("\n", rtrim($out, "\n"));
}

function crontab_write(string $user, array $lines): bool
{
    $tmp = tempnam(sys_get_temp_dir(), 'bpcron');
    if ($tmp === false) { return false; }
    @file_put_contents($tmp, implode("\n", $lines) . "\n");
    [$rc] = shell_out('crontab -u ' . escapeshellarg($user) . ' ' . escapeshellarg($tmp), 15);
    @unlink($tmp);
    return $rc === 0;
}

function cron_parse_line(string $line): ?array
{
    $enabled = true;
    $work = $line;
    if (strpos($work, CRON_OFF) === 0) {
        $enabled = false;
        $work = substr($work, strlen(CRON_OFF));
    } elseif (isset($work[0]) && $work[0] === '#') {
        return null; // ordinary comment
    }
    $work = trim($work);
    if ($work === '') { return null; }

    if (preg_match(CRON_SPECIAL, strtok($work, " \t"))) {
        $parts = preg_split('/\s+/', $work, 2);
        return ['enabled' => $enabled, 'schedule' => $parts[0], 'command' => $parts[1] ?? ''];
    }
    $parts = preg_split('/\s+/', $work, 6);
    if (count($parts) < 6) { return null; }
    $sched = implode(' ', array_slice($parts, 0, 5));
    return ['enabled' => $enabled, 'schedule' => $sched, 'command' => $parts[5]];
}

function cron_list(string $user): array
{
    if (!preg_match(CRON_USER_RE, $user) || !@posix_getpwnam($user)) {
        return ['ok' => false, 'error' => 'unknown system user'];
    }
    $lines = crontab_read($user);
    $jobs = [];
    foreach ($lines as $i => $line) {
        $p = cron_parse_line($line);
        if ($p !== null) { $jobs[] = ['index' => $i] + $p; }
    }
    return ['ok' => true, 'data' => ['user' => $user, 'jobs' => $jobs]];
}

function cron_validate_schedule(string $s): bool
{
    $s = trim($s);
    if (preg_match(CRON_SPECIAL, $s)) { return true; }
    $f = preg_split('/\s+/', $s);
    if (count($f) !== 5) { return false; }
    foreach ($f as $field) {
        if (!preg_match('#^[0-9*/,\-A-Za-z]+$#', $field)) { return false; }
    }
    return true;
}

function cron_add(string $user, string $schedule, string $command): array
{
    if (!preg_match(CRON_USER_RE, $user) || !@posix_getpwnam($user)) { return ['ok' => false, 'error' => 'unknown system user']; }
    $schedule = trim($schedule);
    $command  = trim($command);
    if (!cron_validate_schedule($schedule)) { return ['ok' => false, 'error' => 'invalid schedule (use 5 fields or @daily etc.)']; }
    if ($command === '' || preg_match('/[\r\n]/', $command)) { return ['ok' => false, 'error' => 'command required, single line']; }
    $lines = crontab_read($user);
    $lines[] = $schedule . ' ' . $command;
    return crontab_write($user, $lines)
        ? ['ok' => true, 'data' => 'added']
        : ['ok' => false, 'error' => 'could not write crontab'];
}

function cron_delete(string $user, int $index): array
{
    if (!preg_match(CRON_USER_RE, $user) || !@posix_getpwnam($user)) { return ['ok' => false, 'error' => 'unknown system user']; }
    $lines = crontab_read($user);
    if ($index < 0 || $index >= count($lines) || cron_parse_line($lines[$index]) === null) {
        return ['ok' => false, 'error' => 'job not found (list may be stale — refresh)'];
    }
    array_splice($lines, $index, 1);
    return crontab_write($user, $lines)
        ? ['ok' => true, 'data' => 'deleted']
        : ['ok' => false, 'error' => 'could not write crontab'];
}

function cron_toggle(string $user, int $index): array
{
    if (!preg_match(CRON_USER_RE, $user) || !@posix_getpwnam($user)) { return ['ok' => false, 'error' => 'unknown system user']; }
    $lines = crontab_read($user);
    if ($index < 0 || $index >= count($lines) || cron_parse_line($lines[$index]) === null) {
        return ['ok' => false, 'error' => 'job not found (refresh)'];
    }
    $line = $lines[$index];
    if (strpos($line, CRON_OFF) === 0) {
        $lines[$index] = substr($line, strlen(CRON_OFF));
    } else {
        $lines[$index] = CRON_OFF . $line;
    }
    return crontab_write($user, $lines)
        ? ['ok' => true, 'data' => 'toggled']
        : ['ok' => false, 'error' => 'could not write crontab'];
}

/* =============== firewall (ufw) ========================== */


function ufw_installed(): bool
{
    return trim((string)@shell_exec('command -v ufw 2>/dev/null')) !== '';
}

function valid_ip_or_cidr(string $s): bool
{
    if (filter_var($s, FILTER_VALIDATE_IP) !== false) { return true; }
    if (strpos($s, '/') !== false) {
        [$ip, $m] = explode('/', $s, 2);
        return filter_var($ip, FILTER_VALIDATE_IP) !== false && ctype_digit($m) && (int)$m <= 128;
    }
    return false;
}

function fw_status(): array
{
    if (!ufw_installed()) {
        return ['installed' => false, 'active' => false];
    }
    $out = (string)@shell_exec('ufw status verbose 2>/dev/null');
    $active = preg_match('/Status:\s*active/i', $out) === 1;
    $din = $dout = 'unknown';
    if (preg_match('/Default:\s*(\w+)\s*\(incoming\),\s*(\w+)\s*\(outgoing\)/i', $out, $m)) {
        $din = $m[1]; $dout = $m[2];
    }
    return ['installed' => true, 'active' => $active,
            'default_in' => $din, 'default_out' => $dout];
}

function fw_rules(): array
{
    if (!ufw_installed()) { return ['ok' => false, 'error' => 'ufw not installed']; }
    $out = (string)@shell_exec('ufw status numbered 2>/dev/null');
    $rules = [];
    foreach (explode("\n", $out) as $line) {
        if (preg_match('/^\[\s*(\d+)\]\s+(.+?)\s{2,}(ALLOW|DENY|REJECT|LIMIT)(?:\s+(IN|OUT))?\s+(.+?)\s*$/', $line, $m)) {
            $rules[] = [
                'num'    => (int)$m[1],
                'to'     => trim($m[2]),
                'action' => trim($m[3] . ' ' . ($m[4] ?? '')),
                'from'   => trim($m[5]),
            ];
        }
    }
    return ['ok' => true, 'data' => $rules];
}

function fw_add(array $a): array
{
    if (!ufw_installed()) { return ['ok' => false, 'error' => 'ufw not installed']; }
    $action = (string)($a['action'] ?? '');
    if (!in_array($action, ['allow', 'deny', 'reject', 'limit'], true)) {
        return ['ok' => false, 'error' => 'action must be allow, deny, reject or limit'];
    }
    $proto = strtolower((string)($a['proto'] ?? 'tcp'));
    if (!in_array($proto, ['tcp', 'udp', 'any'], true)) {
        return ['ok' => false, 'error' => 'protocol must be tcp, udp or any'];
    }
    $port = (string)($a['port'] ?? '');
    if (!ctype_digit($port) || (int)$port < 1 || (int)$port > 65535) {
        return ['ok' => false, 'error' => 'port must be 1–65535'];
    }
    $src = trim((string)($a['source'] ?? ''));

    if ($src !== '') {
        if (!valid_ip_or_cidr($src)) { return ['ok' => false, 'error' => 'source must be an IP or CIDR']; }
        $cmd = 'ufw ' . escapeshellarg($action) . ' from ' . escapeshellarg($src)
             . ' to any port ' . escapeshellarg($port);
        if ($proto !== 'any') { $cmd .= ' proto ' . escapeshellarg($proto); }
    } else {
        $spec = $proto === 'any' ? $port : $port . '/' . $proto;
        $cmd = 'ufw ' . escapeshellarg($action) . ' ' . escapeshellarg($spec);
    }
    [$rc, $out] = shell_out($cmd, 30);
    return $rc === 0 ? ['ok' => true, 'data' => trim($out)] : ['ok' => false, 'error' => trim($out)];
}

function fw_delete(int $num): array
{
    if (!ufw_installed()) { return ['ok' => false, 'error' => 'ufw not installed']; }
    if ($num < 1 || $num > 9999) { return ['ok' => false, 'error' => 'invalid rule number']; }
    [$rc, $out] = shell_out('ufw --force delete ' . (int)$num, 30);
    return $rc === 0 ? ['ok' => true, 'data' => trim($out)] : ['ok' => false, 'error' => trim($out)];
}

function fw_toggle(bool $enable): array
{
    if (!$enable) {
        if (!ufw_installed()) { return ['ok' => true, 'data' => 'already off']; }
        [$rc, $out] = shell_out('ufw --force disable', 30);
        return $rc === 0 ? ['ok' => true, 'data' => 'disabled'] : ['ok' => false, 'error' => trim($out)];
    }

    // enabling — install if needed, then guard SSH + panel port against lockout
    if (!ufw_installed()) {
        shell_out('DEBIAN_FRONTEND=noninteractive apt-get install -y ufw', 180);
        if (!ufw_installed()) { return ['ok' => false, 'error' => 'could not install ufw']; }
    }
    // detect sshd port
    $ssh = '22';
    if (preg_match('/^\s*Port\s+(\d+)/mi', (string)@file_get_contents('/etc/ssh/sshd_config'), $m)) {
        $ssh = $m[1];
    }
    // detect panel port from managed nginx vhost
    $panel = '8899';
    if (preg_match('/listen\s+(\d+)\s+ssl/', (string)@file_get_contents('/etc/nginx/sites-available/bitpanel.conf'), $m2)) {
        $panel = $m2[1];
    }
    shell_out('ufw allow ' . escapeshellarg($ssh . '/tcp'), 20);
    shell_out('ufw allow ' . escapeshellarg($panel . '/tcp'), 20);
    [$rc, $out] = shell_out('ufw --force enable', 30);
    return $rc === 0
        ? ['ok' => true, 'data' => "enabled (kept SSH {$ssh} and panel {$panel} open)"]
        : ['ok' => false, 'error' => trim($out)];
}

/* =============== fail2ban ================================ */

function f2b_installed(): bool
{
    return trim((string)@shell_exec('command -v fail2ban-client 2>/dev/null')) !== '';
}

function f2b_status(): array
{
    if (!f2b_installed()) { return ['installed' => false, 'active' => false, 'jails' => []]; }
    $st = unit_state('fail2ban');
    $active = $st['active'] === 'active';
    $jails = [];
    if ($active) {
        $out = (string)@shell_exec('fail2ban-client status 2>/dev/null');
        if (preg_match('/Jail list:\s*(.+)/i', $out, $m)) {
            foreach (preg_split('/[,\s]+/', trim($m[1])) as $j) {
                if ($j !== '') { $jails[] = $j; }
            }
        }
    }
    return ['installed' => true, 'active' => $active, 'jails' => $jails];
}

function f2b_jail(string $jail): array
{
    if (!f2b_installed()) { return ['ok' => false, 'error' => 'fail2ban not installed']; }
    if (!preg_match(JAIL_RE, $jail)) { return ['ok' => false, 'error' => 'invalid jail name']; }
    $out = (string)@shell_exec('fail2ban-client status ' . escapeshellarg($jail) . ' 2>/dev/null');
    if (trim($out) === '') { return ['ok' => false, 'error' => 'jail not found']; }
    $failed = 0; $banned = 0; $ips = [];
    if (preg_match('/Currently failed:\s*(\d+)/i', $out, $m)) { $failed = (int)$m[1]; }
    if (preg_match('/Currently banned:\s*(\d+)/i', $out, $m)) { $banned = (int)$m[1]; }
    if (preg_match('/Banned IP list:\s*(.*)/i', $out, $m)) {
        foreach (preg_split('/\s+/', trim($m[1])) as $ip) {
            if ($ip !== '' && filter_var($ip, FILTER_VALIDATE_IP)) { $ips[] = $ip; }
        }
    }
    return ['ok' => true, 'data' => ['jail' => $jail, 'failed' => $failed,
            'banned' => $banned, 'ips' => $ips]];
}

function f2b_action(string $action, string $jail, string $ip): array
{
    if (!f2b_installed()) { return ['ok' => false, 'error' => 'fail2ban not installed']; }
    if (!preg_match(JAIL_RE, $jail)) { return ['ok' => false, 'error' => 'invalid jail name']; }
    if (filter_var($ip, FILTER_VALIDATE_IP) === false) { return ['ok' => false, 'error' => 'invalid IP address']; }
    if (!in_array($action, ['banip', 'unbanip'], true)) { return ['ok' => false, 'error' => 'bad action']; }
    [$rc, $out] = shell_out('fail2ban-client set ' . escapeshellarg($jail) . ' '
        . $action . ' ' . escapeshellarg($ip), 30);
    return $rc === 0 ? ['ok' => true, 'data' => trim($out)] : ['ok' => false, 'error' => trim($out)];
}

/* ============= software store =========================== */

function soft_items(): array
{
    return [
        ['key' => 'nginx',      'label' => 'Nginx',        'pkg' => 'nginx',          'unit' => 'nginx',          'group' => 'Web'],
        ['key' => 'apache2',    'label' => 'Apache',       'pkg' => 'apache2',        'unit' => 'apache2',        'group' => 'Web'],
        ['key' => 'mysql',      'label' => 'MySQL 8',      'pkg' => 'mysql-server',   'unit' => 'mysql',          'group' => 'Database'],
        ['key' => 'mariadb',    'label' => 'MariaDB',      'pkg' => 'mariadb-server', 'unit' => 'mariadb',        'group' => 'Database'],
        ['key' => 'postgresql', 'label' => 'PostgreSQL',   'pkg' => 'postgresql',     'unit' => 'postgresql',     'group' => 'Database'],
        ['key' => 'redis',      'label' => 'Redis',        'pkg' => 'redis-server',   'unit' => 'redis-server',   'group' => 'Cache'],
        ['key' => 'memcached',  'label' => 'Memcached',    'pkg' => 'memcached',      'unit' => 'memcached',      'group' => 'Cache'],
        ['key' => 'php83',      'label' => 'PHP 8.3 FPM',  'pkg' => 'php8.3-fpm',     'unit' => 'php8.3-fpm',     'group' => 'PHP'],
        ['key' => 'php82',      'label' => 'PHP 8.2 FPM',  'pkg' => 'php8.2-fpm',     'unit' => 'php8.2-fpm',     'group' => 'PHP'],
        ['key' => 'php81',      'label' => 'PHP 8.1 FPM',  'pkg' => 'php8.1-fpm',     'unit' => 'php8.1-fpm',     'group' => 'PHP'],
        ['key' => 'nodejs',     'label' => 'Node.js 22',   'pkg' => 'nodejs',         'unit' => null,             'group' => 'Runtime'],
        ['key' => 'docker',     'label' => 'Docker',       'pkg' => 'docker.io',      'unit' => 'docker',         'group' => 'Runtime'],
        ['key' => 'fail2ban',   'label' => 'Fail2ban',     'pkg' => 'fail2ban',       'unit' => 'fail2ban',       'group' => 'Security'],
        ['key' => 'ufw',        'label' => 'UFW firewall', 'pkg' => 'ufw',            'unit' => null,             'group' => 'Security'],
        ['key' => 'vsftpd',     'label' => 'vsftpd (FTP)', 'pkg' => 'vsftpd',         'unit' => 'vsftpd',         'group' => 'Other'],
    ];
}

function pkg_installed(string $pkg): bool
{
    $out = (string)@shell_exec('dpkg-query -W -f=\'${Status}\' ' . escapeshellarg($pkg) . ' 2>/dev/null');
    return strpos($out, 'install ok installed') !== false;
}

function soft_catalog(): array
{
    $res = [];
    foreach (soft_items() as $it) {
        $installed = pkg_installed($it['pkg']);
        $active = false;
        if ($installed && $it['unit'] !== null) {
            $active = unit_state($it['unit'])['active'] === 'active';
        }
        $it['installed'] = $installed;
        $it['active'] = $active;
        $it['locked'] = in_array($it['key'], ['php83', 'nginx'], true); // panel depends on these
        $res[] = $it;
    }
    return $res;
}

function soft_install(string $key): array
{
    $item = null;
    foreach (soft_items() as $it) { if ($it['key'] === $key) { $item = $it; } }
    if ($item === null) { return ['ok' => false, 'error' => 'unknown component']; }

    if ($key === 'mysql' && pkg_installed('mariadb-server')) { return ['ok' => false, 'error' => 'MariaDB is installed — remove it first']; }
    if ($key === 'mariadb' && pkg_installed('mysql-server')) { return ['ok' => false, 'error' => 'MySQL is installed — remove it first']; }

    // build a constant command per validated key (no user input in command)
    $env = 'DEBIAN_FRONTEND=noninteractive ';
    if ($key === 'php81' || $key === 'php82') {
        $ver = $key === 'php81' ? '8.1' : '8.2';
        $cmd = $env . 'apt-get install -y software-properties-common && add-apt-repository -y ppa:ondrej/php && apt-get update -qq && '
             . $env . "apt-get install -y php{$ver}-fpm php{$ver}-mysql php{$ver}-mbstring php{$ver}-curl php{$ver}-xml php{$ver}-gd";
    } elseif ($key === 'php83') {
        $cmd = $env . 'apt-get install -y php8.3-fpm php8.3-mysql php8.3-mbstring php8.3-curl php8.3-xml php8.3-gd';
    } elseif ($key === 'nodejs') {
        $cmd = 'curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && ' . $env . 'apt-get install -y nodejs';
    } else {
        $cmd = $env . 'apt-get install -y ' . escapeshellarg($item['pkg']);
    }

    [$rc, $out] = shell_out($cmd, 600);
    if ($rc !== 0) { return ['ok' => false, 'error' => "install failed:\n" . $out]; }
    if ($item['unit'] !== null) {
        shell_out('systemctl enable --now ' . escapeshellarg($item['unit']), 30);
    }
    return ['ok' => true, 'data' => $item['label'] . ' installed'];
}

function soft_uninstall(string $key): array
{
    if (in_array($key, ['php83', 'nginx'], true)) {
        return ['ok' => false, 'error' => 'this component is required by the panel'];
    }
    $item = null;
    foreach (soft_items() as $it) { if ($it['key'] === $key) { $item = $it; } }
    if ($item === null) { return ['ok' => false, 'error' => 'unknown component']; }
    [$rc, $out] = shell_out('DEBIAN_FRONTEND=noninteractive apt-get purge -y ' . escapeshellarg($item['pkg'])
        . ' && DEBIAN_FRONTEND=noninteractive apt-get autoremove -y', 300);
    return $rc === 0 ? ['ok' => true, 'data' => $item['label'] . ' removed'] : ['ok' => false, 'error' => trim($out)];
}

/* =================== logs =============================== */

function log_catalog(): array
{
    return [
        'nginx-error'   => '/var/log/nginx/error.log',
        'nginx-access'  => '/var/log/nginx/access.log',
        'panel-error'   => '/var/log/nginx/bitpanel.error.log',
        'panel-access'  => '/var/log/nginx/bitpanel.access.log',
        'panel-php'     => '/opt/bitpanel/logs/php.log',
        'php83-fpm'     => '/var/log/php8.3-fpm.log',
        'mysql-error'   => '/var/log/mysql/error.log',
        'fail2ban'      => '/var/log/fail2ban.log',
        'auth'          => '/var/log/auth.log',
        'syslog'        => '/var/log/syslog',
    ];
}

function log_list(): array
{
    $res = [];
    foreach (log_catalog() as $key => $path) {
        if (is_file($path)) {
            $res[] = ['key' => $key, 'path' => $path, 'size' => (float)@filesize($path)];
        }
    }
    return $res;
}

function log_tail(string $path, int $lines): array
{
    $allow = array_values(log_catalog());
    if (!in_array($path, $allow, true)) { return ['ok' => false, 'error' => 'log not in allowlist']; }
    if (!is_file($path)) { return ['ok' => false, 'error' => 'log file not found']; }
    $lines = max(10, min(2000, $lines));
    [$rc, $out] = shell_out('tail -n ' . (int)$lines . ' ' . escapeshellarg($path), 30);
    return ['ok' => true, 'data' => ['path' => $path, 'text' => $out]];
}

/* =================== docker ============================= */


function docker_installed(): bool
{
    return trim((string)@shell_exec('command -v docker 2>/dev/null')) !== '';
}

function docker_ps(bool $all): array
{
    if (!docker_installed()) { return ['ok' => false, 'error' => 'docker not installed', 'installed' => false]; }
    $flag = $all ? '-a ' : '';
    [$rc, $out] = shell_out('docker ps ' . $flag . '--format \'{{.ID}}\t{{.Names}}\t{{.Image}}\t{{.State}}\t{{.Status}}\t{{.Ports}}\'', 30);
    if ($rc !== 0) { return ['ok' => false, 'error' => trim($out)]; }
    $res = [];
    foreach (explode("\n", trim($out)) as $line) {
        if ($line === '') { continue; }
        $c = explode("\t", $line);
        if (count($c) < 5) { continue; }
        $res[] = ['id' => $c[0], 'name' => $c[1], 'image' => $c[2],
                  'state' => $c[3], 'status' => $c[4], 'ports' => $c[5] ?? ''];
    }
    return ['ok' => true, 'data' => $res];
}

function docker_images(): array
{
    if (!docker_installed()) { return ['ok' => false, 'error' => 'docker not installed']; }
    [$rc, $out] = shell_out('docker images --format \'{{.Repository}}\t{{.Tag}}\t{{.ID}}\t{{.Size}}\'', 30);
    if ($rc !== 0) { return ['ok' => false, 'error' => trim($out)]; }
    $res = [];
    foreach (explode("\n", trim($out)) as $line) {
        if ($line === '') { continue; }
        $c = explode("\t", $line);
        if (count($c) < 4) { continue; }
        $res[] = ['repo' => $c[0], 'tag' => $c[1], 'id' => $c[2], 'size' => $c[3]];
    }
    return ['ok' => true, 'data' => $res];
}

function docker_action(string $id, string $action): array
{
    if (!docker_installed()) { return ['ok' => false, 'error' => 'docker not installed']; }
    if (!preg_match(DOCKER_ID_RE, $id)) { return ['ok' => false, 'error' => 'invalid container id']; }
    if (!in_array($action, ['start', 'stop', 'restart', 'rm'], true)) { return ['ok' => false, 'error' => 'bad action']; }
    $cmd = $action === 'rm'
        ? 'docker rm -f ' . escapeshellarg($id)
        : 'docker ' . $action . ' ' . escapeshellarg($id);
    [$rc, $out] = shell_out($cmd, 60);
    return $rc === 0 ? ['ok' => true, 'data' => trim($out)] : ['ok' => false, 'error' => trim($out)];
}

function docker_logs(string $id, int $lines): array
{
    if (!docker_installed()) { return ['ok' => false, 'error' => 'docker not installed']; }
    if (!preg_match(DOCKER_ID_RE, $id)) { return ['ok' => false, 'error' => 'invalid container id']; }
    $lines = max(10, min(1000, $lines));
    [$rc, $out] = shell_out('docker logs --tail ' . (int)$lines . ' ' . escapeshellarg($id) . ' 2>&1', 30);
    return ['ok' => true, 'data' => ['text' => $out]];
}

/* =================== backups ============================ */


function backup_ensure(): void
{
    if (!is_dir(BACKUP_DIR)) { @mkdir(BACKUP_DIR, 0750, true); }
}

function backup_list(): array
{
    backup_ensure();
    $res = [];
    foreach (glob(BACKUP_DIR . '/*') ?: [] as $f) {
        if (!is_file($f)) { continue; }
        $name = basename($f);
        $type = 'other';
        if (strpos($name, 'site-') === 0) { $type = 'site'; }
        elseif (strpos($name, 'db-') === 0) { $type = 'database'; }
        elseif (strpos($name, 'path-') === 0) { $type = 'path'; }
        $res[] = ['name' => $name, 'path' => $f, 'type' => $type,
                  'size' => (float)@filesize($f), 'mtime' => (int)@filemtime($f)];
    }
    usort($res, static fn($a, $b) => $b['mtime'] <=> $a['mtime']);
    return $res;
}

function backup_create(array $a): array
{
    backup_ensure();
    $type = (string)($a['type'] ?? '');
    $target = (string)($a['target'] ?? '');
    $ts = date('Ymd-His');

    if ($type === 'site') {
        $s = site_load($target);
        if ($s === null || ($s['type'] ?? '') === 'proxy') { return ['ok' => false, 'error' => 'site not found or has no document root']; }
        $root = $s['root'];
        $dest = BACKUP_DIR . '/site-' . $target . '-' . $ts . '.tar.gz';
        [$rc, $out] = shell_out('tar czf ' . escapeshellarg($dest)
            . ' -C ' . escapeshellarg(dirname($root)) . ' ' . escapeshellarg(basename($root)), 900);
    } elseif ($type === 'path') {
        $c = canon($target, true);
        if ($c === null || $c === '/') { return ['ok' => false, 'error' => 'invalid path']; }
        if ($err = is_protected($c, false)) { return ['ok' => false, 'error' => $err]; }
        $safe = preg_replace('/[^A-Za-z0-9._-]/', '_', trim(basename($c), '/')) ?: 'root';
        $dest = BACKUP_DIR . '/path-' . $safe . '-' . $ts . '.tar.gz';
        [$rc, $out] = shell_out('tar czf ' . escapeshellarg($dest)
            . ' -C ' . escapeshellarg(dirname($c)) . ' ' . escapeshellarg(basename($c)), 900);
    } elseif ($type === 'db') {
        if (!preg_match(IDENT_RE, $target) || db_engine_unit() === null) { return ['ok' => false, 'error' => 'invalid database']; }
        $dest = BACKUP_DIR . '/db-' . $target . '-' . $ts . '.sql.gz';
        $dump = (is_file('/etc/mysql/debian.cnf') ? 'mysqldump --defaults-file=/etc/mysql/debian.cnf' : 'mysqldump')
            . ' ' . escapeshellarg($target) . ' | gzip > ' . escapeshellarg($dest);
        [$rc, $out] = shell_out($dump, 900);
    } else {
        return ['ok' => false, 'error' => 'type must be site, path or db'];
    }

    if ($rc !== 0) { @unlink($dest); return ['ok' => false, 'error' => "backup failed:\n" . $out]; }
    return ['ok' => true, 'data' => ['name' => basename($dest), 'size' => (float)@filesize($dest)]];
}

function backup_delete(string $name): array
{
    if (!preg_match(BACKUP_NAME, $name)) { return ['ok' => false, 'error' => 'invalid name']; }
    $f = realpath(BACKUP_DIR . '/' . $name);
    if ($f === false || strpos($f, BACKUP_DIR . '/') !== 0 || !is_file($f)) { return ['ok' => false, 'error' => 'backup not found']; }
    return @unlink($f) ? ['ok' => true, 'data' => 'deleted'] : ['ok' => false, 'error' => 'delete failed'];
}

/* ---- S3 ---- */

function s3_get(): array
{
    if (!is_file(S3_CONF)) { return ['configured' => false]; }
    $c = json_decode((string)@file_get_contents(S3_CONF), true);
    if (!is_array($c)) { return ['configured' => false]; }
    return [
        'configured' => true,
        'bucket' => $c['bucket'] ?? '',
        'region' => $c['region'] ?? '',
        'prefix' => $c['prefix'] ?? '',
        'access_key' => isset($c['access_key']) ? substr($c['access_key'], 0, 4) . '••••' : '',
    ];
}

function s3_set(array $a): array
{
    $bucket = trim((string)($a['bucket'] ?? ''));
    $region = trim((string)($a['region'] ?? ''));
    $prefix = trim((string)($a['prefix'] ?? ''));
    $ak = trim((string)($a['access_key'] ?? ''));
    $sk = trim((string)($a['secret_key'] ?? ''));
    if (!preg_match(BUCKET_RE, $bucket)) { return ['ok' => false, 'error' => 'invalid bucket name']; }
    if (!preg_match('/^[a-z0-9\-]{1,30}$/', $region)) { return ['ok' => false, 'error' => 'invalid region']; }
    if ($prefix !== '' && !preg_match('#^[A-Za-z0-9._/\-]{1,120}$#', $prefix)) { return ['ok' => false, 'error' => 'invalid prefix']; }
    // keep previous keys if fields left blank
    $prev = is_file(S3_CONF) ? (json_decode((string)@file_get_contents(S3_CONF), true) ?: []) : [];
    if ($ak === '') { $ak = (string)($prev['access_key'] ?? ''); }
    if ($sk === '') { $sk = (string)($prev['secret_key'] ?? ''); }
    if ($ak === '' || $sk === '') { return ['ok' => false, 'error' => 'access key and secret key required']; }
    $conf = ['bucket' => $bucket, 'region' => $region, 'prefix' => $prefix, 'access_key' => $ak, 'secret_key' => $sk];
    @file_put_contents(S3_CONF, json_encode($conf));
    @chmod(S3_CONF, 0600);
    return ['ok' => true, 'data' => s3_get()];
}

function s3_push(string $name): array
{
    if (!preg_match(BACKUP_NAME, $name)) { return ['ok' => false, 'error' => 'invalid name']; }
    $f = realpath(BACKUP_DIR . '/' . $name);
    if ($f === false || strpos($f, BACKUP_DIR . '/') !== 0 || !is_file($f)) { return ['ok' => false, 'error' => 'backup not found']; }
    if (!is_file(S3_CONF)) { return ['ok' => false, 'error' => 'configure S3 first']; }
    $c = json_decode((string)@file_get_contents(S3_CONF), true);
    if (!is_array($c) || empty($c['bucket'])) { return ['ok' => false, 'error' => 'S3 not configured']; }

    if (trim((string)@shell_exec('command -v aws 2>/dev/null')) === '') {
        shell_out('DEBIAN_FRONTEND=noninteractive apt-get install -y awscli', 300);
        if (trim((string)@shell_exec('command -v aws 2>/dev/null')) === '') {
            return ['ok' => false, 'error' => 'awscli not available and could not be installed'];
        }
    }
    $prefix = $c['prefix'] !== '' ? rtrim($c['prefix'], '/') . '/' : '';
    $key = $prefix . $name;
    $env = 'AWS_ACCESS_KEY_ID=' . escapeshellarg($c['access_key'])
         . ' AWS_SECRET_ACCESS_KEY=' . escapeshellarg($c['secret_key'])
         . ' AWS_DEFAULT_REGION=' . escapeshellarg($c['region']) . ' ';
    $cmd = $env . 'aws s3 cp ' . escapeshellarg($f)
         . ' ' . escapeshellarg('s3://' . $c['bucket'] . '/' . $key);
    [$rc, $out] = shell_out($cmd, 600);
    return $rc === 0 ? ['ok' => true, 'data' => 'uploaded to s3://' . $c['bucket'] . '/' . $key]
                     : ['ok' => false, 'error' => "upload failed:\n" . $out];
}

/* =================== FTP (vsftpd) ======================= */


function ftpacct_installed(): bool
{
    return pkg_installed('vsftpd');
}

function ftpacct_status(): array
{
    $inst = ftpacct_installed();
    $active = $inst && unit_state('vsftpd')['active'] === 'active';
    return ['installed' => $inst, 'active' => $active, 'pasv' => '40000-40100'];
}

function ftpacct_setup(): array
{
    if (!ftpacct_installed()) {
        shell_out('DEBIAN_FRONTEND=noninteractive apt-get install -y vsftpd', 300);
        if (!ftpacct_installed()) { return ['ok' => false, 'error' => 'could not install vsftpd']; }
    }
    @shell_exec('getent group ' . escapeshellarg(FTP_GROUP) . ' >/dev/null || groupadd ' . escapeshellarg(FTP_GROUP));
    @mkdir('/var/run/vsftpd/empty', 0755, true);
    if (@file_put_contents('/etc/vsftpd.conf', VSFTPD_CONF . "\n") === false) {
        return ['ok' => false, 'error' => 'could not write vsftpd.conf'];
    }
    shell_out('systemctl enable vsftpd', 20);
    [$rc, $out] = shell_out('systemctl restart vsftpd', 30);
    if ($rc !== 0) { return ['ok' => false, 'error' => "vsftpd restart failed: " . trim($out)]; }
    return ftpacct_status() + ['ok' => true];
}

function user_in_ftp_group(string $user): bool
{
    $g = @posix_getgrnam(FTP_GROUP);
    return $g !== false && in_array($user, $g['members'] ?? [], true);
}

function ftpacct_users(): array
{
    $g = @posix_getgrnam(FTP_GROUP);
    if ($g === false) { return []; }
    $res = [];
    foreach (($g['members'] ?? []) as $u) {
        $pw = @posix_getpwnam($u);
        $res[] = ['user' => $u, 'home' => $pw['dir'] ?? ''];
    }
    sort($res);
    return $res;
}

function ftpacct_add(array $a): array
{
    if (!ftpacct_installed()) { return ['ok' => false, 'error' => 'set up FTP first']; }
    $user = (string)($a['user'] ?? '');
    $pass = (string)($a['password'] ?? '');
    $dir  = (string)($a['dir'] ?? '');
    if (!preg_match(FTP_USER_RE, $user)) { return ['ok' => false, 'error' => 'invalid username']; }
    if (@posix_getpwnam($user) !== false) { return ['ok' => false, 'error' => 'user already exists']; }
    if ($pass === '' || strlen($pass) > 128 || preg_match('/[\r\n:]/', $pass)) { return ['ok' => false, 'error' => 'password required (no colon/newline)']; }
    if ($dir === '') { $dir = '/var/www/' . $user; }
    $c = canon($dir, false);
    if ($c === null || !(strpos($c, '/var/www/') === 0 || strpos($c, '/home/') === 0 || strpos($c, '/srv/') === 0)) {
        return ['ok' => false, 'error' => 'home must be under /var/www, /home or /srv'];
    }
    if ($err = is_protected($c, true)) { return ['ok' => false, 'error' => $err]; }

    @shell_exec('getent group ' . escapeshellarg(FTP_GROUP) . ' >/dev/null || groupadd ' . escapeshellarg(FTP_GROUP));
    [$rc, $out] = shell_out('useradd -m -d ' . escapeshellarg($c) . ' -s /usr/sbin/nologin -G '
        . escapeshellarg(FTP_GROUP) . ' ' . escapeshellarg($user), 30);
    if ($rc !== 0) { return ['ok' => false, 'error' => "useradd failed: " . trim($out)]; }

    // set password via temp file (avoids shell-quoting the secret)
    $tmp = tempnam(sys_get_temp_dir(), 'bpftp');
    @file_put_contents($tmp, $user . ':' . $pass);
    [$rc2] = shell_out('chpasswd < ' . escapeshellarg($tmp), 15);
    @unlink($tmp);
    if ($rc2 !== 0) { return ['ok' => false, 'error' => 'user created but setting password failed']; }
    @shell_exec('chown ' . escapeshellarg($user . ':' . $user) . ' ' . escapeshellarg($c));
    return ['ok' => true, 'data' => 'FTP account created'];
}

function ftpacct_delete(string $user): array
{
    if (!preg_match(FTP_USER_RE, $user)) { return ['ok' => false, 'error' => 'invalid username']; }
    if (!user_in_ftp_group($user)) { return ['ok' => false, 'error' => 'not a BitPanel FTP account']; }
    [$rc, $out] = shell_out('userdel ' . escapeshellarg($user), 30); // home/files left in place
    return $rc === 0 ? ['ok' => true, 'data' => 'deleted (home directory left in place)'] : ['ok' => false, 'error' => trim($out)];
}

function ftpacct_password(string $user, string $pass): array
{
    if (!preg_match(FTP_USER_RE, $user)) { return ['ok' => false, 'error' => 'invalid username']; }
    if (!user_in_ftp_group($user)) { return ['ok' => false, 'error' => 'not a BitPanel FTP account']; }
    if ($pass === '' || strlen($pass) > 128 || preg_match('/[\r\n:]/', $pass)) { return ['ok' => false, 'error' => 'invalid password']; }
    $tmp = tempnam(sys_get_temp_dir(), 'bpftp');
    @file_put_contents($tmp, $user . ':' . $pass);
    [$rc] = shell_out('chpasswd < ' . escapeshellarg($tmp), 15);
    @unlink($tmp);
    return $rc === 0 ? ['ok' => true, 'data' => 'password changed'] : ['ok' => false, 'error' => 'chpasswd failed'];
}

/* ============= PHP manager ============================== */

function php_ver_ok(string $v): bool
{
    if (!preg_match('/^\d+\.\d+$/', $v)) { return false; }
    foreach (php_versions() as $pv) { if ($pv['version'] === $v) { return true; } }
    return false;
}

function php_managed_keys(): array
{
    return [
        'memory_limit'         => '/^(-1|\d{1,5}[MGmg]?)$/',
        'upload_max_filesize'  => '/^\d{1,5}[MGmg]?$/',
        'post_max_size'        => '/^\d{1,5}[MGmg]?$/',
        'max_execution_time'   => '/^\d{1,4}$/',
        'max_input_time'       => '/^-?\d{1,4}$/',
        'max_input_vars'       => '/^\d{1,6}$/',
        'display_errors'       => '/^(On|Off)$/',
        'date.timezone'        => '#^[A-Za-z0-9_/+\-]{1,40}$#',
    ];
}

function php_settings_get(string $version): array
{
    if (!php_ver_ok($version)) { return ['ok' => false, 'error' => 'PHP version not installed']; }
    $bin = 'php' . $version;
    $vals = [];
    foreach (array_keys(php_managed_keys()) as $k) {
        $v = trim((string)@shell_exec($bin . ' -r ' . escapeshellarg('echo ini_get("' . $k . '");') . ' 2>/dev/null'));
        $vals[$k] = $v;
    }
    return ['ok' => true, 'data' => ['version' => $version, 'values' => $vals]];
}

function php_settings_set(string $version, array $values): array
{
    if (!php_ver_ok($version)) { return ['ok' => false, 'error' => 'PHP version not installed']; }
    $keys = php_managed_keys();
    $lines = ["; Managed by BitPanel"];
    foreach ($keys as $k => $re) {
        if (!array_key_exists($k, $values)) { continue; }
        $v = trim((string)$values[$k]);
        if ($v === '') { continue; }
        if (!preg_match($re, $v)) { return ['ok' => false, 'error' => "invalid value for {$k}"]; }
        $lines[] = $k . ' = ' . $v;
    }
    $dir = "/etc/php/{$version}/fpm/conf.d";
    if (!is_dir($dir)) { return ['ok' => false, 'error' => 'php-fpm conf.d not found']; }
    if (@file_put_contents($dir . '/99-bitpanel.ini', implode("\n", $lines) . "\n") === false) {
        return ['ok' => false, 'error' => 'could not write php ini'];
    }
    [$rc, $out] = shell_out('systemctl restart php' . $version . '-fpm', 30);
    return $rc === 0 ? ['ok' => true, 'data' => 'saved and FPM restarted'] : ['ok' => false, 'error' => trim($out)];
}

function php_ext_catalog(): array
{
    // ext key => apt package suffix
    return ['gd', 'mbstring', 'curl', 'xml', 'mysql', 'intl', 'zip', 'bcmath', 'gmp', 'soap', 'redis', 'imagick'];
}

function php_ext_list(string $version): array
{
    if (!php_ver_ok($version)) { return ['ok' => false, 'error' => 'PHP version not installed']; }
    $loaded = strtolower((string)@shell_exec('php' . $version . ' -m 2>/dev/null'));
    $res = [];
    foreach (php_ext_catalog() as $ext) {
        $needle = $ext === 'mysql' ? 'pdo_mysql' : $ext;
        $res[] = ['ext' => $ext, 'enabled' => strpos($loaded, $needle) !== false];
    }
    return ['ok' => true, 'data' => $res];
}

function php_ext_toggle(string $version, string $ext, bool $enable): array
{
    if (!php_ver_ok($version)) { return ['ok' => false, 'error' => 'PHP version not installed']; }
    if (!in_array($ext, php_ext_catalog(), true)) { return ['ok' => false, 'error' => 'unknown extension']; }
    $pkg = 'php' . $version . '-' . $ext;
    $cmd = $enable
        ? 'DEBIAN_FRONTEND=noninteractive apt-get install -y ' . escapeshellarg($pkg)
        : 'DEBIAN_FRONTEND=noninteractive apt-get purge -y ' . escapeshellarg($pkg);
    [$rc, $out] = shell_out($cmd, 300);
    if ($rc !== 0) { return ['ok' => false, 'error' => trim($out)]; }
    shell_out('systemctl restart php' . $version . '-fpm', 30);
    return ['ok' => true, 'data' => $ext . ($enable ? ' enabled' : ' disabled')];
}

/* ============= app daemons (supervisor) ================= */


function daemon_unit(string $name): string { return "bitpanel-app-{$name}"; }

function daemon_list(): array
{
    $res = [];
    foreach (glob('/etc/systemd/system/bitpanel-app-*.service') ?: [] as $f) {
        if (!preg_match('/bitpanel-app-(.+)\.service$/', $f, $m)) { continue; }
        $name = $m[1];
        $st = unit_state(daemon_unit($name));
        $meta = json_decode((string)@file_get_contents(DAEMON_DIR . '/' . $name . '.json'), true);
        $res[] = [
            'name' => $name,
            'command' => is_array($meta) ? ($meta['command'] ?? '') : '',
            'dir' => is_array($meta) ? ($meta['dir'] ?? '') : '',
            'user' => is_array($meta) ? ($meta['user'] ?? '') : '',
            'active' => $st['active'] === 'active',
            'sub' => $st['sub'],
        ];
    }
    usort($res, static fn($a, $b) => strcmp($a['name'], $b['name']));
    return $res;
}

function daemon_create(array $a): array
{
    $name = (string)($a['name'] ?? '');
    $cmd  = trim((string)($a['command'] ?? ''));
    $dir  = trim((string)($a['dir'] ?? ''));
    $user = trim((string)($a['user'] ?? 'www-data'));
    $autostart = !empty($a['autostart']);

    if (!preg_match(DAEMON_NAME_RE, $name)) { return ['ok' => false, 'error' => 'name: lowercase letters, digits, - or _']; }
    if (is_file('/etc/systemd/system/' . daemon_unit($name) . '.service')) { return ['ok' => false, 'error' => 'a daemon with that name exists']; }
    if ($cmd === '' || preg_match('/[\r\n]/', $cmd)) { return ['ok' => false, 'error' => 'command required, single line']; }
    if (!preg_match(FTP_USER_RE, $user) || @posix_getpwnam($user) === false) { return ['ok' => false, 'error' => 'unknown run-as user']; }
    if ($dir === '') { $dir = '/var/www'; }
    $c = canon($dir, true);
    if ($c === null || !is_dir($c)) { return ['ok' => false, 'error' => 'working directory not found']; }
    if ($err = is_protected($c, false)) { return ['ok' => false, 'error' => $err]; }

    if (!is_dir(DAEMON_DIR)) { @mkdir(DAEMON_DIR, 0750, true); }
    // command goes in a script to avoid systemd quoting pitfalls
    $script = DAEMON_DIR . '/' . $name . '.sh';
    @file_put_contents($script, "#!/bin/sh\ncd " . escapeshellarg($c) . "\nexec " . $cmd . "\n");
    @chmod($script, 0750);

    $unit = "[Unit]\nDescription=BitPanel app: {$name}\nAfter=network.target\n\n"
          . "[Service]\nType=simple\nUser=" . $user . "\nExecStart=" . $script . "\n"
          . "Restart=always\nRestartSec=3\n\n"
          . "[Install]\nWantedBy=multi-user.target\n";
    if (@file_put_contents('/etc/systemd/system/' . daemon_unit($name) . '.service', $unit) === false) {
        return ['ok' => false, 'error' => 'could not write unit'];
    }
    @file_put_contents(DAEMON_DIR . '/' . $name . '.json',
        json_encode(['command' => $cmd, 'dir' => $c, 'user' => $user]));

    shell_out('systemctl daemon-reload', 20);
    if ($autostart) { shell_out('systemctl enable ' . escapeshellarg(daemon_unit($name)), 20); }
    [$rc, $out] = shell_out('systemctl start ' . escapeshellarg(daemon_unit($name)), 30);
    return $rc === 0 ? ['ok' => true, 'data' => 'daemon created and started'] : ['ok' => false, 'error' => "created but start failed: " . trim($out)];
}

function daemon_action(string $name, string $action): array
{
    if (!preg_match(DAEMON_NAME_RE, $name)) { return ['ok' => false, 'error' => 'invalid name']; }
    if (!is_file('/etc/systemd/system/' . daemon_unit($name) . '.service')) { return ['ok' => false, 'error' => 'daemon not found']; }
    if (!in_array($action, ['start', 'stop', 'restart', 'enable', 'disable'], true)) { return ['ok' => false, 'error' => 'bad action']; }
    [$rc, $out] = shell_out('systemctl ' . $action . ' ' . escapeshellarg(daemon_unit($name)), 30);
    return $rc === 0 ? ['ok' => true, 'data' => "{$action} ok"] : ['ok' => false, 'error' => trim($out)];
}

function daemon_delete(string $name): array
{
    if (!preg_match(DAEMON_NAME_RE, $name)) { return ['ok' => false, 'error' => 'invalid name']; }
    $unitFile = '/etc/systemd/system/' . daemon_unit($name) . '.service';
    if (!is_file($unitFile)) { return ['ok' => false, 'error' => 'daemon not found']; }
    shell_out('systemctl disable --now ' . escapeshellarg(daemon_unit($name)), 30);
    @unlink($unitFile);
    @unlink(DAEMON_DIR . '/' . $name . '.sh');
    @unlink(DAEMON_DIR . '/' . $name . '.json');
    shell_out('systemctl daemon-reload', 20);
    return ['ok' => true, 'data' => 'deleted'];
}

function daemon_logs(string $name, int $lines): array
{
    if (!preg_match(DAEMON_NAME_RE, $name)) { return ['ok' => false, 'error' => 'invalid name']; }
    $lines = max(10, min(1000, $lines));
    $out = (string)@shell_exec('journalctl -u ' . escapeshellarg(daemon_unit($name))
        . ' --no-pager -n ' . (int)$lines . ' 2>&1');
    return ['ok' => true, 'data' => ['text' => $out]];
}

/* ============= system tools ============================= */

function sys_updates(): array
{
    shell_out('DEBIAN_FRONTEND=noninteractive apt-get update -qq', 120);
    $out = (string)@shell_exec('apt list --upgradable 2>/dev/null');
    $list = [];
    foreach (explode("\n", $out) as $line) {
        if (strpos($line, '/') === false || stripos($line, 'Listing') === 0) { continue; }
        if (preg_match('#^(\S+)/\S+\s+(\S+)\s+\S+\s+\[upgradable from:\s*([^\]]+)\]#', $line, $m)) {
            $list[] = ['pkg' => $m[1], 'new' => $m[2], 'old' => trim($m[3])];
        }
        if (count($list) >= 300) { break; }
    }
    return ['ok' => true, 'data' => ['count' => count($list), 'packages' => $list]];
}

function sys_upgrade(): array
{
    [$rc, $out] = shell_out('DEBIAN_FRONTEND=noninteractive apt-get upgrade -y', 1200);
    $tail = implode("\n", array_slice(explode("\n", $out), -20));
    return $rc === 0 ? ['ok' => true, 'data' => $tail] : ['ok' => false, 'error' => $tail];
}

function proc_top(string $sort): array
{
    $key = $sort === 'mem' ? '-%mem' : '-%cpu';
    $out = (string)@shell_exec('ps -eo pid,user,pcpu,pmem,rss,comm --sort=' . $key . ' 2>/dev/null | head -n 31');
    $res = [];
    $lines = explode("\n", trim($out));
    array_shift($lines); // header
    foreach ($lines as $line) {
        $c = preg_split('/\s+/', trim($line), 6);
        if (count($c) < 6) { continue; }
        $res[] = ['pid' => (int)$c[0], 'user' => $c[1], 'cpu' => (float)$c[2],
                  'mem' => (float)$c[3], 'rss' => (int)$c[4] * 1024, 'command' => $c[5]];
    }
    return $res;
}

function proc_kill(int $pid, string $signal): array
{
    if ($pid <= 1) { return ['ok' => false, 'error' => 'refusing to signal PID <= 1']; }
    if ($pid === getmypid()) { return ['ok' => false, 'error' => 'refusing to kill the agent']; }
    $cmdline = (string)@file_get_contents('/proc/' . $pid . '/cmdline');
    if (strpos($cmdline, 'bitpanel-agent') !== false || strpos($cmdline, 'agent.php') !== false) {
        return ['ok' => false, 'error' => 'refusing to kill the BitPanel agent'];
    }
    $sig = in_array($signal, ['TERM', 'KILL', 'HUP', 'INT'], true) ? $signal : 'TERM';
    [$rc, $out] = shell_out('kill -' . $sig . ' ' . (int)$pid, 10);
    return $rc === 0 ? ['ok' => true, 'data' => "sent SIG{$sig} to {$pid}"] : ['ok' => false, 'error' => trim($out) ?: 'no such process'];
}

function net_listening(): array
{
    $out = (string)@shell_exec('ss -tulpnH 2>/dev/null');
    $res = [];
    foreach (explode("\n", trim($out)) as $line) {
        if ($line === '') { continue; }
        $c = preg_split('/\s+/', trim($line));
        if (count($c) < 5) { continue; }
        $proc = '';
        if (preg_match('/users:\(\("([^"]+)"/', $line, $m)) { $proc = $m[1]; }
        $res[] = ['proto' => $c[0], 'local' => $c[4], 'process' => $proc];
        if (count($res) >= 200) { break; }
    }
    return $res;
}

/* ============= scheduled backups ======================= */


function bkjob_prefix(array $j): string
{
    if ($j['type'] === 'site') { return 'site-' . $j['target'] . '-'; }
    if ($j['type'] === 'db')   { return 'db-' . $j['target'] . '-'; }
    $safe = preg_replace('/[^A-Za-z0-9._-]/', '_', trim(basename($j['target']), '/')) ?: 'root';
    return 'path-' . $safe . '-';
}

function bkjob_list(): array
{
    if (!is_dir(BKJOB_DIR)) { return []; }
    $res = [];
    foreach (glob(BKJOB_DIR . '/*.json') ?: [] as $f) {
        $j = json_decode((string)@file_get_contents($f), true);
        if (is_array($j)) { $res[] = $j; }
    }
    usort($res, static fn($a, $b) => strcmp($a['id'] ?? '', $b['id'] ?? ''));
    return $res;
}

function bkjob_create(array $a): array
{
    $type = (string)($a['type'] ?? '');
    $target = (string)($a['target'] ?? '');
    $schedule = trim((string)($a['schedule'] ?? ''));
    $keep = (int)($a['keep'] ?? 7);
    $s3 = !empty($a['s3']);

    if (!in_array($type, ['site', 'path', 'db'], true)) { return ['ok' => false, 'error' => 'type must be site, path or db']; }
    if (!cron_validate_schedule($schedule)) { return ['ok' => false, 'error' => 'invalid schedule']; }
    if ($keep < 1 || $keep > 100) { return ['ok' => false, 'error' => 'keep must be 1–100']; }

    if ($type === 'site') {
        if (site_load($target) === null) { return ['ok' => false, 'error' => 'site not found']; }
    } elseif ($type === 'db') {
        if (!preg_match(IDENT_RE, $target)) { return ['ok' => false, 'error' => 'invalid database']; }
    } else {
        $c = canon($target, true);
        if ($c === null || $c === '/') { return ['ok' => false, 'error' => 'invalid path']; }
        if ($err = is_protected($c, false)) { return ['ok' => false, 'error' => $err]; }
        $target = $c;
    }

    $base = preg_replace('/[^a-z0-9._-]/', '-', strtolower($type . '-' . basename($target)));
    $base = trim((string)$base, '-.') ?: 'job';
    $id = $base; $i = 1;
    if (!is_dir(BKJOB_DIR)) { @mkdir(BKJOB_DIR, 0750, true); }
    while (is_file(BKJOB_DIR . '/' . $id . '.json')) { $id = $base . '-' . (++$i); }
    if (!preg_match(BKJOB_ID_RE, $id)) { return ['ok' => false, 'error' => 'could not derive job id']; }

    $job = ['id' => $id, 'type' => $type, 'target' => $target, 'schedule' => $schedule,
            'keep' => $keep, 's3' => $s3, 'created' => time()];
    @file_put_contents(BKJOB_DIR . '/' . $id . '.json', json_encode($job, JSON_PRETTY_PRINT));

    // one cron.d entry per job, running the backup-runner as root
    $cron = $schedule . ' root /usr/bin/php /opt/bitpanel/panel/bin/backup-runner.php '
          . $id . ' >> /opt/bitpanel/logs/backup.log 2>&1' . "\n";
    if (@file_put_contents('/etc/cron.d/bitpanel-bk-' . $id, $cron) === false) {
        @unlink(BKJOB_DIR . '/' . $id . '.json');
        return ['ok' => false, 'error' => 'could not write cron entry'];
    }
    @chmod('/etc/cron.d/bitpanel-bk-' . $id, 0644);
    return ['ok' => true, 'data' => $job];
}

function bkjob_delete(string $id): array
{
    if (!preg_match(BKJOB_ID_RE, $id)) { return ['ok' => false, 'error' => 'invalid id']; }
    $f = BKJOB_DIR . '/' . $id . '.json';
    if (!is_file($f)) { return ['ok' => false, 'error' => 'job not found']; }
    @unlink($f);
    @unlink('/etc/cron.d/bitpanel-bk-' . $id);
    return ['ok' => true, 'data' => 'deleted (existing archives kept)'];
}

/* ============= database query console =================== */

function db_tables(string $database): array
{
    if (!preg_match(IDENT_RE, $database) || db_engine_unit() === null) { return ['ok' => false, 'error' => 'invalid database']; }
    [$rc, $out] = mysql_q("SELECT table_name, table_rows, ROUND((data_length+index_length)) "
        . "FROM information_schema.tables WHERE table_schema='" . $database . "' ORDER BY table_name");
    if ($rc !== 0) { return ['ok' => false, 'error' => trim($out)]; }
    $res = [];
    foreach (explode("\n", trim($out)) as $line) {
        if ($line === '') { continue; }
        $c = explode("\t", $line);
        if (count($c) < 1) { continue; }
        $res[] = ['name' => $c[0], 'rows' => (int)($c[1] ?? 0), 'size' => (float)($c[2] ?? 0)];
    }
    return ['ok' => true, 'data' => $res];
}

function db_query(string $database, string $sql): array
{
    if (!preg_match(IDENT_RE, $database) || db_engine_unit() === null) { return ['ok' => false, 'error' => 'invalid database']; }
    $sql = trim($sql);
    if ($sql === '') { return ['ok' => false, 'error' => 'empty query']; }
    if (strlen($sql) > 200000) { return ['ok' => false, 'error' => 'query too long']; }

    $tmp = tempnam(sys_get_temp_dir(), 'bpsql');
    @file_put_contents($tmp, $sql);
    $cmd = mysql_prefix() . ' --table --database=' . escapeshellarg($database) . ' < ' . escapeshellarg($tmp);
    [$rc, $out] = shell_out($cmd, 60);
    @unlink($tmp);
    // cap returned text so the panel isn't flooded
    if (strlen($out) > 200000) { $out = substr($out, 0, 200000) . "\n… output truncated …"; }
    return $rc === 0
        ? ['ok' => true, 'data' => ['text' => $out !== '' ? $out : '(query ok, no result set)']]
        : ['ok' => false, 'error' => trim($out)];
}

/* =================== mail server ========================= */
/* Postfix (virtual mailboxes, no open relay) + Dovecot (IMAP/SASL) + OpenDKIM.
 * No MySQL dependency: domains/mailboxes/aliases are JSON-authoritative on disk;
 * Postfix hash maps and Dovecot's passwd-file are fully regenerated on every change. */


function mail_ensure_dirs(): void
{
    foreach ([MAIL_DIR, MAIL_SSL_DIR] as $d) {
        if (!is_dir($d)) { @mkdir($d, 0750, true); }
    }
    foreach ([MAIL_DOMAINS, MAIL_BOXES, MAIL_ALIASES] as $f) {
        if (!is_file($f)) { @file_put_contents($f, '{}'); }
    }
}

function mail_json_read(string $f): array
{
    $j = json_decode((string)@file_get_contents($f), true);
    return is_array($j) ? $j : [];
}

function mail_json_write(string $f, array $data): void
{
    @file_put_contents($f, json_encode($data, JSON_PRETTY_PRINT));
    @chmod($f, 0640);
}

function mail_config_get(): array
{
    mail_ensure_dirs();
    $c = mail_json_read(MAIL_CONF);
    return ['hostname' => $c['hostname'] ?? ''];
}

function mail_installed(): bool
{
    return pkg_installed('postfix') && pkg_installed('dovecot-core');
}

function mail_status(): array
{
    mail_ensure_dirs();
    $installed = mail_installed();
    $pf = unit_state('postfix');
    $dv = unit_state('dovecot');
    $dk = unit_state('opendkim');
    $cfg = mail_config_get();
    return [
        'installed' => $installed,
        'postfix'   => $pf['active'] === 'active',
        'dovecot'   => $dv['active'] === 'active',
        'opendkim'  => $dk['active'] === 'active',
        'hostname'  => $cfg['hostname'],
        'ssl'       => is_file(MAIL_SSL_DIR . '/fullchain.pem'),
        'domains'   => count(mail_json_read(MAIL_DOMAINS)),
        'mailboxes' => count(mail_json_read(MAIL_BOXES)),
    ];
}

/* ---- one-time / idempotent setup ---- */

function mail_ensure_acme_catchall(): void
{
    // Any hostname's HTTP-01 challenge succeeds even before it's a configured "site".
    $f = NG_AVAIL . '/00-bitpanel-acme-catchall.conf';
    if (is_file($f)) { return; }
    $conf = "server {\n    listen 80 default_server;\n    listen [::]:80 default_server;\n"
          . "    server_name _;\n"
          . "    location ^~ /.well-known/acme-challenge/ {\n"
          . "        root " . ACME_WEBROOT . ";\n        default_type \"text/plain\";\n    }\n"
          . "    location / { return 444; }\n}\n";
    @mkdir(ACME_WEBROOT . '/.well-known/acme-challenge', 0755, true);
    @shell_exec('chown -R www-data:www-data ' . escapeshellarg(ACME_WEBROOT));
    if (@file_put_contents($f, $conf) !== false) {
        @symlink($f, NG_ENABLED . '/00-bitpanel-acme-catchall.conf');
        nginx_test_reload();
    }
}

function mail_ensure_vmail_user(): array
{
    if (@posix_getpwnam(VMAIL_USER) === false) {
        [$rc, $out] = shell_out('useradd -r -m -d ' . VMAIL_HOME . ' -s /usr/sbin/nologin ' . VMAIL_USER, 20);
        if ($rc !== 0) { return ['ok' => false, 'error' => 'could not create vmail user: ' . trim($out)]; }
    }
    @mkdir(VMAIL_HOME, 0750, true);
    @shell_exec('chown ' . VMAIL_USER . ':' . VMAIL_USER . ' ' . VMAIL_HOME);
    return ['ok' => true];
}

function mail_configure_postfix(): array
{
    $pw = @posix_getpwnam(VMAIL_USER);
    if ($pw === false) { return ['ok' => false, 'error' => 'vmail user missing']; }
    $uid = (int)$pw['uid'];
    $gid = (int)$pw['gid'];

    $kv = [
        'virtual_mailbox_domains'  => 'hash:/etc/postfix/vmail_domains',
        'virtual_mailbox_base'     => VMAIL_HOME,
        'virtual_mailbox_maps'     => 'hash:/etc/postfix/vmail_users',
        'virtual_alias_maps'       => 'hash:/etc/postfix/vmail_aliases',
        'virtual_minimum_uid'      => (string)$uid,
        'virtual_uid_maps'         => 'static:' . $uid,
        'virtual_gid_maps'         => 'static:' . $gid,
        'virtual_transport'        => 'virtual',
        'mynetworks'               => '127.0.0.0/8 [::1]/128',
        'inet_interfaces'          => 'all',
        'inet_protocols'           => 'ipv4',
        'smtpd_sasl_auth_enable'   => 'yes',
        'smtpd_sasl_type'          => 'dovecot',
        'smtpd_sasl_path'          => 'private/auth',
        'smtpd_relay_restrictions' => 'permit_mynetworks,permit_sasl_authenticated,reject_unauth_destination',
        'smtpd_recipient_restrictions' => 'permit_mynetworks,permit_sasl_authenticated,reject_unauth_destination',
        'smtpd_helo_required'      => 'yes',
        'disable_vrfy_command'     => 'yes',
        'smtpd_tls_security_level' => 'may',
        'smtp_tls_security_level'  => 'may',
        'smtpd_milters'            => 'inet:127.0.0.1:8891',
        'non_smtpd_milters'        => 'inet:127.0.0.1:8891',
        'milter_default_action'    => 'accept',
        'milter_protocol'          => '6',
    ];
    $cfg = mail_config_get();
    if ($cfg['hostname'] !== '') {
        $kv['myhostname'] = $cfg['hostname'];
        $kv['smtpd_tls_cert_file'] = MAIL_SSL_DIR . '/fullchain.pem';
        $kv['smtpd_tls_key_file']  = MAIL_SSL_DIR . '/key.pem';
    }
    $args = '';
    foreach ($kv as $k => $v) { $args .= ' ' . escapeshellarg($k . '=' . $v); }
    [$rc, $out] = shell_out('postconf -e' . $args, 30);
    if ($rc !== 0) { return ['ok' => false, 'error' => 'postconf -e failed: ' . trim($out)]; }

    // submission (587): add service if missing, then set SASL-only overrides.
    $has = trim((string)@shell_exec("postconf -M 2>/dev/null | grep -c '^submission '"));
    if ($has === '0' || $has === '') {
        shell_out('postconf -M ' . escapeshellarg('submission/inet=submission inet n - y - - smtpd'), 20);
    }
    $subOverrides = [
        'smtpd_tls_security_level=encrypt',
        'smtpd_sasl_auth_enable=yes',
        'smtpd_sasl_type=dovecot',
        'smtpd_sasl_path=private/auth',
        'smtpd_client_restrictions=permit_sasl_authenticated,reject',
        'smtpd_relay_restrictions=permit_sasl_authenticated,reject',
    ];
    foreach ($subOverrides as $o) {
        shell_out('postconf -P ' . escapeshellarg('submission/inet/' . $o), 20);
    }
    // ensure empty maps exist so postfix doesn't fail to start before first domain
    foreach (['/etc/postfix/vmail_domains', '/etc/postfix/vmail_users', '/etc/postfix/vmail_aliases'] as $f) {
        if (!is_file($f)) { @touch($f); }
        shell_out('postmap ' . escapeshellarg($f), 15);
    }
    return ['ok' => true];
}

function mail_configure_dovecot(): array
{
    $cfg = mail_config_get();
    $ssl = $cfg['hostname'] !== '' && is_file(MAIL_SSL_DIR . '/fullchain.pem');
    $conf = "# Managed by BitPanel\n"
        . "protocols = imap\n"
        . "mail_location = maildir:" . VMAIL_HOME . "/%d/%n\n"
        . "disable_plaintext_auth = " . ($ssl ? 'yes' : 'no') . "\n"
        . "auth_mechanisms = plain login\n"
        . ($ssl
            ? "ssl = required\nssl_cert = <" . MAIL_SSL_DIR . "/fullchain.pem\nssl_key = <" . MAIL_SSL_DIR . "/key.pem\n"
            : "ssl = no\n")
        . "passdb {\n  driver = passwd-file\n  args = scheme=SHA512-CRYPT username_format=%u /etc/dovecot/vmail_users.passwd\n}\n"
        . "userdb {\n  driver = passwd-file\n  args = username_format=%u /etc/dovecot/vmail_users.passwd\n"
        . "  default_fields = uid=" . VMAIL_USER . " gid=" . VMAIL_USER . " home=" . VMAIL_HOME . "/%d/%n\n}\n"
        . "service auth {\n  unix_listener /var/spool/postfix/private/auth {\n    mode = 0660\n    user = postfix\n    group = postfix\n  }\n}\n";
    if (@file_put_contents('/etc/dovecot/conf.d/99-bitpanel.conf', $conf) === false) {
        return ['ok' => false, 'error' => 'could not write dovecot conf'];
    }
    if (!is_file('/etc/dovecot/vmail_users.passwd')) { @touch('/etc/dovecot/vmail_users.passwd'); }
    @chmod('/etc/dovecot/vmail_users.passwd', 0640);
    @shell_exec('chgrp dovecot /etc/dovecot/vmail_users.passwd 2>/dev/null');
    return ['ok' => true];
}

function mail_configure_opendkim(): array
{
    @mkdir(OPENDKIM_KEYS, 0750, true);
    $conf = "Syslog yes\nUMask 007\nSocket inet:8891@127.0.0.1\nPidFile /run/opendkim/opendkim.pid\n"
          . "Mode sv\nCanonicalization relaxed/simple\nKeyTable /etc/opendkim/KeyTable\n"
          . "SigningTable refile:/etc/opendkim/SigningTable\nExternalIgnoreList /etc/opendkim/TrustedHosts\n"
          . "InternalHosts /etc/opendkim/TrustedHosts\n";
    @file_put_contents('/etc/opendkim.conf', $conf);
    @file_put_contents('/etc/opendkim/TrustedHosts', "127.0.0.1\n::1\n");
    foreach (['/etc/opendkim/KeyTable', '/etc/opendkim/SigningTable'] as $f) {
        if (!is_file($f)) { @touch($f); }
    }
    return ['ok' => true];
}

function mail_setup(): array
{
    if (!mail_installed()) {
        [$rc, $out] = shell_out('DEBIAN_FRONTEND=noninteractive apt-get install -y '
            . 'postfix dovecot-core dovecot-imapd opendkim opendkim-tools', 600);
        if ($rc !== 0) { return ['ok' => false, 'error' => "install failed:\n" . $out]; }
    }
    mail_ensure_dirs();
    $v = mail_ensure_vmail_user();
    if (!$v['ok']) { return $v; }
    mail_ensure_acme_catchall();

    $p = mail_configure_postfix();
    if (!$p['ok']) { return $p; }
    $d = mail_configure_dovecot();
    if (!$d['ok']) { return $d; }
    $k = mail_configure_opendkim();
    if (!$k['ok']) { return $k; }

    mail_rewrite_maps(); // regenerate from existing JSON (safe if empty)

    shell_out('systemctl enable postfix dovecot opendkim', 20);
    [$rc1, $o1] = shell_out('systemctl restart opendkim', 20);
    [$rc2, $o2] = shell_out('systemctl restart dovecot', 20);
    [$rc3, $o3] = shell_out('systemctl restart postfix', 20);
    if ($rc1 !== 0 || $rc2 !== 0 || $rc3 !== 0) {
        return ['ok' => false, 'error' => "service restart failed — opendkim:{$o1} dovecot:{$o2} postfix:{$o3}"];
    }
    return ['ok' => true, 'data' => mail_status()];
}

function mail_hostname_set(string $hostname): array
{
    if (!preg_match(DOMAIN_RE, $hostname)) { return ['ok' => false, 'error' => 'invalid hostname']; }
    mail_ensure_dirs();
    mail_json_write(MAIL_CONF, ['hostname' => $hostname]);
    if (mail_installed()) { mail_configure_postfix(); mail_configure_dovecot(); shell_out('systemctl restart postfix dovecot', 30); }
    return ['ok' => true, 'data' => mail_config_get()];
}

function mail_ssl_issue(): array
{
    $cfg = mail_config_get();
    if ($cfg['hostname'] === '') { return ['ok' => false, 'error' => 'set a mail hostname first']; }
    if (!mail_installed()) { return ['ok' => false, 'error' => 'set up the mail server first']; }
    mail_ensure_acme_catchall();
    $e = acme_ensure();
    if (!$e['ok']) { return $e; }

    [$rc, $out] = shell_out(ACME_SH . ' --issue -d ' . escapeshellarg($cfg['hostname'])
        . ' --webroot ' . escapeshellarg(ACME_WEBROOT) . ' --server letsencrypt --keylength 2048', 300);
    if ($rc !== 0 && $rc !== 2) { return ['ok' => false, 'error' => "certificate issuance failed:\n" . $out]; }

    if (!is_dir(MAIL_SSL_DIR)) { @mkdir(MAIL_SSL_DIR, 0750, true); }
    [$rc2, $out2] = shell_out(ACME_SH . ' --install-cert -d ' . escapeshellarg($cfg['hostname'])
        . ' --key-file ' . escapeshellarg(MAIL_SSL_DIR . '/key.pem')
        . ' --fullchain-file ' . escapeshellarg(MAIL_SSL_DIR . '/fullchain.pem')
        . ' --reloadcmd ' . escapeshellarg('systemctl reload postfix dovecot'), 120);
    if ($rc2 !== 0 || !is_file(MAIL_SSL_DIR . '/fullchain.pem')) { return ['ok' => false, 'error' => "cert install failed:\n" . $out2]; }
    @chmod(MAIL_SSL_DIR . '/key.pem', 0640);
    @shell_exec('chgrp dovecot ' . escapeshellarg(MAIL_SSL_DIR . '/key.pem') . ' 2>/dev/null');

    mail_configure_postfix();
    mail_configure_dovecot();
    shell_out('systemctl restart postfix dovecot', 30);
    return ['ok' => true, 'data' => cert_expiry_generic(MAIL_SSL_DIR . '/fullchain.pem')];
}

function cert_expiry_generic(string $fullchain): ?int
{
    if (!is_file($fullchain)) { return null; }
    $out = (string)@shell_exec('openssl x509 -enddate -noout -in ' . escapeshellarg($fullchain) . ' 2>/dev/null');
    if (preg_match('/notAfter=(.+)/', $out, $m)) { $ts = strtotime(trim($m[1])); return $ts !== false ? $ts : null; }
    return null;
}

/* ---- map regeneration (JSON is authoritative) ---- */

function mail_rewrite_maps(): void
{
    $domains = mail_json_read(MAIL_DOMAINS);
    $boxes   = mail_json_read(MAIL_BOXES);
    $aliases = mail_json_read(MAIL_ALIASES);

    $dLines = [];
    foreach (array_keys($domains) as $d) { $dLines[] = $d . ' OK'; }
    @file_put_contents('/etc/postfix/vmail_domains', implode("\n", $dLines) . "\n");

    $uLines = [];
    $pLines = [];
    foreach ($boxes as $email => $b) {
        $uLines[] = $email . ' ' . $b['domain'] . '/' . $b['local'] . '/';
        $pLines[] = $email . ':' . $b['dovecot_hash'] . ':' . VMAIL_USER . ':' . VMAIL_USER . '::'
                  . VMAIL_HOME . '/' . $b['domain'] . '/' . $b['local'] . '::';
    }
    @file_put_contents('/etc/postfix/vmail_users', implode("\n", $uLines) . "\n");
    @file_put_contents('/etc/dovecot/vmail_users.passwd', implode("\n", $pLines) . "\n");
    @chmod('/etc/dovecot/vmail_users.passwd', 0640);

    $aLines = [];
    foreach ($aliases as $from => $to) { $aLines[] = $from . ' ' . $to; }
    @file_put_contents('/etc/postfix/vmail_aliases', implode("\n", $aLines) . "\n");

    foreach (['/etc/postfix/vmail_domains', '/etc/postfix/vmail_users', '/etc/postfix/vmail_aliases'] as $f) {
        shell_out('postmap ' . escapeshellarg($f), 20);
    }
    shell_out('systemctl reload postfix', 15);
    shell_out('systemctl reload dovecot', 15);

    $kt = [];
    $st = [];
    foreach (array_keys($domains) as $d) {
        $kt[] = "mail._domainkey.{$d} {$d}:mail:" . OPENDKIM_KEYS . "/{$d}/mail.private";
        $st[] = "*@{$d} mail._domainkey.{$d}";
    }
    @file_put_contents('/etc/opendkim/KeyTable', implode("\n", $kt) . "\n");
    @file_put_contents('/etc/opendkim/SigningTable', implode("\n", $st) . "\n");
    shell_out('systemctl restart opendkim', 20);
}

/* ---- DNS record helpers ---- */

function mail_dkim_txt_value(string $domain): ?string
{
    $f = OPENDKIM_KEYS . "/{$domain}/mail.txt";
    $raw = (string)@file_get_contents($f);
    if ($raw === '') { return null; }
    preg_match_all('/"([^"]*)"/', $raw, $m);
    return $m[1] ? implode('', $m[1]) : null;
}

function mail_domain_records(string $domain): array
{
    if (!preg_match(DOMAIN_RE, $domain)) { return ['ok' => false, 'error' => 'invalid domain']; }
    $domains = mail_json_read(MAIL_DOMAINS);
    if (!isset($domains[$domain])) { return ['ok' => false, 'error' => 'domain not found']; }
    $cfg = mail_config_get();
    $mx = $cfg['hostname'] !== '' ? $cfg['hostname'] : $domain;
    return ['ok' => true, 'data' => [
        'mx'     => ['host' => $domain, 'type' => 'MX', 'value' => "10 {$mx}."],
        'spf'    => ['host' => $domain, 'type' => 'TXT', 'value' => 'v=spf1 mx ~all'],
        'dkim'   => ['host' => "mail._domainkey.{$domain}", 'type' => 'TXT', 'value' => mail_dkim_txt_value($domain) ?? '(pending)'],
        'dmarc'  => ['host' => "_dmarc.{$domain}", 'type' => 'TXT', 'value' => 'v=DMARC1; p=none; rua=mailto:postmaster@' . $domain],
    ]];
}

/* ---- domains ---- */

function mail_domain_list(): array
{
    mail_ensure_dirs();
    $domains = mail_json_read(MAIL_DOMAINS);
    $boxes = mail_json_read(MAIL_BOXES);
    $counts = [];
    foreach ($boxes as $email => $b) { $counts[$b['domain']] = ($counts[$b['domain']] ?? 0) + 1; }
    $res = [];
    foreach ($domains as $d => $meta) {
        $res[] = ['domain' => $d, 'mailboxes' => $counts[$d] ?? 0, 'created' => $meta['created'] ?? 0];
    }
    usort($res, static fn($a, $b) => strcmp($a['domain'], $b['domain']));
    return $res;
}

function mail_domain_add(string $domain): array
{
    if (!mail_installed()) { return ['ok' => false, 'error' => 'set up the mail server first']; }
    if (!preg_match(DOMAIN_RE, $domain)) { return ['ok' => false, 'error' => 'invalid domain']; }
    $domains = mail_json_read(MAIL_DOMAINS);
    if (isset($domains[$domain])) { return ['ok' => false, 'error' => 'domain already added']; }

    @mkdir(OPENDKIM_KEYS . "/{$domain}", 0750, true);
    [$rc, $out] = shell_out('opendkim-genkey -b 2048 -s mail -d ' . escapeshellarg($domain)
        . ' -D ' . escapeshellarg(OPENDKIM_KEYS . "/{$domain}"), 30);
    if ($rc !== 0 || !is_file(OPENDKIM_KEYS . "/{$domain}/mail.private")) {
        return ['ok' => false, 'error' => "DKIM key generation failed: " . trim($out)];
    }
    @shell_exec('chown -R opendkim:opendkim ' . escapeshellarg(OPENDKIM_KEYS . "/{$domain}"));
    @chmod(OPENDKIM_KEYS . "/{$domain}/mail.private", 0600);

    $domains[$domain] = ['created' => time()];
    mail_json_write(MAIL_DOMAINS, $domains);
    mail_rewrite_maps();

    $rec = mail_domain_records($domain);
    return ['ok' => true, 'data' => $rec['ok'] ? $rec['data'] : null];
}

function mail_domain_delete(string $domain): array
{
    if (!preg_match(DOMAIN_RE, $domain)) { return ['ok' => false, 'error' => 'invalid domain']; }
    $domains = mail_json_read(MAIL_DOMAINS);
    if (!isset($domains[$domain])) { return ['ok' => false, 'error' => 'domain not found']; }
    unset($domains[$domain]);
    mail_json_write(MAIL_DOMAINS, $domains);

    $boxes = mail_json_read(MAIL_BOXES);
    foreach ($boxes as $email => $b) { if ($b['domain'] === $domain) { unset($boxes[$email]); } }
    mail_json_write(MAIL_BOXES, $boxes);

    $aliases = mail_json_read(MAIL_ALIASES);
    foreach (array_keys($aliases) as $from) {
        if (strpos($from, '@' . $domain) !== false) { unset($aliases[$from]); }
    }
    mail_json_write(MAIL_ALIASES, $aliases);

    mail_rewrite_maps();
    if (is_dir(VMAIL_HOME . '/' . $domain)) {
        shell_out('rm -rf --one-file-system -- ' . escapeshellarg(VMAIL_HOME . '/' . $domain), 60);
    }
    if (is_dir(OPENDKIM_KEYS . '/' . $domain)) {
        shell_out('rm -rf -- ' . escapeshellarg(OPENDKIM_KEYS . '/' . $domain), 20);
    }
    return ['ok' => true, 'data' => 'domain and its mailboxes deleted'];
}

/* ---- mailboxes ---- */

function dovecot_hash(string $pw): string
{
    $salt = substr(strtr(base64_encode(random_bytes(9)), '+/', './'), 0, 16);
    return '{SHA512-CRYPT}' . crypt($pw, '$6$' . $salt . '$');
}

function mail_mailbox_list(string $domain): array
{
    $boxes = mail_json_read(MAIL_BOXES);
    $res = [];
    foreach ($boxes as $email => $b) {
        if ($domain !== '' && $b['domain'] !== $domain) { continue; }
        $res[] = ['email' => $email, 'domain' => $b['domain'], 'created' => $b['created'] ?? 0];
    }
    usort($res, static fn($a, $b) => strcmp($a['email'], $b['email']));
    return $res;
}

function mail_mailbox_add(string $email, string $password): array
{
    $email = strtolower($email);
    if (!preg_match(EMAIL_RE, $email)) { return ['ok' => false, 'error' => 'invalid email address']; }
    if ($password === '' || strlen($password) < 8 || strlen($password) > 128 || preg_match('/[\r\n]/', $password)) {
        return ['ok' => false, 'error' => 'password must be 8-128 chars, no newlines']; 
    }
    [$local, $domain] = explode('@', $email, 2);
    $domains = mail_json_read(MAIL_DOMAINS);
    if (!isset($domains[$domain])) { return ['ok' => false, 'error' => 'add the domain first']; }
    $boxes = mail_json_read(MAIL_BOXES);
    if (isset($boxes[$email])) { return ['ok' => false, 'error' => 'mailbox already exists']; }

    $dir = VMAIL_HOME . "/{$domain}/{$local}";
    foreach (['cur', 'new', 'tmp'] as $sub) { @mkdir("{$dir}/{$sub}", 0700, true); }
    @shell_exec('chown -R ' . VMAIL_USER . ':' . VMAIL_USER . ' ' . escapeshellarg(VMAIL_HOME . "/{$domain}"));

    $boxes[$email] = ['domain' => $domain, 'local' => $local, 'dovecot_hash' => dovecot_hash($password), 'created' => time()];
    mail_json_write(MAIL_BOXES, $boxes);
    mail_rewrite_maps();
    return ['ok' => true, 'data' => 'mailbox created'];
}

function mail_mailbox_delete(string $email): array
{
    $email = strtolower($email);
    $boxes = mail_json_read(MAIL_BOXES);
    if (!isset($boxes[$email])) { return ['ok' => false, 'error' => 'mailbox not found']; }
    $b = $boxes[$email];
    unset($boxes[$email]);
    mail_json_write(MAIL_BOXES, $boxes);
    mail_rewrite_maps();
    $dir = VMAIL_HOME . '/' . $b['domain'] . '/' . $b['local'];
    if (is_dir($dir)) { shell_out('rm -rf --one-file-system -- ' . escapeshellarg($dir), 60); }
    return ['ok' => true, 'data' => 'mailbox deleted'];
}

function mail_mailbox_password(string $email, string $password): array
{
    $email = strtolower($email);
    if ($password === '' || strlen($password) < 8 || strlen($password) > 128) { return ['ok' => false, 'error' => 'password must be 8-128 chars']; }
    $boxes = mail_json_read(MAIL_BOXES);
    if (!isset($boxes[$email])) { return ['ok' => false, 'error' => 'mailbox not found']; }
    $boxes[$email]['dovecot_hash'] = dovecot_hash($password);
    mail_json_write(MAIL_BOXES, $boxes);
    mail_rewrite_maps();
    return ['ok' => true, 'data' => 'password changed'];
}

/* ---- aliases / forwards ---- */

function mail_alias_list(): array
{
    $aliases = mail_json_read(MAIL_ALIASES);
    $res = [];
    foreach ($aliases as $from => $to) { $res[] = ['from' => $from, 'to' => $to]; }
    usort($res, static fn($a, $b) => strcmp($a['from'], $b['from']));
    return $res;
}

function mail_alias_add(string $from, string $to): array
{
    $from = strtolower(trim($from));
    $to = trim($to);
    if (!preg_match(EMAIL_RE, $from)) { return ['ok' => false, 'error' => 'invalid "from" address']; }
    foreach (array_map('trim', explode(',', $to)) as $t) {
        if (!preg_match(EMAIL_RE, $t)) { return ['ok' => false, 'error' => "invalid target address: {$t}"]; }
    }
    [, $domain] = array_pad(explode('@', $from, 2), 2, '');
    $domains = mail_json_read(MAIL_DOMAINS);
    if (!isset($domains[$domain])) { return ['ok' => false, 'error' => 'domain not found']; }
    $aliases = mail_json_read(MAIL_ALIASES);
    $aliases[$from] = $to;
    mail_json_write(MAIL_ALIASES, $aliases);
    mail_rewrite_maps();
    return ['ok' => true, 'data' => 'alias added'];
}

function mail_alias_delete(string $from): array
{
    $from = strtolower(trim($from));
    $aliases = mail_json_read(MAIL_ALIASES);
    if (!isset($aliases[$from])) { return ['ok' => false, 'error' => 'alias not found']; }
    unset($aliases[$from]);
    mail_json_write(MAIL_ALIASES, $aliases);
    mail_rewrite_maps();
    return ['ok' => true, 'data' => 'alias deleted'];
}

/* =================== data cleanup ========================= */

function du_bytes(string $path): float
{
    if (!file_exists($path)) { return 0.0; }
    $out = trim((string)@shell_exec('du -sb ' . escapeshellarg($path) . ' 2>/dev/null | cut -f1'));
    return $out !== '' && ctype_digit($out) ? (float)$out : 0.0;
}

function cleanup_disk_usage(): array
{
    $paths = [
        'Web sites (/var/www)'        => '/var/www',
        'Logs (/var/log)'             => '/var/log',
        'Backups'                     => BACKUP_DIR,
        'APT package cache'           => '/var/cache/apt/archives',
        'MySQL/MariaDB data'          => '/var/lib/mysql',
        'Docker'                      => '/var/lib/docker',
        'Mail (/var/vmail)'           => VMAIL_HOME,
        'Home directories'            => '/home',
        'systemd journal'             => '/var/log/journal',
    ];
    $res = [];
    foreach ($paths as $label => $p) {
        if (!file_exists($p)) { continue; }
        $res[] = ['label' => $label, 'path' => $p, 'size' => du_bytes($p)];
    }
    usort($res, static fn($a, $b) => $b['size'] <=> $a['size']);
    return ['disks' => disks(), 'breakdown' => $res];
}

function journal_usage_bytes(): float
{
    $out = (string)@shell_exec('journalctl --disk-usage 2>/dev/null');
    if (preg_match('/take up\s+([\d.]+)\s*([KMGT]?)\s+in the file system/i', $out, $m)) {
        $mult = ['' => 1, 'K' => 1024, 'M' => 1024 ** 2, 'G' => 1024 ** 3, 'T' => 1024 ** 4];
        return (float)$m[1] * ($mult[strtoupper($m[2])] ?? 1);
    }
    return 0.0;
}

function cleanup_scan(): array
{
    $apt = du_bytes('/var/cache/apt/archives');
    $journal = journal_usage_bytes();
    $journalReclaim = max(0.0, $journal - 200 * 1024 * 1024); // target cap 200MB

    $oldBackups = 0.0; $oldBackupCount = 0;
    $cutoff = time() - 30 * 86400;
    foreach (backup_list() as $b) {
        if ($b['mtime'] < $cutoff) { $oldBackups += $b['size']; $oldBackupCount++; }
    }

    $logsTotal = 0.0; $logCount = 0;
    foreach (log_list() as $l) {
        if ($l['size'] > 20 * 1024 * 1024) { $logsTotal += $l['size']; $logCount++; }
    }

    $tmpTotal = 0.0; $tmpCount = 0;
    $tmpCutoff = time() - 86400;
    foreach ([UPTMP, DLTMP] as $d) {
        foreach (glob($d . '/*') ?: [] as $f) {
            if (is_file($f) && (int)@filemtime($f) < $tmpCutoff) { $tmpTotal += (float)@filesize($f); $tmpCount++; }
        }
    }

    $dockerReclaim = null;
    if (docker_installed()) {
        $out = (string)@shell_exec('docker system df --format \'{{.Type}}\t{{.Reclaimable}}\' 2>/dev/null');
        $dockerReclaim = $out !== '' ? $out : null;
    }

    return [
        'apt_cache'   => ['bytes' => $apt],
        'journal'     => ['bytes' => $journal, 'reclaimable' => $journalReclaim],
        'old_backups' => ['bytes' => $oldBackups, 'count' => $oldBackupCount, 'days' => 30],
        'large_logs'  => ['bytes' => $logsTotal, 'count' => $logCount, 'threshold_mb' => 20],
        'tmp_files'   => ['bytes' => $tmpTotal, 'count' => $tmpCount],
        'docker'      => ['installed' => docker_installed(), 'summary' => $dockerReclaim],
    ];
}

function cleanup_run(string $action, array $params): array
{
    switch ($action) {
        case 'apt_clean':
            [$rc, $out] = shell_out('apt-get clean && DEBIAN_FRONTEND=noninteractive apt-get autoremove -y', 120);
            return $rc === 0 ? ['ok' => true, 'data' => 'apt cache cleaned + autoremove run'] : ['ok' => false, 'error' => trim($out)];

        case 'journal_vacuum':
            [$rc, $out] = shell_out('journalctl --vacuum-size=200M', 60);
            return $rc === 0 ? ['ok' => true, 'data' => trim($out) ?: 'journal trimmed to 200M'] : ['ok' => false, 'error' => trim($out)];

        case 'old_backups':
            $days = max(1, (int)($params['days'] ?? 30));
            $cutoff = time() - $days * 86400;
            $freed = 0.0; $deleted = 0;
            foreach (backup_list() as $b) {
                if ($b['mtime'] < $cutoff) {
                    $r = backup_delete($b['name']);
                    if (!empty($r['ok'])) { $freed += $b['size']; $deleted++; }
                }
            }
            return ['ok' => true, 'data' => "deleted {$deleted} backup(s), freed " . round($freed / 1048576) . " MB"];

        case 'truncate_logs':
            $paths = is_array($params['paths'] ?? null) ? $params['paths'] : [];
            $allow = array_values(log_catalog());
            $done = 0; $freed = 0.0;
            foreach ($paths as $p) {
                if (!in_array($p, $allow, true) || !is_file($p)) { continue; }
                $freed += (float)@filesize($p);
                $fp = @fopen($p, 'w');
                if ($fp !== false) { fclose($fp); $done++; }
            }
            return ['ok' => true, 'data' => "truncated {$done} log(s), freed " . round($freed / 1048576) . " MB"];

        case 'tmp_files':
            $cutoff = time() - 86400;
            $freed = 0.0; $deleted = 0;
            foreach ([UPTMP, DLTMP] as $d) {
                foreach (glob($d . '/*') ?: [] as $f) {
                    if (is_file($f) && (int)@filemtime($f) < $cutoff) {
                        $freed += (float)@filesize($f);
                        if (@unlink($f)) { $deleted++; }
                    }
                }
            }
            return ['ok' => true, 'data' => "removed {$deleted} temp file(s), freed " . round($freed / 1048576) . " MB"];

        case 'docker_prune':
            if (!docker_installed()) { return ['ok' => false, 'error' => 'docker not installed']; }
            [$rc, $out] = shell_out('docker system prune -af', 120);
            return $rc === 0 ? ['ok' => true, 'data' => trim($out)] : ['ok' => false, 'error' => trim($out)];

        default:
            return ['ok' => false, 'error' => 'unknown cleanup action'];
    }
}

/* ============= app store (WordPress, phpMyAdmin) ========= */
/* Powered by WP-CLI, ensured on first use. */


function wp_cli_installed(): bool
{
    return is_file(WP_CLI_BIN);
}

function wp_cli_ensure(): array
{
    if (wp_cli_installed()) { return ['ok' => true]; }
    [$rc, $out] = shell_out('curl -fsSL -o ' . escapeshellarg(WP_CLI_BIN) . ' ' . escapeshellarg(WP_CLI_URL), 120);
    if ($rc !== 0 || !is_file(WP_CLI_BIN)) { return ['ok' => false, 'error' => 'wp-cli download failed: ' . trim($out)]; }
    @chmod(WP_CLI_BIN, 0755);
    [$rc2, $out2] = shell_out('sudo -u www-data ' . WP_CLI_BIN . ' --info', 20);
    if ($rc2 !== 0) { return ['ok' => false, 'error' => 'wp-cli installed but not runnable: ' . trim($out2)]; }
    return ['ok' => true];
}

function wp_cli(string $siteRoot, string $args, int $timeout = 120): array
{
    return shell_out('sudo -u www-data ' . WP_CLI_BIN . ' --path=' . escapeshellarg($siteRoot) . ' ' . $args, $timeout);
}

function app_catalog(): array
{
    return [
        'wp_cli' => wp_cli_installed(),
        'apps' => [
            ['key' => 'wordpress', 'name' => 'WordPress',
             'desc' => 'Blog / CMS. Installs core, creates a database, and completes setup via WP-CLI — needs an empty PHP site.'],
            ['key' => 'phpmyadmin', 'name' => 'phpMyAdmin',
             'desc' => 'Web UI for MySQL/MariaDB. Installs into /phpmyadmin under an existing PHP site.'],
        ],
    ];
}

function app_wordpress_install(array $a): array
{
    $siteId = (string)($a['site_id'] ?? '');
    $title  = trim((string)($a['title'] ?? 'My Site'));
    $user   = trim((string)($a['admin_user'] ?? ''));
    $email  = trim((string)($a['admin_email'] ?? ''));

    if (!preg_match(ID_RE, $siteId)) { return ['ok' => false, 'error' => 'invalid site']; }
    $s = site_load($siteId);
    if ($s === null || $s['type'] !== 'php') { return ['ok' => false, 'error' => 'pick an existing PHP site']; }
    $root = $s['root'];
    if (is_file($root . '/wp-config.php')) { return ['ok' => false, 'error' => 'WordPress is already installed here']; }
    $entries = array_diff(@scandir($root) ?: [], ['.', '..', 'index.html']);
    if (!empty($entries)) { return ['ok' => false, 'error' => 'document root is not empty — WordPress needs an empty site']; }
    if ($title === '' || strlen($title) > 200) { return ['ok' => false, 'error' => 'invalid title']; }
    if (!preg_match(APP_USER_RE, $user)) { return ['ok' => false, 'error' => 'invalid admin username']; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { return ['ok' => false, 'error' => 'invalid admin email']; }

    $e = wp_cli_ensure();
    if (!$e['ok']) { return $e; }

    $base = substr(preg_replace('/[^a-z0-9]/', '', strtolower($siteId)) ?? 'site', 0, 12) ?: 'site';
    $suf  = substr(bin2hex(random_bytes(3)), 0, 6);
    $dbName = 'wp_' . $base . '_' . $suf;
    $dbUser = 'wpu_' . $base . '_' . $suf;
    $dbPass = bin2hex(random_bytes(12));
    $adminPass = bin2hex(random_bytes(9));

    $dc = db_create($dbName, 'utf8mb4');
    if (empty($dc['ok'])) { return ['ok' => false, 'error' => 'database step failed: ' . ($dc['error'] ?? '')]; }
    $du = db_user_create(['user' => $dbUser, 'host' => 'localhost', 'password' => $dbPass, 'database' => $dbName]);
    if (empty($du['ok'])) { return ['ok' => false, 'error' => 'database user step failed: ' . ($du['error'] ?? '')]; }

    [$rc, $out] = wp_cli($root, 'core download', 180);
    if ($rc !== 0) { return ['ok' => false, 'error' => 'core download failed: ' . trim($out)]; }

    $cfgArgs = 'config create --dbname=' . escapeshellarg($dbName) . ' --dbuser=' . escapeshellarg($dbUser)
        . ' --dbpass=' . escapeshellarg($dbPass) . ' --dbhost=localhost';
    [$rc2, $out2] = wp_cli($root, $cfgArgs, 30);
    if ($rc2 !== 0) { return ['ok' => false, 'error' => 'wp-config creation failed: ' . trim($out2)]; }

    $url = 'http://' . $s['domains'][0];
    $installArgs = 'core install --url=' . escapeshellarg($url) . ' --title=' . escapeshellarg($title)
        . ' --admin_user=' . escapeshellarg($user) . ' --admin_password=' . escapeshellarg($adminPass)
        . ' --admin_email=' . escapeshellarg($email);
    [$rc3, $out3] = wp_cli($root, $installArgs, 60);
    if ($rc3 !== 0) { return ['ok' => false, 'error' => 'core install failed: ' . trim($out3)]; }

    return ['ok' => true, 'data' => [
        'url' => $url, 'admin_user' => $user, 'admin_password' => $adminPass,
        'db_name' => $dbName, 'db_user' => $dbUser,
    ]];
}

function app_phpmyadmin_install(string $siteId): array
{
    if (!preg_match(ID_RE, $siteId)) { return ['ok' => false, 'error' => 'invalid site']; }
    $s = site_load($siteId);
    if ($s === null || $s['type'] === 'proxy') { return ['ok' => false, 'error' => 'pick a PHP or static site']; }
    $dest = rtrim($s['root'], '/') . '/phpmyadmin';
    if (is_dir($dest)) { return ['ok' => false, 'error' => 'already installed at ' . $dest]; }

    $tmpZip = tempnam(sys_get_temp_dir(), 'pma') . '.zip';
    [$rc, $out] = shell_out('curl -fsSL -o ' . escapeshellarg($tmpZip) . ' ' . escapeshellarg(PMA_URL), 120);
    if ($rc !== 0 || !is_file($tmpZip)) { @unlink($tmpZip); return ['ok' => false, 'error' => 'download failed: ' . trim($out)]; }

    $tmpDir = sys_get_temp_dir() . '/pma_' . bin2hex(random_bytes(6));
    @mkdir($tmpDir, 0755, true);
    [$rc2, $out2] = shell_out('cd ' . escapeshellarg($tmpDir) . ' && unzip -q ' . escapeshellarg($tmpZip), 60);
    @unlink($tmpZip);
    if ($rc2 !== 0) { shell_out('rm -rf -- ' . escapeshellarg($tmpDir), 20); return ['ok' => false, 'error' => 'extract failed: ' . trim($out2)]; }

    $extracted = glob($tmpDir . '/*', GLOB_ONLYDIR);
    if (!$extracted || count($extracted) !== 1) {
        shell_out('rm -rf -- ' . escapeshellarg($tmpDir), 20);
        return ['ok' => false, 'error' => 'unexpected archive layout'];
    }
    if (!@rename($extracted[0], $dest)) {
        shell_out('rm -rf -- ' . escapeshellarg($tmpDir), 20);
        return ['ok' => false, 'error' => 'could not place phpMyAdmin files'];
    }
    shell_out('rm -rf -- ' . escapeshellarg($tmpDir), 20);

    $secret = bin2hex(random_bytes(16));
    $cfgLines = [
        '<?php',
        "\$cfg['blowfish_secret'] = '" . $secret . "';",
        '$i = 1;',
        "\$cfg['Servers'][\$i]['auth_type'] = 'cookie';",
        "\$cfg['Servers'][\$i]['host'] = 'localhost';",
        "\$cfg['Servers'][\$i]['compress'] = false;",
        "\$cfg['Servers'][\$i]['AllowNoPassword'] = false;",
        "\$cfg['UploadDir'] = '';",
        "\$cfg['SaveDir'] = '';",
    ];
    @file_put_contents($dest . '/config.inc.php', implode("\n", $cfgLines) . "\n");
    @shell_exec('chown -R www-data:www-data ' . escapeshellarg($dest));

    return ['ok' => true, 'data' => 'installed at ' . $dest . ' — log in with any MySQL user/password'];
}

/* ============= WP Toolkit ================================ */

function wp_detect_sites(): array
{
    $res = [];
    foreach (glob(SITES_DIR . '/*.json') ?: [] as $f) {
        $s = json_decode((string)@file_get_contents($f), true);
        if (!is_array($s) || ($s['type'] ?? '') === 'proxy') { continue; }
        $root = $s['root'] ?? '';
        if ($root !== '' && is_file($root . '/wp-config.php')) {
            $res[] = ['id' => $s['id'], 'domain' => $s['domains'][0] ?? $s['id'], 'root' => $root];
        }
    }
    return $res;
}

function wp_find(string $siteId): ?array
{
    foreach (wp_detect_sites() as $s) { if ($s['id'] === $siteId) { return $s; } }
    return null;
}

function wp_json_count(string $json): int
{
    $d = json_decode($json, true);
    return is_array($d) ? count($d) : 0;
}

function wp_list(): array
{
    $e = wp_cli_ensure();
    if (!$e['ok']) { return $e; }
    $res = [];
    foreach (wp_detect_sites() as $s) {
        [$rc, $ver] = wp_cli($s['root'], 'core version', 20);
        if ($rc !== 0) { continue; } // not a healthy install (e.g. db unreachable) — skip, don't fail the whole list
        [, $coreJ]  = wp_cli($s['root'], 'core check-update --format=json', 20);
        [, $plugJ]  = wp_cli($s['root'], 'plugin list --update=available --format=json', 20);
        [, $themeJ] = wp_cli($s['root'], 'theme list --update=available --format=json', 20);
        $res[] = [
            'id' => $s['id'], 'domain' => $s['domain'], 'version' => trim($ver),
            'core_updates' => wp_json_count($coreJ), 'plugin_updates' => wp_json_count($plugJ),
            'theme_updates' => wp_json_count($themeJ),
        ];
    }
    return ['ok' => true, 'data' => $res];
}

function wp_action(string $siteId, string $cliArgs, int $timeout): array
{
    $s = wp_find($siteId);
    if ($s === null) { return ['ok' => false, 'error' => 'WordPress site not found']; }
    [$rc, $out] = wp_cli($s['root'], $cliArgs, $timeout);
    return $rc === 0 ? ['ok' => true, 'data' => trim($out) ?: 'done'] : ['ok' => false, 'error' => trim($out)];
}

function wp_harden(string $siteId): array
{
    $s = wp_find($siteId);
    if ($s === null) { return ['ok' => false, 'error' => 'WordPress site not found']; }
    $cfgFile = $s['root'] . '/wp-config.php';
    $content = (string)@file_get_contents($cfgFile);
    if ($content === '') { return ['ok' => false, 'error' => 'could not read wp-config.php']; }
    if (strpos($content, 'DISALLOW_FILE_EDIT') !== false) { return ['ok' => true, 'data' => 'already hardened']; }
    $new = preg_replace('/^<\?php/', "<?php\ndefine('DISALLOW_FILE_EDIT', true);", $content, 1);
    if ($new === null || $new === $content) { return ['ok' => false, 'error' => 'could not patch wp-config.php']; }
    if (@file_put_contents($cfgFile, $new) === false) { return ['ok' => false, 'error' => 'write failed']; }
    return ['ok' => true, 'data' => 'file editor disabled (DISALLOW_FILE_EDIT)'];
}

/* =================== dashboard rollup ===================== */

function overview_summary(): array
{
    $sites = site_list();
    $sitesRunning = 0;
    foreach ($sites as $s) { if (!empty($s['enabled'])) { $sitesRunning++; } }

    $ftp = ftpacct_installed() ? count(ftpacct_users()) : 0;

    $mailDomains = 0; $mailboxes = 0;
    if (mail_installed()) {
        mail_ensure_dirs();
        $mailDomains = count(mail_json_read(MAIL_DOMAINS));
        $mailboxes = count(mail_json_read(MAIL_BOXES));
    }

    $dbs = 0;
    if (db_engine_unit() !== null) {
        $r = db_list();
        $dbs = !empty($r['ok']) ? count($r['data']) : 0;
    }

    $containers = 0;
    if (docker_installed()) {
        $r = docker_ps(false);
        $containers = !empty($r['ok']) ? count($r['data']) : 0;
    }

    return [
        'sites_total' => count($sites), 'sites_running' => $sitesRunning,
        'ftp_accounts' => $ftp,
        'mail_domains' => $mailDomains, 'mailboxes' => $mailboxes,
        'databases' => $dbs,
        'docker_running' => $containers,
    ];
}

/* =================== security page ======================== */


function sshd_get_directive(string $key, string $default): string
{
    $content = (string)@file_get_contents(SSHD_CONF);
    if (preg_match('/^\s*' . preg_quote($key, '/') . '\s+(\S+)/mi', $content, $m)) {
        return $m[1];
    }
    return $default;
}

function sshd_set_directive(string $key, string $value): bool
{
    $content = (string)@file_get_contents(SSHD_CONF);
    $pattern = '/^\s*#?\s*' . preg_quote($key, '/') . '\s+.*$/mi';
    $line = $key . ' ' . $value;
    $content = preg_match($pattern, $content)
        ? preg_replace($pattern, $line, $content, 1)
        : rtrim($content) . "\n" . $line . "\n";
    return @file_put_contents(SSHD_CONF, $content) !== false;
}

function sec_get(): array
{
    $allow = [];
    if (is_file(PANEL_ALLOWLIST)) {
        foreach (explode("\n", (string)@file_get_contents(PANEL_ALLOWLIST)) as $line) {
            if (preg_match('/^\s*allow\s+([^;]+);/', trim($line), $m)) { $allow[] = trim($m[1]); }
        }
    }
    $ping = trim((string)@shell_exec('sysctl -n net.ipv4.icmp_echo_ignore_all 2>/dev/null'));
    return [
        'ssh_port'        => sshd_get_directive('Port', '22'),
        'root_login'      => sshd_get_directive('PermitRootLogin', 'yes'),
        'ping_disabled'   => $ping === '1',
        'panel_allowlist' => $allow,
    ];
}

function sec_ssh_port_set(int $port): array
{
    if ($port < 1 || $port > 65535) { return ['ok' => false, 'error' => 'invalid port']; }
    if (ufw_installed()) {
        $st = fw_status();
        if (!empty($st['active'])) { shell_out('ufw allow ' . $port . '/tcp', 15); }
    }
    if (!sshd_set_directive('Port', (string)$port)) { return ['ok' => false, 'error' => 'could not write sshd_config']; }
    [$rc, $out] = shell_out('sshd -t', 15);
    if ($rc !== 0) { return ['ok' => false, 'error' => 'sshd config test failed (not restarted): ' . trim($out)]; }
    [$rc2, $out2] = shell_out('systemctl restart ssh', 20);
    if ($rc2 !== 0) { return ['ok' => false, 'error' => 'restart failed: ' . trim($out2)]; }
    return ['ok' => true, 'data' => "SSH now on port {$port}. Test a NEW connection before closing this one — the old port's UFW rule was left open."];
}

function sec_root_login_set(bool $enabled): array
{
    $val = $enabled ? 'yes' : 'no';
    if (!sshd_set_directive('PermitRootLogin', $val)) { return ['ok' => false, 'error' => 'could not write sshd_config']; }
    [$rc, $out] = shell_out('sshd -t', 15);
    if ($rc !== 0) { return ['ok' => false, 'error' => 'sshd config test failed: ' . trim($out)]; }
    [$rc2, $out2] = shell_out('systemctl restart ssh', 20);
    return $rc2 === 0
        ? ['ok' => true, 'data' => "root SSH login: {$val}"]
        : ['ok' => false, 'error' => trim($out2)];
}

function sec_ping_set(bool $disabled): array
{
    $val = $disabled ? 1 : 0;
    shell_out('sysctl -w net.ipv4.icmp_echo_ignore_all=' . $val, 10);
    @file_put_contents(SYSCTL_BITPANEL, "net.ipv4.icmp_echo_ignore_all = {$val}\n");
    return ['ok' => true, 'data' => $disabled ? 'ping (ICMP echo) disabled' : 'ping (ICMP echo) enabled'];
}

function sec_allowlist_set(array $ips): array
{
    foreach ($ips as $ip) {
        if (!valid_ip_or_cidr($ip)) { return ['ok' => false, 'error' => "invalid IP/CIDR: {$ip}"]; }
    }
    $lines = [];
    if ($ips) {
        foreach ($ips as $ip) { $lines[] = "allow {$ip};"; }
        $lines[] = 'deny all;';
    } else {
        $lines[] = '# no restriction — all IPs allowed';
    }
    if (@file_put_contents(PANEL_ALLOWLIST, implode("\n", $lines) . "\n") === false) {
        return ['ok' => false, 'error' => 'could not write allowlist'];
    }
    return nginx_test_reload();
}
